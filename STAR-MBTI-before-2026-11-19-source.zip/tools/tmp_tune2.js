#!/usr/bin/env node
/**
 * tmp_tune2.js — 分布整形调参模拟 v2
 * 在 tmp_tune.js 基础上加入「基础分两极化映射」：对非精品命中的模板分做分档变换，
 * 再叠加修正系数放大，扫描组合方案找最优。
 * 用法：node tmp_tune2.js
 */

'use strict';
const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const MD = path.join(ROOT, 'text', 'MBTI星座组合评价表.md');
const md = fs.readFileSync(MD, 'utf8');

const MBTI_TYPES = ['INTJ','INTP','ENTJ','ENTP','INFJ','INFP','ENFJ','ENFP','ISTJ','ISFJ','ESTJ','ESFJ','ISTP','ISFP','ESTP','ESFP'];
const ZODIACS = ['白羊','金牛','双子','巨蟹','狮子','处女','天秤','天蝎','射手','摩羯','水瓶','双鱼'];
const ZE = { 白羊:'火',金牛:'土',双子:'风',巨蟹:'水',狮子:'火',处女:'土',天秤:'风',天蝎:'水',射手:'火',摩羯:'土',水瓶:'风',双鱼:'水' };
const DIM_BUCKETS = { '理性型':['INTJ','INTP','ENTJ','ENTP'],'感性型':['INFJ','INFP','ENFJ','ENFP'],'控制型':['ISTJ','ISFJ','ESTJ','ESFJ'],'自由型':['ISTP','ISFP','ESTP','ESFP'] };
const DIM_OF = {};
for (const [d, ts] of Object.entries(DIM_BUCKETS)) for (const t of ts) DIM_OF[t] = d;
const DIMP = { '理性':0,'感性':1,'控制':2,'自由':3 };
const ELP = { '火':0,'土':1,'风':2,'水':3 };
const LEVELS = [
  { min: 90, name: '天作之合' }, { min: 80, name: '默契搭档' }, { min: 70, name: '互补成长' },
  { min: 60, name: '需要磨合' }, { min: 0, name: '挑战满满' }
];
function levelOf(s) { for (const L of LEVELS) if (s >= L.min) return L.name; return '挑战满满'; }
function clamp(n) { return Math.max(45, Math.min(99, n)); }

function extractTable(startKw, endKw) {
  const s = md.indexOf(startKw);
  if (s < 0) throw new Error('锚点缺失: ' + startKw);
  const e = endKw ? md.indexOf(endKw, s + startKw.length) : md.length;
  const lines = md.slice(s, e).split('\n').filter(l => l.trim().startsWith('|'));
  const header = lines[0].split('|').map(c => c.trim()).filter(Boolean);
  const rows = [];
  for (let i = 2; i < lines.length; i++) {
    const cells = lines[i].split('|').map(c => c.trim());
    const obj = {};
    header.forEach((h, j) => { obj[h] = cells[j + 1] !== undefined ? cells[j + 1] : ''; });
    if (Object.values(obj).some(v => v)) rows.push(obj);
  }
  return rows;
}
function parsePairs(rows) {
  const m = {};
  for (const r of rows) {
    const p = r['组合'].split('×').map(s => s.trim());
    m[[p[0], p[1]].sort().join('_x_')] = { a: p[0], b: p[1], base: parseInt(r['评分'], 10) };
  }
  return m;
}
const mbtiT = parsePairs(extractTable('## 六、MBTI 模板配对', '## 七、'));
const zodiacT = parsePairs(extractTable('## 七、星座模板配对', '## 八、'));
const mbtiP = parsePairs(extractTable('## 四、MBTI 精品配对', '## 五、'));
const zodiacP = parsePairs(extractTable('## 五、星座精品配对', '## 六、'));
const isPremium = new Set([...Object.keys(mbtiP), ...Object.keys(zodiacP)]);

function parseCollide(rows, keyCol) {
  const m = {};
  for (const r of rows) {
    const parts = r[keyCol].split('×').map(s => s.trim());
    const prio = keyCol === '碰撞' ? DIMP : ELP;
    const key = parts.slice().sort((x, y) => prio[x] - prio[y]).join('×');
    m[key] = { love: +r['恋爱修正'], friend: +r['友谊修正'], work: +r['职场修正'] };
  }
  return m;
}
const PA0 = parseCollide(extractTable('**表 A：人格碰撞修正系数', '**表 B'), '碰撞');
const EA0 = parseCollide(extractTable('**表 B：星座元素碰撞修正系数', '> 修正系数设计依据'), '元素碰撞');

const TARGETS = {
  '天作之合': { love: [3, 7], friend: [3, 7], work: [4, 8] },
  '默契搭档': { love: [14, 20], friend: [14, 20], work: [15, 22] },
  '互补成长': { love: [28, 36], friend: [28, 36], work: [28, 36] },
  '需要磨合': { love: [26, 34], friend: [26, 34], work: [24, 32] },
  '挑战满满': { love: [10, 18], friend: [10, 18], work: [8, 16] }
};

// 分档映射：6 个断点 [<62, 62-67, 68-72, 73-77, 78-83, ≥84] → 偏移量
const MAPPING_MODES = {
  M1: [-5, -2, 0, 2, 4, 6],
  M2: [-8, -4, 0, 3, 5, 8],
  M3: [-11, -6, -1, 4, 7, 10]
};
function mapScore(x, mode) {
  if (x < 62) return x + mode[0];
  if (x < 68) return x + mode[1];
  if (x < 73) return x + mode[2];
  if (x < 78) return x + mode[3];
  if (x < 84) return x + mode[4];
  return x + mode[5];
}
// 生成映射后的模板表（精品命中的不动）
function buildMapped(tpl, preKeys, mode) {
  const out = {};
  for (const [k, rec] of Object.entries(tpl)) {
    out[k] = { ...rec, base: preKeys.has(k) ? rec.base : mapScore(rec.base, mode) };
  }
  return out;
}

function simulate(mbtiT2, zodiacT2, PA, EA) {
  const picks = [];
  for (let i = 0; i < 16; i++) for (let j = 0; j < 12; j++) picks.push({ mbti: MBTI_TYPES[i], z: ZODIACS[j] });
  const N = picks.length;
  const dist = { love: {}, friend: {}, work: {} };
  for (const s of ['love', 'friend', 'work']) for (const L of LEVELS) dist[s][L.name] = 0;
  let diffSum = 0, cnt = 0;
  for (let i = 0; i < N; i++) {
    for (let j = 0; j < N; j++) {
      const pa = picks[i], pb = picks[j];
      const mk = [pa.mbti, pb.mbti].sort().join('_x_');
      const zk = [pa.z, pb.z].sort().join('_x_');
      const m = mbtiT2[mk], z = zodiacT2[zk];
      const dA = DIM_OF[m.a].replace('型',''), dB = DIM_OF[m.b].replace('型','');
      const pk = [dA, dB].sort((x, y) => DIMP[x] - DIMP[y]).join('×');
      const eA = ZE[z.a], eB = ZE[z.b];
      const ek = [eA, eB].sort((x, y) => ELP[x] - ELP[y]).join('×');
      const res = {};
      for (const s of ['love', 'friend', 'work']) {
        const ms = clamp(m.base + PA[pk][s]);
        const zs = clamp(z.base + EA[ek][s]);
        res[s] = Math.round(ms * 0.6 + zs * 0.4);
        dist[s][levelOf(res[s])]++;
      }
      diffSum += Math.abs(res.love - res.friend) + Math.abs(res.love - res.work) + Math.abs(res.friend - res.work);
      cnt++;
    }
  }
  const out = { avgDiff: diffSum / cnt };
  for (const s of ['love', 'friend', 'work']) {
    out[s] = {};
    for (const L of LEVELS) out[s][L.name] = dist[s][L.name] * 100 / cnt;
  }
  return out;
}

function judge(out) {
  const fails = [];
  for (const s of ['love', 'friend', 'work']) {
    for (const L of LEVELS) {
      const pct = out[s][L.name];
      const [lo, hi] = TARGETS[L.name][s];
      if (!(pct >= lo && pct <= hi)) {
        fails.push(`${s === 'love' ? '恋爱' : s === 'friend' ? '友谊' : '职场'}-${L.name} ${pct.toFixed(1)}%`);
      }
    }
  }
  return fails;
}

function scaled(base, scaleP, scaleN, shift) {
  const out = {};
  for (const [k, v] of Object.entries(base)) {
    out[k] = {};
    for (const s of ['love', 'friend', 'work']) {
      const val = v[s];
      out[k][s] = Math.round(val * (val >= 0 ? scaleP : scaleN)) + shift;
    }
  }
  return out;
}

const candidates = [];
for (const [mName, mMode] of Object.entries(MAPPING_MODES)) {
  for (const scaleP of [1.2, 1.4, 1.6]) {
    for (const scaleN of [2.0, 2.5, 3.0]) {
      for (const shift of [-1, 0]) {
        const mbtiT2 = buildMapped(mbtiT, new Set(Object.keys(mbtiP)), mMode);
        const zodiacT2 = buildMapped(zodiacT, new Set(Object.keys(zodiacP)), mMode);
        const PA = scaled(PA0, scaleP, scaleN, shift);
        const EA = scaled(EA0, scaleP, scaleN, shift);
        const out = simulate(mbtiT2, zodiacT2, PA, EA);
        const fails = judge(out);
        candidates.push({ mName, scaleP, scaleN, shift, fails: fails.length, fails, out, mbtiT2, zodiacT2, PA, EA });
      }
    }
  }
}
candidates.sort((a, b) => a.fails - b.fails);
for (let i = 0; i < 5; i++) {
  const c = candidates[i];
  console.log(`#${i + 1} 映射${c.mName} 正×${c.scaleP} 负×${c.scaleN} 平移${c.shift} → 未达标 ${c.fails} 项`);
  console.log('   ' + c.fails.join(' | '));
  for (const s of ['love', 'friend', 'work']) {
    const cn = s === 'love' ? '恋爱' : s === 'friend' ? '友谊' : '职场';
    console.log(`   ${cn}:`, Object.entries(c.out[s]).map(([k, v]) => `${k} ${v.toFixed(1)}%`).join(' | '));
  }
  console.log(`   场景分化均值 ${c.out.avgDiff.toFixed(1)}`);
  console.log('');
}

const best = candidates[0];
console.log('===== 最优方案系数 =====');
// 打印映射后的基础分范围
let mmin = Infinity, mmax = -Infinity, zmin = Infinity, zmax = -Infinity;
for (const r of Object.values(best.mbtiT2)) { mmin = Math.min(mmin, r.base); mmax = Math.max(mmax, r.base); }
for (const r of Object.values(best.zodiacT2)) { zmin = Math.min(zmin, r.base); zmax = Math.max(zmax, r.base); }
console.log(`映射后 MBTI 模板分: ${mmin} ~ ${mmax}`);
console.log(`映射后 星座 模板分: ${zmin} ~ ${zmax}`);
console.log('表 A：');
for (const [k, v] of Object.entries(best.PA)) console.log(`  ${k}: love ${v.love}, friend ${v.friend}, work ${v.work}`);
console.log('表 B：');
for (const [k, v] of Object.entries(best.EA)) console.log(`  ${k}: love ${v.love}, friend ${v.friend}, work ${v.work}`);
