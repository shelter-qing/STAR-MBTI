#!/usr/bin/env node
// tmp_engine_test.js — 正式引擎全量压力测试（与 build-data.js 口径对比）
'use strict';
const path = require('path');
const ROOT = path.join(__dirname, '..');
const { MBTI_TYPES, ZODIACS } = require(path.join(ROOT, 'utils', 'helper.js'));
const { calculateCompatibility } = require(path.join(ROOT, 'utils', 'score.js'));

const MBTI_N = MBTI_TYPES.length;   // 16
const ZODIAC_N = ZODIACS.length;    // 12

// 1. 语法/加载自检
console.log('✅ 引擎加载成功，MBTI', MBTI_N, '型 / 星座', ZODIAC_N, '座');

// 2. 全量 192 pick × 192 pick × 3 场景（36,864 × 3）分布统计
const dist = { love: {}, friend: {}, work: {} };
const scenes = ['love', 'friend', 'work'];
for (const s of scenes) for (const lv of ['天作之合', '默契搭档', '互补成长', '需要磨合', '挑战满满']) dist[s][lv] = 0;

let total = 0, sumDiff = 0, sum90 = 0, challCount = 0;
const pairCount = MBTI_N * ZODIAC_N; // 192

for (let i = 0; i < pairCount; i++) {
  for (let j = 0; j < pairCount; j++) {
    const mA = Math.floor(i / ZODIAC_N), zA = i % ZODIAC_N;
    const mB = Math.floor(j / ZODIAC_N), zB = j % ZODIAC_N;
    const r = calculateCompatibility(mA, zA, mB, zB, 'love');
    const rf = calculateCompatibility(mA, zA, mB, zB, 'friend');
    const rw = calculateCompatibility(mA, zA, mB, zB, 'work');
    dist.love[r.level]++;
    dist.friend[rf.level]++;
    dist.work[rw.level]++;
    total++;
    if (r.score >= 90) sum90++;
    if (r.score < 60) challCount++;
    sumDiff += Math.abs(r.score - rf.score) + Math.abs(r.score - rw.score) + Math.abs(rf.score - rw.score);
  }
}

function pct(n) { return (n / total * 100).toFixed(1) + '%'; }
console.log('\n=== 全量分布（' + total + ' 组 × 3 场景）===');
const rows = [['天作之合', '90+'], ['默契搭档', '80-89'], ['互补成长', '70-79'], ['需要磨合', '60-69'], ['挑战满满', '<60']];
for (const [lv, rng] of rows) {
  console.log(`${rng} ${lv}: 恋爱 ${pct(dist.love[lv])} | 友谊 ${pct(dist.friend[lv])} | 职场 ${pct(dist.work[lv])}`);
}
console.log('\n天作之合合计:', (sum90 / total * 100).toFixed(1) + '%', '(目标 ≤20%)');
console.log('挑战满满恋爱:', pct(dist.love['挑战满满']), '友谊:', pct(dist.friend['挑战满满']), '职场:', pct(dist.work['挑战满满']), '(目标 ≥8%)');
console.log('场景分化均值:', (sumDiff / total).toFixed(1), '分 (目标 ≥10)');

// 3. 稳定性：同一输入多次调用一致
const r1 = calculateCompatibility(0, 4, 3, 6, 'love');
const r2 = calculateCompatibility(0, 4, 3, 6, 'love');
console.log('\n稳定性: ', JSON.stringify(r1.scene) === JSON.stringify(r2.scene) && r1.summary === r2.summary ? '✅ 完全一致' : '❌ 不一致');

// 4. 文档第十一章示例对齐
// 示例1: INTJ(0)×ENFP(7) + 狮子(4座,索引4)×天蝎(7) → love 82 / friend 72 / work 76
const ex1 = calculateCompatibility(0, 4, 7, 7, 'love');
// 示例2: INTJ(0)×ENTP(3) + 处女(5)×摩羯(9) → love 86 / friend 90 / work 96
const ex2 = calculateCompatibility(0, 5, 3, 9, 'love');
// 示例3: INTJ(0)×ESFP(15) + 金牛(1)×水瓶(10) → love 46 / friend 47 / work 51
const ex3 = calculateCompatibility(0, 1, 15, 10, 'love');
console.log('\n=== 文档第十一章示例对齐 ===');
console.log('示例1 INTJ×ENFP+狮子×天蝎:', JSON.stringify(ex1.scene), '(期望 {love:82,friend:72,work:76})');
console.log('示例2 INTJ×ENTP+处女×摩羯:', JSON.stringify(ex2.scene), '(期望 {love:86,friend:90,work:96})');
console.log('示例3 INTJ×ESFP+金牛×水瓶:', JSON.stringify(ex3.scene), '(期望 {love:46,friend:47,work:51})');
const ex1ok = ex1.scene.love === 82 && ex1.scene.friend === 72 && ex1.scene.work === 76;
const ex2ok = ex2.scene.love === 86 && ex2.scene.friend === 90 && ex2.scene.work === 96;
const ex3ok = ex3.scene.love === 46 && ex3.scene.friend === 47 && ex3.scene.work === 51;
console.log('示例对齐:', ex1ok && ex2ok && ex3ok ? '✅ 全部一致' : '❌ 存在偏差');

// 5. 返回结构完整性
const sample = calculateCompatibility(0, 0, 15, 11, 'friend');
const need = ['score', 'level', 'nickname', 'scene', 'summary', 'advice', 'pros', 'cons', 'tags'];
const miss = need.filter(k => !(k in sample));
console.log('\n返回结构:', miss.length === 0 ? '✅ 字段齐全' : '❌ 缺字段: ' + miss.join(','));
console.log('sample pros[0]:', sample.pros[0]);
console.log('sample advice:', sample.advice);

// 6. 全绿判定
const allGreen = sum90 / total * 100 <= 20 &&
  dist.love['挑战满满'] / total >= 0.08 && dist.friend['挑战满满'] / total >= 0.08 && dist.work['挑战满满'] / total >= 0.08 &&
  sumDiff / total >= 10 && ex1ok && ex2ok && ex3ok && miss.length === 0;
console.log('\n' + (allGreen ? '✅✅ 正式引擎全部校验通过' : '❌ 存在未达标项'));
