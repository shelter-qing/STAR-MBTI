#!/usr/bin/env node
/**
 * finalize-doc.js — 将 tmp_tune3 调参结果回填到 MBTI星座组合评价表.md
 *
 * 1. 模板表（六/七章）评分列：非精品 key → baseMap 映射值；精品 key → 精品表分值
 * 2. 表 A（人格碰撞）/ 表 B（元素碰撞）修正系数列 → 优化后最终值
 * 3. 叙事文本更新：1.6 分布描述、9.3 系数范围、9.9 规则2、10.4 星座精品名单
 * 4. 第十一章三个示例：数据来源分、碰撞系数、分数/等级/命名、收尾说明全部重算
 *
 * 用法：node finalize-doc.js
 */

'use strict';
const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const MD_PATH = path.join(ROOT, 'text', 'MBTI星座组合评价表.md');
const RESULT_PATH = path.join(__dirname, 'tmp_tune3_result.json');

const md = fs.readFileSync(MD_PATH, 'utf8');
const eol = md.includes('\r\n') ? '\r\n' : '\n';
const lines = md.split(/\r?\n/);
const result = JSON.parse(fs.readFileSync(RESULT_PATH, 'utf8'));

const DIM_BUCKETS = { '理性型':['INTJ','INTP','ENTJ','ENTP'],'感性型':['INFJ','INFP','ENFJ','ENFP'],'控制型':['ISTJ','ISFJ','ESTJ','ESFJ'],'自由型':['ISTP','ISFP','ESTP','ESFP'] };
const DIM_OF = {};
for (const [d, ts] of Object.entries(DIM_BUCKETS)) for (const t of ts) DIM_OF[t] = d;
const DIMP = { '理性':0,'感性':1,'控制':2,'自由':3 };
const ZE = { 白羊:'火',金牛:'土',双子:'风',巨蟹:'水',狮子:'火',处女:'土',天秤:'风',天蝎:'水',射手:'火',摩羯:'土',水瓶:'风',双鱼:'水' };
const ELP = { '火':0,'土':1,'风':2,'水':3 };
const COLLISION_ORDER = ['理性×理性','理性×感性','理性×控制','理性×自由','感性×感性','感性×控制','感性×自由','控制×控制','控制×自由','自由×自由'];
const ELEM_ORDER = ['火×火','火×土','火×风','火×水','土×土','土×风','土×水','水×水','风×风','风×水'];
const SCENES = ['love','friend','work'];

function normPair(a, b) { return [a.trim(), b.trim()].sort().join('_x_'); }
function normCollide(parts, prio) { return parts.slice().sort((x, y) => prio[x] - prio[y]).join('×'); }

function extractTable(startKw, endKw) {
  const s = md.indexOf(startKw);
  if (s < 0) throw new Error('锚点缺失: ' + startKw);
  const e = endKw ? md.indexOf(endKw, s + startKw.length) : md.length;
  const rows = [];
  for (const raw of md.slice(s, e).split(/\r?\n/)) {
    if (!raw.trim().startsWith('|')) continue;
    const cells = raw.split('|').map(c => c.trim());
    if (cells.length < 3) continue;
    rows.push(cells);
  }
  return rows;
}
function parsePairs(rows, comboC, scoreC) {
  const m = {};
  for (const cells of rows) {
    const p = cells[comboC].split('×');
    if (p.length !== 2) continue;
    const key = normPair(p[0], p[1]);
    m[key] = parseInt(cells[scoreC], 10);
  }
  return m;
}
function parseCollide(rows, keyC, valC, prio) {
  const m = {};
  for (const cells of rows) {
    const p = cells[keyC].split('×');
    if (p.length !== 2) continue;
    m[normCollide(p, prio)] = { love: parseInt(cells[valC], 10), friend: parseInt(cells[valC + 1], 10), work: parseInt(cells[valC + 2], 10) };
  }
  return m;
}

const mbtiPremium = parsePairs(extractTable('## 四、MBTI 精品配对', '## 五、'), 2, 4);
const zodiacPremium = parsePairs(extractTable('## 五、星座精品配对', '## 六、'), 2, 4);
const PA_new = {}; // collisionKey -> {love,friend,work}
for (let i = 0; i < 10; i++) {
  const key = COLLISION_ORDER[i];
  PA_new[key] = { love: result.PA[i][0], friend: result.PA[i][1], work: result.PA[i][2] };
}
const EA_new = {};
for (let i = 0; i < 10; i++) {
  const key = ELEM_ORDER[i];
  EA_new[key] = { love: result.EA[i][0], friend: result.EA[i][1], work: result.EA[i][2] };
}
const baseMapM = result.baseMap.mbti;
const baseMapZ = result.baseMap.zodiac;

function fmt(v) { return v > 0 ? '+' + v : String(v); }

// ---------- 1. 模板表评分列 ----------
let scoreChanged = 0;
function rewriteTemplateRange(startAnchor, endAnchor, premiumMap, baseMap) {
  const s = lines.findIndex(l => l.startsWith(startAnchor));
  if (s < 0) throw new Error('锚点缺失: ' + startAnchor);
  const e = endAnchor ? lines.findIndex((l, i) => i > s && l.startsWith(endAnchor)) : lines.length;
  for (let i = s + 1; i < (e < 0 ? lines.length : e); i++) {
    const raw = lines[i];
    if (!raw.trim().startsWith('|')) continue;
    const cells = raw.split('|');
    if (cells.length < 6) continue;
    const p = cells[2].trim().split('×');
    if (p.length !== 2) continue;
    const key = normPair(p[0], p[1]);
    let newScore = null;
    if (premiumMap[key] !== undefined) newScore = premiumMap[key];
    else if (baseMap[key] !== undefined) newScore = baseMap[key];
    if (newScore === null) continue;
    const old = cells[4].trim();
    if (old !== String(newScore)) {
      cells[4] = ' ' + newScore + ' ';
      lines[i] = cells.join('|');
      scoreChanged++;
    }
  }
}
rewriteTemplateRange('## 六、MBTI 模板配对', '## 七、', mbtiPremium, baseMapM);
rewriteTemplateRange('## 七、星座模板配对', '## 八、', zodiacPremium, baseMapZ);
console.log('模板评分列更新: ' + scoreChanged + ' 处');

// ---------- 2. 修正系数表 ----------
let corrChanged = 0;
function rewriteCorrRange(anchor, corrMap, keyCol, prio) {
  const s = lines.findIndex(l => l.includes(anchor));
  if (s < 0) throw new Error('锚点缺失: ' + anchor);
  for (let i = s + 1; i < lines.length; i++) {
    const raw = lines[i].trim();
    if (raw.startsWith('**')) break; // 下一个章节标题，停止
    if (!raw.startsWith('|')) continue; // 跳过空行
    if (/^\|[\s:|-]+\|?$/.test(raw)) continue; // 表分隔行 |---|---|
    const cells = raw.split('|');
    if (cells.length < 7) continue;
    const p = cells[keyCol].trim().split('×');
    if (p.length !== 2) continue;
    const key = normCollide(p, prio);
    const v = corrMap[key];
    if (!v) continue;
    const olds = [cells[3].trim(), cells[4].trim(), cells[5].trim()];
    const news = [fmt(v.love), fmt(v.friend), fmt(v.work)];
    if (olds[0] !== news[0] || olds[1] !== news[1] || olds[2] !== news[2]) {
      cells[3] = ' ' + news[0] + ' ';
      cells[4] = ' ' + news[1] + ' ';
      cells[5] = ' ' + news[2] + ' ';
      lines[i] = cells.join('|');
      corrChanged++;
    }
  }
}
rewriteCorrRange('**表 A：人格碰撞修正系数', PA_new, 1, DIMP);
rewriteCorrRange('**表 B：星座元素碰撞修正系数', EA_new, 1, ELP);
console.log('修正系数表更新: ' + corrChanged + ' 行');

// ---------- 3. 叙事文本 ----------
function replaceText(oldStr, newStr) {
  const joined = lines.join(eol);
  if (!joined.includes(oldStr)) { console.warn('⚠️ 未找到文本: ' + oldStr.slice(0, 40) + '...'); return; }
  const replaced = joined.replace(oldStr, newStr);
  const arr = replaced.split(/\r?\n/);
  lines.length = 0;
  lines.push(...arr);
}
replaceText('占比约 12%~18%', '占比约 11%~14%');
replaceText('系数范围为 **-6 ~ +12**', '系数范围为 **-14 ~ +28**');
replaceText(
  '2. **模板基础分整定**：原版模板层评分整体虚高（最低 63/67，全量无一落在"挑战满满"档）。本次将 MBTI 模板基础分整体下调 8 分、星座模板基础分整体下调 6 分（精品层不动），使低分区真实存在。文档中模板表的评分列已按此规则更新，构建脚本读取的就是最终值；',
  '2. **模板基础分整定**：原版模板层评分整体虚高（最低 63/67，全量无一落在"挑战满满"档）。本次将模板基础分按分位数曲线整体重排：非精品组合按原分值排序后拉伸至 46~78（MBTI）与 53~90（星座），精品层保持原分并作为同 key 模板分的最终值，使低分区真实存在（三场景"挑战满满"占比均 ≥8%）。文档中模板表的评分列已按此规则更新，构建脚本读取的就是最终值；'
);
replaceText('处女×摩羯、天蝎×巨蟹', '处女×摩羯、双子×射手');
console.log('叙事文本更新完成');

// ---------- 4. 第十一章示例重算 ----------
function clamp(n) { return n < 45 ? 45 : n > 99 ? 99 : n; }
function sceneScore(mbtiBase, zBase, pk, ek, scene) {
  const s = SCENES.indexOf(scene);
  const m = clamp(mbtiBase + PA_new[pk][scene]);
  const z = clamp(zBase + EA_new[ek][scene]);
  return Math.round(m * 0.6 + z * 0.4);
}
function mbtiKeyOf(a, b) { return normPair(a, b); }
const LEVEL_NAMES = {
  '天作之合': { love: '灵魂共振', friend: '生死之交', work: '黄金搭档' },
  '默契搭档': { love: '双星恋人', friend: '灵魂挚友', work: '王牌组合' },
  '互补成长': { love: '互补恋人', friend: '趣味相投', work: '靠谱队友' },
  '需要磨合': { love: '磨合伴侣', friend: '普通熟络', work: '泛泛合作' },
  '挑战满满': { love: '平行宇宙', friend: '点头之交', work: '合作困难' }
};
function levelOf(sc) { return sc >= 90 ? '天作之合' : sc >= 80 ? '默契搭档' : sc >= 70 ? '互补成长' : sc >= 60 ? '需要磨合' : '挑战满满'; }

// 从更新后的行内重新解析模板分（确保用的是回填后的最终值）
function reparseBase(anchor, endAnchor) {
  const s = lines.findIndex(l => l.startsWith(anchor));
  const e = endAnchor ? lines.findIndex((l, i) => i > s && l.startsWith(endAnchor)) : lines.length;
  const map = {};
  for (let i = s + 1; i < (e < 0 ? lines.length : e); i++) {
    const raw = lines[i];
    if (!raw.trim().startsWith('|')) continue;
    const cells = raw.split('|');
    if (cells.length < 6) continue;
    const p = cells[2].trim().split('×');
    if (p.length !== 2) continue;
    map[normPair(p[0], p[1])] = parseInt(cells[4].trim(), 10);
  }
  return map;
}
const mbtiBaseNow = reparseBase('## 六、MBTI 模板配对', '## 七、');
const zodiacBaseNow = reparseBase('## 七、星座模板配对', '## 八、');

function collisionOf(mbtiA, mbtiB) {
  const dA = DIM_OF[mbtiA].replace('型', ''), dB = DIM_OF[mbtiB].replace('型', '');
  return normCollide([dA, dB], DIMP);
}
function elementOf(zA, zB) {
  return normCollide([ZE[zA], ZE[zB]], ELP);
}

const EXAMPLES = [
  { id: 1, mbtiA: 'INTJ', mbtiB: 'ENFP', zA: '天蝎', zB: '狮子', mName: 'INTJ×ENFP', zName: '狮子×天蝎' },
  { id: 2, mbtiA: 'INTJ', mbtiB: 'ENTP', zA: '处女', zB: '摩羯', mName: 'INTJ×ENTP', zName: '处女×摩羯' },
  { id: 3, mbtiA: 'INTJ', mbtiB: 'ESFP', zA: '金牛', zB: '水瓶', mName: 'INTJ×ESFP', zName: '金牛×水瓶' }
];

const results = {};
for (const ex of EXAMPLES) {
  const mk = mbtiKeyOf(ex.mbtiA, ex.mbtiB);
  const zk = mbtiKeyOf(ex.zA, ex.zB);
  const mb = mbtiBaseNow[mk];
  const zb = zodiacBaseNow[zk];
  const pk = collisionOf(ex.mbtiA, ex.mbtiB);
  const ek = elementOf(ex.zA, ex.zB);
  const scores = {};
  for (const s of ['love', 'friend', 'work']) scores[s] = sceneScore(mb, zb, pk, ek, s);
  results[ex.id] = { mb, zb, pk, ek, scores };
  console.log(`示例${ex.id}: ${ex.mName}(${mb}) + ${ex.zName}(${zb}) | 碰撞 ${pk}(${fmt(PA_new[pk].love)}/${fmt(PA_new[pk].friend)}/${fmt(PA_new[pk].work)}) × ${ek}(${fmt(EA_new[ek].love)}/${fmt(EA_new[ek].friend)}/${fmt(EA_new[ek].work)})`);
  console.log(`  love=${scores.love} ${levelOf(scores.love)}/${LEVEL_NAMES[levelOf(scores.love)].love} | friend=${scores.friend} ${levelOf(scores.friend)}/${LEVEL_NAMES[levelOf(scores.friend)].friend} | work=${scores.work} ${levelOf(scores.work)}/${LEVEL_NAMES[levelOf(scores.work)].work}`);
}

const exDefs = [
  { id: 1, pkText: '理性×感性（+9/+5/+3）', ekText: '火×水（+3/-3/+1）', oldScores: { love: 80, friend: 75, work: 76 }, oldLevels: { love: '默契搭档', friend: '互补成长', work: '互补成长' }, oldNames: { love: '双星恋人', friend: '趣味相投', work: '靠谱队友' } },
  { id: 2, pkText: '理性×理性（+4/+6/+12）', ekText: '土×土（+3/+5/+9）', oldScores: { love: 84, friend: 86, work: 91 }, oldLevels: { love: '默契搭档', friend: '默契搭档', work: '天作之合' }, oldNames: { love: '双星恋人', friend: '灵魂挚友', work: '黄金搭档' } },
  { id: 3, pkText: '理性×自由（-2/+1/-2）', ekText: '土×风（-5/-1/+2）', oldScores: { love: 57, friend: 60, work: 59 }, oldLevels: { love: '挑战满满', friend: '需要磨合', work: '挑战满满' }, oldNames: { love: '平行宇宙', friend: '普通熟络', work: '合作困难' } }
];
for (let i = 0; i < exDefs.length; i++) {
  const ex = { ...exDefs[i], ...EXAMPLES[i] };
  const r = results[ex.id]; // pk/ek 在 results 里，不在 EXAMPLES 里
  // 碰撞行
  replaceText(`人格碰撞：${ex.pkText}｜元素碰撞：${ex.ekText}`, `人格碰撞：${r.pk}（${fmt(PA_new[r.pk].love)}/${fmt(PA_new[r.pk].friend)}/${fmt(PA_new[r.pk].work)}）｜元素碰撞：${r.ek}（${fmt(EA_new[r.ek].love)}/${fmt(EA_new[r.ek].friend)}/${fmt(EA_new[r.ek].work)}）`);
  for (const s of ['love', 'friend', 'work']) {
    const sc = r.scores[s];
    const lv = levelOf(sc);
    const name = LEVEL_NAMES[lv][s];
    const cn = { love: '恋爱相性', friend: '友谊默契', work: '职场搭档' }[s];
    replaceText(`| ${cn} | **${ex.oldScores[s]}** | ${ex.oldLevels[s]} | ${ex.oldNames[s]} |`, `| ${cn} | **${sc}** | ${lv} | ${name} |`);
    replaceText(`**${cn}（${ex.oldScores[s]} · ${ex.oldNames[s]}）**`, `**${cn}（${sc} · ${name}）**`);
  }
}

// 数据来源行的基础分更新（星座模板层狮子×天蝎 61 → 新值）
replaceText('星座模板层（狮子×天蝎，61）', `星座模板层（狮子×天蝎，${results[1].zb}）`);
replaceText('MBTI 模板层（INTJ×ESFP，59）+ 星座模板层（金牛×水瓶，61）', `MBTI 模板层（INTJ×ESFP，${results[3].mb}）+ 星座模板层（金牛×水瓶，${results[3].zb}）`);

// 收尾说明
const r1 = results[1], r2 = results[2], r3 = results[3];
const allScores = [r1.scores, r2.scores, r3.scores].flatMap(o => [o.love, o.friend, o.work]);
const minSc = Math.min(...allScores), maxSc = Math.max(...allScores);
const diff2 = Math.max(r2.scores.love, r2.scores.friend, r2.scores.work) - Math.min(r2.scores.love, r2.scores.friend, r2.scores.work);
replaceText(
  `三个示例对照可见：**同一组合的三个场景分数可以相差 15+ 分（示例二 love 84 / work 91），不同组合的同一场景可以横跨 57~91 的完整区间**。`,
  `三个示例对照可见：**同一组合的三个场景分数可以拉开 10+ 分（示例二 love ${r2.scores.love} / work ${r2.scores.work}），不同组合的同一场景可以横跨 ${minSc}~${maxSc} 的完整区间**。`
);
console.log('第十一章示例更新完成');

// 写回
fs.writeFileSync(MD_PATH, lines.join(eol), 'utf8');
console.log('\n✅ 文档已写回: ' + MD_PATH);
