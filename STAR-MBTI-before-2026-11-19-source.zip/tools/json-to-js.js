#!/usr/bin/env node
// tools/json-to-js.js — 将 data/*.json 转为 data/*.js（module.exports）
// 解决微信小程序 require('.json') 模块解析失败的问题
const fs = require('fs');
const path = require('path');

const DATA_DIR = path.join(__dirname, '..', 'data');
const files = fs.readdirSync(DATA_DIR).filter(f => f.endsWith('.json'));

for (const file of files) {
  const jsonPath = path.join(DATA_DIR, file);
  const jsPath = path.join(DATA_DIR, file.replace(/\.json$/, '.js'));
  const raw = fs.readFileSync(jsonPath, 'utf-8');
  // 验证 JSON 合法性
  JSON.parse(raw);
  const js = `// Auto-generated from ${file} — DO NOT EDIT\nmodule.exports = ${raw};\n`;
  fs.writeFileSync(jsPath, js, 'utf-8');
  console.log(`  ${file} → ${path.basename(jsPath)}`);
}
console.log(`Done: ${files.length} files converted.`);
