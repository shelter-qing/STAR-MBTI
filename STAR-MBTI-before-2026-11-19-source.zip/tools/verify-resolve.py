"""Verify the current wheel slot math.

Both bubble orbits are moved back by half a slot from their previous
on-tick positions, so the final bubble phases are aligned to i * slot.
"""

import math


def angular_distance(a, b):
    diff = abs(a - b) % 360
    return min(diff, 360 - diff)


def resolve(rot, n, which):
    slot = 360.0 / n
    norm = rot % 360
    pointer = 180 if which == "B" else 0
    phase = 0
    best = 0
    best_diff = float("inf")
    for i in range(n):
        center = (i * slot + phase + norm - 90 + 360) % 360
        diff = angular_distance(center, pointer)
        if diff < best_diff:
            best_diff, best = diff, i
    return best, best_diff


def bubble_angle(rot, i, n):
    slot = 360.0 / n
    phase = 0
    return (i * slot + phase + rot - 90 + 360) % 360


print("=== Initial selection ===")
initial = [
    ("A", 16, 90, 0, "INTJ"),
    ("A", 12, 330, 4, "Leo"),
    ("B", 16, 247.5, 1, "INTP"),
    ("B", 12, 90, 6, "Libra"),
]
all_ok = True
for which, n, rot, expected, label in initial:
    actual, diff = resolve(rot, n, which)
    ok = actual == expected
    all_ok = all_ok and ok
    print(
        f"{which} n={n:2d} rot={rot:7.2f} -> {actual:2d} "
        f"(expected {expected:2d} {label}) {'OK' if ok else 'FAIL'}"
    )

print()
print("=== Snap positions: bubbles are centered on the fixed pointer ===")
for which in ["A", "B"]:
    for n in [16, 12]:
        slot = 360.0 / n
        expected_diff = 0
        for step in range(0, n):
            rot = step * slot
            index, diff = resolve(rot, n, which)
            center = bubble_angle(rot, index, n)
            ok = math.isclose(diff, expected_diff, abs_tol=1e-7)
            all_ok = all_ok and ok
            if not ok:
                print(
                    f"FAIL {which} n={n} rot={rot:.2f} index={index} "
                    f"center={center:.2f} diff={diff:.2f}"
                )

print("All snap positions match the expected bubble/pointer alignment." if all_ok else "MISMATCH")
raise SystemExit(0 if all_ok else 1)
