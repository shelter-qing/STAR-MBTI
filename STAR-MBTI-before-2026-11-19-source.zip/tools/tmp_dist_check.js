#!/usr/bin/env node
// tmp_dist_check.js — 校验回填后文档的模板表评分分布
'use strict';
const fs = require('fs');
const path = require('path');
const md = fs.readFileSync(path.join(__dirname, '..', 'text', 'MBTI星座组合评价表.md'), 'utf8');

function statTable(start, end, label) {
  const s = md.indexOf(start);
  const e = md.indexOf(end, s);
  const rows = md.slice(s, e).split(/\r?\n/).filter(l => {
    const t = l.trim();
    return t.startsWith('|') && !/^\|[\s:|-]+\|?$/.test(t);
  });
  const scores = [];
  for (const r of rows) {
    const c = r.split('|').map(x => x.trim());
    const v = parseInt(c[4], 10);
    if (!isNaN(v)) scores.push(v);
  }
  const hist = { '<60': 0, '60-69': 0, '70-79': 0, '80-89': 0, '90+': 0, max: 0, min: 100 };
  for (const v of scores) {
    if (v < 60) hist['<60']++;
    else if (v < 70) hist['60-69']++;
    else if (v < 80) hist['70-79']++;
    else if (v < 90) hist['80-89']++;
    else hist['90+']++;
    hist.max = Math.max(hist.max, v);
    hist.min = Math.min(hist.min, v);
  }
  console.log(`${label}: 共 ${scores.length} 条 | min=${hist.min} max=${hist.max} | <60:${hist['<60']} 60-69:${hist['60-69']} 70-79:${hist['70-79']} 80-89:${hist['80-89']} 90+:${hist['90+']}`);
}

statTable('## 六、MBTI 模板配对', '## 七、', 'MBTI 模板');
statTable('## 七、星座模板配对', '## 八、', '星座模板');
