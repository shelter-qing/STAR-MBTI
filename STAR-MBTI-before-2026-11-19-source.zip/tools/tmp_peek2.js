#!/usr/bin/env node
// tmp_peek2.js — 查看 scene-engine 剩余结构
'use strict';
const path = require('path');
const d = require(path.join(__dirname, '..', 'data', 'scene-engine.json'));
console.log('naming:', JSON.stringify(d.naming, null, 1));
console.log('copyFit keys:', Object.keys(d.copyFit));
console.log('copyFit sample:', JSON.stringify(d.copyFit[Object.keys(d.copyFit)[0]]).slice(0, 400));
console.log('copyBlock keys:', Object.keys(d.copyBlock));
console.log('copyBlock sample:', JSON.stringify(d.copyBlock[Object.keys(d.copyBlock)[0]]).slice(0, 400));
console.log('advice:', JSON.stringify(d.advice).slice(0, 900));
