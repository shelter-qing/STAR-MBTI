#!/usr/bin/env node
// tmp_peek3.js — 查看 pairs 完整 value 字段
'use strict';
const path = require('path');
const ROOT = path.join(__dirname, '..', 'data');
const m = require(path.join(ROOT, 'mbti-pairs.json'));
const z = require(path.join(ROOT, 'zodiac-pairs.json'));
const mk = Object.keys(m)[0];
const zk = Object.keys(z)[0];
console.log('mbti-pairs value keys:', Object.keys(m[mk]));
console.log('mbti-pairs full:', JSON.stringify(m[mk], null, 1).slice(0, 1200));
console.log('---');
console.log('zodiac-pairs value keys:', Object.keys(z[zk]));
console.log('zodiac-pairs full:', JSON.stringify(z[zk], null, 1).slice(0, 1000));
console.log('---');
// 检查所有条目是否都有 summary/advice
let mNoSummary = 0, zNoSummary = 0;
for (const k of Object.keys(m)) if (!m[k].summary) mNoSummary++;
for (const k of Object.keys(z)) if (!z[k].summary) zNoSummary++;
console.log('mbti-pairs 无 summary:', mNoSummary, '/', Object.keys(m).length);
console.log('zodiac-pairs 无 summary:', zNoSummary, '/', Object.keys(z).length);
