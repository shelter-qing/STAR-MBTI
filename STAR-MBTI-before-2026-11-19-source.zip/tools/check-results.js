'use strict';

const { MBTI_TYPES, ZODIACS } = require('../utils/helper');
const { calculateCompatibility } = require('../utils/score');
const ENGINE = require('../data/scene-engine');

const scenes = ENGINE.scenes;
const knownLevels = new Set(ENGINE.levels.map(level => level.name));
const failures = [];
const levelCounts = Object.fromEntries(scenes.map(scene => [scene, {}]));
let checked = 0;

function fail(message) {
  if (failures.length < 30) failures.push(message);
}

function checkText(value, label) {
  if (typeof value !== 'string' || !value.trim()) {
    fail(`${label}: 文案为空`);
    return;
  }
  if (/\{\w+\}/.test(value)) fail(`${label}: 存在未替换模板变量`);
}

function checkItems(items, label) {
  if (!Array.isArray(items) || items.length !== 4) {
    fail(`${label}: 应有 4 条内容`);
    return;
  }
  items.forEach((item, index) => {
    checkText(item && item.title, `${label}[${index}].title`);
    checkText(item && item.detail, `${label}[${index}].detail`);
    if (item && item.detail && String(item.detail).length > 50) {
      fail(`${label}[${index}].detail: 超过结果卡片建议长度`);
    }
  });
  const details = items.map(item => item && item.detail).filter(Boolean);
  if (new Set(details).size !== details.length) fail(`${label}: 同一张卡片存在重复正文`);
}

function checkAdvice(value, label) {
  const lines = String(value || '').split(/\n+/).filter(Boolean);
  if (lines.length !== 4) fail(`${label}: 应有 4 段评语`);
  if (new Set(lines).size !== lines.length) fail(`${label}: 评语段落重复`);
}

for (let mA = 0; mA < MBTI_TYPES.length; mA++) {
  for (let zA = 0; zA < ZODIACS.length; zA++) {
    for (let mB = 0; mB < MBTI_TYPES.length; mB++) {
      for (let zB = 0; zB < ZODIACS.length; zB++) {
        for (const scene of scenes) {
          const label = `${MBTI_TYPES[mA]}-${ZODIACS[zA].name}/${MBTI_TYPES[mB]}-${ZODIACS[zB].name}/${scene}`;
          const result = calculateCompatibility(mA, zA, mB, zB, scene);
          checked++;

          if (!Number.isInteger(result.score) || result.score < ENGINE.formula.min || result.score > ENGINE.formula.max) {
            fail(`${label}: 分数超出范围 (${result.score})`);
          }
          if (result.score !== result.scene[scene]) fail(`${label}: 当前场景分数与场景分数表不一致`);
          if (!knownLevels.has(result.level)) fail(`${label}: 未知等级 (${result.level})`);
          checkText(result.nickname, `${label}.nickname`);
          checkText(result.summary, `${label}.summary`);
          checkText(result.advice, `${label}.advice`);
          checkText(result.adviceText, `${label}.adviceText`);
          if (result.summary.length > 40) fail(`${label}.summary: 超过摘要建议长度`);
          checkAdvice(result.adviceText, `${label}.adviceText`);
          checkItems(result.fitItems, `${label}.fitItems`);
          checkItems(result.grindItems, `${label}.grindItems`);

          if (!Array.isArray(result.tags) || result.tags.length < 2) {
            fail(`${label}: 标签不足 2 个`);
          } else {
            result.tags.forEach((tag, index) => checkText(tag, `${label}.tags[${index}]`));
          }

          levelCounts[scene][result.level] = (levelCounts[scene][result.level] || 0) + 1;
        }
      }
    }
  }
}

console.log(`已检查 ${checked.toLocaleString()} 份结果 (${MBTI_TYPES.length * ZODIACS.length} 种选型 × ${MBTI_TYPES.length * ZODIACS.length} 种选型 × ${scenes.length} 个场景)`);
for (const scene of scenes) {
  const counts = Object.entries(levelCounts[scene]).map(([level, count]) => `${level}: ${count.toLocaleString()}`);
  console.log(`${scene}: ${counts.join(' | ')}`);
}

if (failures.length) {
  console.error(`发现问题（最多显示 30 条；实际问题可能更多）：\n- ${failures.join('\n- ')}`);
  process.exitCode = 1;
} else {
  console.log('结果结构、分数范围和文案占位符检查通过。');
}
