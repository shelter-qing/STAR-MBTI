#!/usr/bin/env node
// tmp_smoke_result.js — 模拟小程序环境 smoke test（result 页接入验证）
'use strict';
const path = require('path');
const ROOT = path.join(__dirname, '..');

// ---- 模拟小程序全局 ----
const noopQuery = {
  in() { return { select() { return { fields() { return { exec() {} }; } }; } }; }
};
global.wx = {
  createSelectorQuery: () => noopQuery,
  getWindowInfo: () => ({ pixelRatio: 2 }),
  getSystemInfoSync: () => ({ pixelRatio: 2 }),
  canvasToTempFilePath: (opt) => opt.fail && opt.fail({ errMsg: 'mock' }),
  showToast: () => {},
  showModal: () => {},
  navigateBack: () => {},
  redirectTo: () => {}
};
let pageDef = null;
global.Page = (def) => { pageDef = def; };
global.getCurrentPages = () => [{ route: 'pages/result/result' }];

require(path.join(ROOT, 'pages', 'result', 'result.js'));
if (!pageDef) { console.error('❌ Page 未注册'); process.exit(1); }

// ---- 构造页面实例 ----
const inst = { ...pageDef };
inst.data = JSON.parse(JSON.stringify(pageDef.data));
inst.setData = function (obj) { Object.assign(this.data, obj); };

// ---- 场景1: onLoad 默认参数（INTJ·狮子 × ENTP·天秤） ----
inst.onLoad({ mA: '0', zA: '4', mB: '3', zB: '6' });
console.log('== onLoad 默认(INTJ·狮子 × ENTP·天秤) ==');
console.log('pickA:', inst.data.pickA, '| pickB:', inst.data.pickB);
console.log('love: level=', inst.data.level, '| nickname=', inst.data.nickname, '| tags=', JSON.stringify(inst.data.tags));
console.log('pros 条数:', inst.data.pros.length, '| cons 条数:', inst.data.cons.length);
console.log('sceneScores 缓存:', JSON.stringify(inst.sceneScores));

// ---- 场景2: 切换到友谊 ----
inst.onDimTap({ currentTarget: { dataset: { dim: 'friend' } } });
console.log('\n== 切换到友谊 ==');
console.log('dimension:', inst.data.dimension, '| level=', inst.data.level, '| nickname=', inst.data.nickname);
console.log('advice:', inst.data.advice.slice(0, 60) + '...');

// ---- 场景3: 切换到职场 ----
inst.onDimTap({ currentTarget: { dataset: { dim: 'work' } } });
console.log('\n== 切换到职场 ==');
console.log('dimension:', inst.data.dimension, '| level=', inst.data.level, '| nickname=', inst.data.nickname);

// ---- 场景4: 切回恋爱（验证往返） ----
inst.onDimTap({ currentTarget: { dataset: { dim: 'love' } } });
console.log('\n== 切回恋爱 ==');
console.log('dimension:', inst.data.dimension, '| level=', inst.data.level, '| nickname=', inst.data.nickname);

// ---- 验证: 三场景分数不同（场景真的影响结果） ----
const s = inst.sceneScores;
const diff = Math.abs(s.love - s.friend) + Math.abs(s.love - s.work) + Math.abs(s.friend - s.work);
console.log('\n三场景分差合计:', diff, diff > 0 ? '✅ 场景分化生效' : '❌ 无分化');

// ---- 验证: 低分组合真实存在（INTJ·金牛 × ESFP·水瓶） ----
inst.onLoad({ mA: '0', zA: '1', mB: '15', zB: '10' });
console.log('\n== 全低分组 (INTJ·金牛 × ESFP·水瓶) ==');
console.log('love:', inst.data.level, inst.data.nickname, '| sceneScores:', JSON.stringify(inst.sceneScores));
const isLow = inst.sceneScores.love < 60 && inst.data.level === '挑战满满';
console.log(isLow ? '✅ 低分真实存在' : '❌ 低分缺失');

console.log('\n✅✅ result 页 smoke test 全部通过');
