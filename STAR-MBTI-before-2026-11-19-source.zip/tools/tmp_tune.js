#!/usr/bin/env node
/**
 * tmp_tune.js — 分布整形调参模拟（临时工具，不产出交付物）
 * 目标：找到表 A/B 修正系数的放大策略，使三场景分布落入 9.8 目标区间。
 * 用法：node tmp_tune.js
 */

'use strict';
const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const MD = path.join(ROOT, 'text', 'MBTI星座组合评价表.md');
const md = fs.readFileSync(MD, 'utf8');

const MBTI_TYPES = ['INTJ','INTP','ENTJ','ENTP','INFJ','INFP','ENFJ','ENFP','ISTJ','ISFJ','ESTJ','ESFJ','ISTP','ISFP','ESTP','ESFP'];
const ZODIACS = ['白羊','金牛','双子','巨蟹','狮子','处女','天秤','天蝎','射手','摩羯','水瓶','双鱼'];
const ZE = { 白羊:'火',金牛:'土',双子:'风',巨蟹:'水',狮子:'火',处女:'土',天秤:'风',天蝎:'水',射手:'火',摩羯:'土',水瓶:'风',双鱼:'水' };
const DIM_BUCKETS = { '理性型':['INTJ','INTP','ENTJ','ENTP'],'感性型':['INFJ','INFP','ENFJ','ENFP'],'控制型':['ISTJ','ISFJ','ESTJ','ESFJ'],'自由型':['ISTP','ISFP','ESTP','ESFP'] };
const DIM_OF = {};
for (const [d, ts] of Object.entries(DIM_BUCKETS)) for (const t of ts) DIM_OF[t] = d;
const DIMP = { '理性':0,'感性':1,'控制':2,'自由':3 };
const ELP = { '火':0,'土':1,'风':2,'水':3 };
const LEVELS = [
  { min: 90, name: '天作之合' }, { min: 80, name: '默契搭档' }, { min: 70, name: '互补成长' },
  { min: 60, name: '需要磨合' }, { min: 0, name: '挑战满满' }
];
function levelOf(s) { for (const L of LEVELS) if (s >= L.min) return L.name; return '挑战满满'; }
function clamp(n) { return Math.max(45, Math.min(99, n)); }

// 从文档解析配对表
function extractTable(startKw, endKw) {
  const s = md.indexOf(startKw);
  if (s < 0) throw new Error('锚点缺失: ' + startKw);
  const e = endKw ? md.indexOf(endKw, s + startKw.length) : md.length;
  const block = md.slice(s, e);
  const lines = block.split('\n').filter(l => l.trim().startsWith('|'));
  const header = lines[0].split('|').map(c => c.trim()).filter(Boolean);
  const rows = [];
  for (let i = 2; i < lines.length; i++) {
    const cells = lines[i].split('|').map(c => c.trim());
    const obj = {};
    header.forEach((h, j) => { obj[h] = cells[j + 1] !== undefined ? cells[j + 1] : ''; });
    if (Object.values(obj).some(v => v)) rows.push(obj);
  }
  return rows;
}
function parsePairs(rows) {
  const m = {};
  for (const r of rows) {
    const p = r['组合'].split('×').map(s => s.trim());
    m[[p[0], p[1]].sort().join('_x_')] = { a: p[0], b: p[1], base: parseInt(r['评分'], 10) };
  }
  return m;
}
const mbtiT = parsePairs(extractTable('## 六、MBTI 模板配对', '## 七、'));
const zodiacT = parsePairs(extractTable('## 七、星座模板配对', '## 八、'));
const mbtiP = parsePairs(extractTable('## 四、MBTI 精品配对', '## 五、'));
const zodiacP = parsePairs(extractTable('## 五、星座精品配对', '## 六、'));
for (const [t, p] of [[mbtiT, mbtiP], [zodiacT, zodiacP]]) for (const k of Object.keys(p)) if (t[k]) t[k].base = p[k].base;

// 原系数表（从文档解析）
function parseCollide(rows, keyCol) {
  const m = {};
  for (const r of rows) {
    const parts = r[keyCol].split('×').map(s => s.trim());
    const prio = keyCol === '碰撞' ? DIMP : ELP;
    const key = parts.slice().sort((x, y) => prio[x] - prio[y]).join('×');
    m[key] = { love: +r['恋爱修正'], friend: +r['友谊修正'], work: +r['职场修正'] };
  }
  return m;
}
const PA0 = parseCollide(extractTable('**表 A：人格碰撞修正系数', '**表 B'), '碰撞');
const EA0 = parseCollide(extractTable('**表 B：星座元素碰撞修正系数', '> 修正系数设计依据'), '元素碰撞');

// 目标区间
const TARGETS = {
  '天作之合': { love: [3, 7], friend: [3, 7], work: [4, 8] },
  '默契搭档': { love: [14, 20], friend: [14, 20], work: [15, 22] },
  '互补成长': { love: [28, 36], friend: [28, 36], work: [28, 36] },
  '需要磨合': { love: [26, 34], friend: [26, 34], work: [24, 32] },
  '挑战满满': { love: [10, 18], friend: [10, 18], work: [8, 16] }
};

function simulate(PA, EA) {
  const picks = [];
  for (let i = 0; i < 16; i++) for (let j = 0; j < 12; j++) picks.push({ mbti: MBTI_TYPES[i], z: ZODIACS[j] });
  const N = picks.length;
  const dist = { love: {}, friend: {}, work: {} };
  for (const s of ['love', 'friend', 'work']) for (const L of LEVELS) dist[s][L.name] = 0;
  let diffSum = 0, cnt = 0;
  for (let i = 0; i < N; i++) {
    for (let j = 0; j < N; j++) {
      const pa = picks[i], pb = picks[j];
      const mk = [pa.mbti, pb.mbti].sort().join('_x_');
      const zk = [pa.z, pb.z].sort().join('_x_');
      const m = mbtiT[mk], z = zodiacT[zk];
      if (!m || !z) { console.log('MISS', mk, zk); process.exit(1); }
      const dA = DIM_OF[m.a].replace('型',''), dB = DIM_OF[m.b].replace('型','');
      const pk = [dA, dB].sort((x, y) => DIMP[x] - DIMP[y]).join('×');
      const eA = ZE[z.a], eB = ZE[z.b];
      const ek = [eA, eB].sort((x, y) => ELP[x] - ELP[y]).join('×');
      const res = {};
      for (const s of ['love', 'friend', 'work']) {
        const ms = clamp(m.base + PA[pk][s]);
        const zs = clamp(z.base + EA[ek][s]);
        res[s] = Math.round(ms * 0.6 + zs * 0.4);
        dist[s][levelOf(res[s])]++;
      }
      diffSum += Math.abs(res.love - res.friend) + Math.abs(res.love - res.work) + Math.abs(res.friend - res.work);
      cnt++;
    }
  }
  const out = {};
  for (const s of ['love', 'friend', 'work']) {
    out[s] = {};
    for (const L of LEVELS) out[s][L.name] = dist[s][L.name] * 100 / cnt;
  }
  out.avgDiff = diffSum / cnt;
  return out;
}

function judge(out) {
  const fails = [];
  const okAll = {};
  for (const s of ['love', 'friend', 'work']) {
    for (const L of LEVELS) {
      const pct = out[s][L.name];
      const [lo, hi] = TARGETS[L.name][s];
      const ok = pct >= lo && pct <= hi;
      okAll[s + L.name] = ok;
      if (!ok) fails.push(`${s === 'love' ? '恋爱' : s === 'friend' ? '友谊' : '职场'}-${L.name} ${pct.toFixed(1)}%`);
    }
  }
  const low = out.love['挑战满满'];
  return { fails, low, avgDiff: out.avgDiff };
}

// ---- 方案扫描：正系数×scaleP，负系数×scaleN（向下取整保留符号） ----
function scaled(base, scaleP, scaleN, shift) {
  const out = {};
  for (const [k, v] of Object.entries(base)) {
    out[k] = {};
    for (const s of ['love', 'friend', 'work']) {
      const val = v[s];
      const sc = val >= 0 ? scaleP : scaleN;
      out[k][s] = Math.round(val * sc) + shift;
    }
  }
  return out;
}

console.log('扫描方案（正缩放 × 负缩放 × 平移）…\n');
const candidates = [];
for (const scaleP of [1.2, 1.4, 1.6, 1.8, 2.0]) {
  for (const scaleN of [2.0, 2.5, 3.0]) {
    for (const shift of [-1, 0, 1]) {
      const PA = scaled(PA0, scaleP, scaleN, shift);
      const EA = scaled(EA0, scaleP, scaleN, shift);
      const out = simulate(PA, EA);
      const r = judge(out);
      candidates.push({ scaleP, scaleN, shift, fails: r.fails.length, ...r, out });
    }
  }
}
candidates.sort((a, b) => a.fails - b.fails);
const best = candidates[0];
console.log('===== 最优方案 =====');
console.log(`正系数 ×${best.scaleP}，负系数 ×${best.scaleN}，整体平移 ${best.shift}，未达标 ${best.fails} 项`);
for (const f of best.fails) console.log('  ❌ ' + f);
console.log(`场景分化均值: ${best.avgDiff.toFixed(1)}`);
for (const s of ['love', 'friend', 'work']) {
  const cn = s === 'love' ? '恋爱' : s === 'friend' ? '友谊' : '职场';
  console.log(`${cn}:`, Object.entries(best.out[s]).map(([k, v]) => `${k} ${v.toFixed(1)}%`).join(' | '));
}

// 打印最佳方案的具体系数
console.log('\n===== 新系数表 =====');
const PA = scaled(PA0, best.scaleP, best.scaleN, best.shift);
const EA = scaled(EA0, best.scaleP, best.scaleN, best.shift);
console.log('表 A：');
for (const [k, v] of Object.entries(PA)) console.log(`  ${k}: love ${v.love}, friend ${v.friend}, work ${v.work}`);
console.log('表 B：');
for (const [k, v] of Object.entries(EA)) console.log(`  ${k}: love ${v.love}, friend ${v.friend}, work ${v.work}`);
