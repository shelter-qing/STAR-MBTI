// 字体与 border 批量清理
// 用法：node tools/fix-css-batch.js
const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..');
const targets = [
  path.join(root, 'app.wxss'),
  path.join(root, 'pages/index/index.wxss'),
  path.join(root, 'pages/result/result.wxss')
];

for (const f of targets) {
  let c = fs.readFileSync(f, 'utf8');
  const before = c;

  // 字体：@font-face 家族名 'HYDaSongJ-Regular' → 'HYDaSongJ-2'
  c = c.replace(/'HYDaSongJ-Regular'/g, "'HYDaSongJ-2'");
  // 字体：font-family 引用 HYDaSongJ-Regular（无引号）→ 'HYDaSongJ-2'
  c = c.replace(/font-family:\s*HYDaSongJ-Regular\s*;/g, "font-family: 'HYDaSongJ-2';");
  // 字体：'HYDaSongJ', 单独引用 → 'HYDaSongJ-2',
  c = c.replace(/'HYDaSongJ',/g, "'HYDaSongJ-2',");

  // 非法 border gradient
  c = c.replace(/border:\s*0\.5px\s+gradient\s*;/g, 'border: 0.5px solid transparent;');
  c = c.replace(/border:\s*1px\s+gradient\s*;/g, 'border: 1px solid transparent;');
  c = c.replace(/border:\s*18px\s+gradient\s*;/g, 'border: 18px solid transparent;');

  if (c !== before) {
    fs.writeFileSync(f, c, 'utf8');
    console.log('  patched: ' + path.relative(root, f));
  } else {
    console.log('  no change: ' + path.relative(root, f));
  }
}
console.log('=== batch done ===');
