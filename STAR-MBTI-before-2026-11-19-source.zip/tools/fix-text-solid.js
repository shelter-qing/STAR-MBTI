// 批量移除 text_N 的渐变 bgc — 改用按行过滤（绕开嵌套括号问题）
const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..');

const jobs = [
  { file: 'pages/index/index.wxss', selector: '.text_1', color: '#f9e6bb' },
  { file: 'pages/index/index.wxss', selector: '.text_2', color: '#f9e6bb' },
  { file: 'pages/index/index.wxss', selector: '.text_3', color: '#dcd3c1' },
  ...Array.from({ length: 32 }, (_, i) => ({
    file: 'pages/index/index.wxss',
    selector: `.text_${i + 9}`,
    color: '#f9e6bb'
  })),
  { file: 'pages/result/result.wxss', selector: '.text_3', color: '#f9e6bb' },
  { file: 'pages/result/result.wxss', selector: '.text_4', color: '#d6cbf0' }
];

const byFile = {};
for (const j of jobs) {
  const abs = path.join(root, j.file);
  (byFile[abs] = byFile[abs] || []).push(j);
}

for (const [abs, list] of Object.entries(byFile)) {
  let c = fs.readFileSync(abs, 'utf8');
  for (const { selector, color } of list) {
    const re = new RegExp(`(${escapeRe(selector)}\\s*\\{)([\\s\\S]*?)(\\})`, 'g');
    c = c.replace(re, (m, open, body, close) => {
      // 拆分 body 为行
      const lines = body.split(/\r?\n/);
      const kept = lines.filter(line => {
        const t = line.trim();
        if (/^background-image\s*:/.test(t)) return false;
        if (/^(-?)webkit-background-clip\s*:/.test(t)) return false;
        if (/^(-?)webkit-text-fill-color\s*:/.test(t)) return false;
        return true;
      });
      // 修正 font-family
      const fixed = kept.map(line =>
        line.replace(/font-family:\s*HYDaSongJ-2\s*;/g, "font-family: 'HYDaSongJ-2';")
            .replace(/font-family:\s*HYDaSongJ-Regular\s*;/g, "font-family: 'HYDaSongJ-2';")
      );
      // 检查/设置 color
      const hasColor = fixed.some(l => /^\s*color\s*:/.test(l));
      if (hasColor) {
        for (let i = 0; i < fixed.length; i++) {
          if (/^\s*color\s*:/.test(fixed[i])) {
            fixed[i] = fixed[i].replace(/(\s*)color\s*:[^;]+;/, `$1color: ${color};`);
            break;
          }
        }
      } else {
        fixed.unshift(`  color: ${color};`);
      }
      return open + '\n' + fixed.join('\n') + '\n' + close;
    });
  }
  fs.writeFileSync(abs, c, 'utf8');
  console.log(`  patched: ${path.relative(root, abs)}`);
}

function escapeRe(s) { return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }
console.log('=== text-solid (line-filter) done ===');
