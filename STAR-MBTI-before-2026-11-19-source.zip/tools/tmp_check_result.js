#!/usr/bin/env node
'use strict';
const r = require('./tmp_tune3_result.json');
console.log('cM:', r.cM.join(','));
console.log('cZ:', r.cZ.join(','));
console.log('PA rows:', r.PA.length, '| EA rows:', r.EA.length);
console.log('baseMap.mbti:', Object.keys(r.baseMap.mbti).length, '| baseMap.zodiac:', Object.keys(r.baseMap.zodiac).length);
console.log('PA[0]:', JSON.stringify(r.PA[0]));
console.log('EA[0]:', JSON.stringify(r.EA[0]));
console.log('样本 mbti:', JSON.stringify(Object.entries(r.baseMap.mbti).slice(0, 3)));
console.log('样本 zodiac:', JSON.stringify(Object.entries(r.baseMap.zodiac).slice(0, 3)));
// 校验：baseMap 是否覆盖全部非精品 key（136-15=121 / 78-15=63）
const fs = require('fs');
const md = fs.readFileSync('text/MBTI星座组合评价表.md', 'utf8');
function extractTable(startKw, endKw) {
  const s = md.indexOf(startKw);
  const e = endKw ? md.indexOf(endKw, s + startKw.length) : md.length;
  const lines = md.slice(s, e).split('\n').filter(l => l.trim().startsWith('|'));
  const header = lines[0].split('|').map(c => c.trim()).filter(Boolean);
  const rows = [];
  for (let i = 2; i < lines.length; i++) {
    const cells = lines[i].split('|').map(c => c.trim());
    const obj = {};
    header.forEach((h, j) => { obj[h] = cells[j + 1] !== undefined ? cells[j + 1] : ''; });
    if (Object.values(obj).some(v => v)) rows.push(obj);
  }
  return rows;
}
function keysOf(rows) {
  return new Set(rows.map(r => r['组合'].split('×').map(s => s.trim()).sort().join('_x_')));
}
const mbtiT = keysOf(extractTable('## 六、MBTI 模板配对', '## 七、'));
const mbtiP = keysOf(extractTable('## 四、MBTI 精品配对', '## 五、'));
const zodiacT = keysOf(extractTable('## 七、星座模板配对', '## 八、'));
const zodiacP = keysOf(extractTable('## 五、星座精品配对', '## 六、'));
const nonPreM = [...mbtiT].filter(k => !mbtiP.has(k));
const nonPreZ = [...zodiacT].filter(k => !zodiacP.has(k));
const mapM = new Set(Object.keys(r.baseMap.mbti));
const mapZ = new Set(Object.keys(r.baseMap.zodiac));
const missingM = nonPreM.filter(k => !mapM.has(k));
const missingZ = nonPreZ.filter(k => !mapZ.has(k));
console.log('非精品 key 数: MBTI', nonPreM.length, '| 星座', nonPreZ.length);
console.log('baseMap 缺失: MBTI', missingM.length, '| 星座', missingZ.length);
if (missingM.length) console.log('  缺失MBTI:', missingM.join(', '));
if (missingZ.length) console.log('  缺失星座:', missingZ.join(', '));
