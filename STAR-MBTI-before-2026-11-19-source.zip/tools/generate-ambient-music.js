const fs = require('fs');
const path = require('path');

const sampleRate = 11025;
const seconds = 12;
const totalSamples = sampleRate * seconds;
const crossfadeSamples = Math.floor(sampleRate * 0.25);
const output = path.join(__dirname, '..', 'assets', 'audio', 'mbti-star-ambient.wav');
const chords = [
  [130.81, 196.00, 261.63],
  [98.00, 146.83, 196.00],
  [110.00, 164.81, 220.00],
  [87.31, 130.81, 174.61]
];

function chordAt(time) {
  const index = Math.min(chords.length - 1, Math.floor(time / (seconds / chords.length)));
  return chords[index];
}

function sampleAt(index) {
  const time = index / sampleRate;
  const chordTime = time % (seconds / chords.length);
  const chord = chordAt(time);
  const chordEnvelope = Math.min(1, chordTime / 0.55, (seconds / chords.length - chordTime) / 0.7);
  const pad = chord.reduce((sum, frequency, voice) => {
    const detune = voice === 1 ? 1.002 : voice === 2 ? 0.998 : 1;
    return sum + Math.sin(2 * Math.PI * frequency * detune * time) * (voice === 0 ? 0.52 : 0.32);
  }, 0) / chord.length;
  const shimmer = Math.sin(2 * Math.PI * chord[2] * 2 * time) * 0.055;
  const pulse = Math.sin(2 * Math.PI * 0.5 * time) * 0.025;
  const fade = Math.min(1, time / 0.35, (seconds - time) / 0.35);
  return (pad * chordEnvelope + shimmer + pulse) * fade * 0.64;
}

const samples = new Float32Array(totalSamples);
for (let i = 0; i < totalSamples; i += 1) samples[i] = sampleAt(i);

for (let i = 0; i < crossfadeSamples; i += 1) {
  const t = i / crossfadeSamples;
  const tail = totalSamples - crossfadeSamples + i;
  const blended = samples[tail] * (1 - t) + samples[i] * t;
  samples[i] = blended;
  samples[tail] = blended;
}

const dataSize = totalSamples * 2;
const header = Buffer.alloc(44);
header.write('RIFF', 0);
header.writeUInt32LE(36 + dataSize, 4);
header.write('WAVE', 8);
header.write('fmt ', 12);
header.writeUInt32LE(16, 16);
header.writeUInt16LE(1, 20);
header.writeUInt16LE(1, 22);
header.writeUInt32LE(sampleRate, 24);
header.writeUInt32LE(sampleRate * 2, 28);
header.writeUInt16LE(2, 32);
header.writeUInt16LE(16, 34);
header.write('data', 36);
header.writeUInt32LE(dataSize, 40);

const data = Buffer.alloc(dataSize);
for (let i = 0; i < totalSamples; i += 1) {
  const value = Math.max(-1, Math.min(1, samples[i]));
  data.writeInt16LE(Math.round(value * 32767), i * 2);
}

fs.mkdirSync(path.dirname(output), { recursive: true });
fs.writeFileSync(output, Buffer.concat([header, data]));
console.log(`Generated ${output} (${header.length + data.length} bytes)`);
