# -*- coding: utf-8 -*-
"""
汉仪大宋简 子集化 + base64 内嵌工具（微信小程序用）
=====================================================
用法:
    python tools/subset-font.py

流程:
    1. 扫描运行时目录(pages/data/utils/components + 根 app.*)的全部文本, 提取去重字符集
    2. 补充 ASCII 可打印字符与常用中文标点/符号
    3. 用 fontTools 把 assets/HYDaSongJ-2.ttf 裁剪为 woff2
    4. base64 编码写入 utils/font-face-data.js (app.js require 它)
    5. 校验子集后字体字符覆盖率, 缺失字符输出到 tools/output/missing-chars.txt

注意:
    * 新增/修改文案后需重跑本脚本, 否则真机会缺字(豆腐块)
    * 本脚本属于开发工具, 不打进小程序包体
"""
import base64
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SRC_FONT = ROOT / "assets" / "HYDaSongJ-2.ttf"
OUT_WOFF2 = ROOT / "tools" / "output" / "HYDaSongJ-2-subset.woff2"
OUT_JS = ROOT / "utils" / "font-face-data.js"
MISSING_REPORT = ROOT / "tools" / "output" / "missing-chars.txt"

SCAN_DIRS = ["pages", "data", "utils", "components"]
SCAN_FILES = ["app.js", "app.json", "app.wxss"]
SCAN_EXTS = {".wxml", ".js", ".json", ".wxss"}

# 字体缺失时兜底补充的字符(常用全角标点/符号, 即使扫描没抓到也保留)
EXTRA_CHARS = "".join(chr(c) for c in range(32, 127)) + (
    "，。！？；：、（）【】《》〈〉「」『』“”‘’—…·～　"
    "☆★○●◎◇◆□■△▲※→←↑↓×÷±°℃§№"
    "① ② ③ ④ ⑤ ⑥ ⑦ ⑧ ⑨ ⑩ ⑪ ⑫ ⑬ ⑭ ⑮ ⑯ ⑰ ⑱ ⑲ ⑳"
)


def scan_chars() -> str:
    chars = set(EXTRA_CHARS)
    roots = [ROOT / d for d in SCAN_DIRS]
    roots += [ROOT / f for f in SCAN_FILES]
    files = []
    for r in roots:
        if r.is_dir():
            for f in r.rglob("*"):
                if f.is_file() and f.suffix in SCAN_EXTS:
                    files.append(f)
        elif r.is_file():
            files.append(r)
    files = sorted(set(files))
    print(f"[scan] {len(files)} files")
    for f in files:
        try:
            text = f.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            text = f.read_text(encoding="utf-8", errors="ignore")
        chars.update(text)
    # 剔除控制字符(换行/制表符等, 字体 cmap 通常没有)
    chars = {c for c in chars if ord(c) >= 0x20 and c != "\ufeff"}
    return "".join(sorted(chars))


def subset_font(text: str) -> None:
    from fontTools import subset

    options = subset.Options()
    options.flavor = "woff2"
    options.hinting = False
    options.desubroutinize = True
    options.layout_features = ["*"]
    options.name_IDs = ["*"]
    options.name_legacy = True
    options.name_languages = ["*"]
    options.recalc_bounds = True
    options.drop_tables += ["FFTM"]

    print(f"[subset] source: {SRC_FONT.name} ({SRC_FONT.stat().st_size / 1024:.0f} KB)")
    font = subset.load_font(str(SRC_FONT), options)
    subsetter = subset.Subsetter(options)
    subsetter.populate(text=text)
    subsetter.subset(font)
    OUT_WOFF2.parent.mkdir(parents=True, exist_ok=True)
    subset.save_font(font, str(OUT_WOFF2), options)
    print(f"[subset] woff2: {OUT_WOFF2.name} ({OUT_WOFF2.stat().st_size / 1024:.0f} KB)")


def verify(text: str) -> bool:
    from fontTools.ttLib import TTFont

    wanted = set(text)
    sub_cmap = set(chr(k) for k in TTFont(str(OUT_WOFF2)).getBestCmap().keys())
    src_cmap = set(chr(k) for k in TTFont(str(SRC_FONT)).getBestCmap().keys())

    sub_missing = sorted(wanted - sub_cmap)          # 子集化后缺失(源没有的不算)
    src_missing = sorted(wanted - src_cmap)          # 源字体本身就没有的字符
    real_missing = sorted(set(sub_missing) - set(src_missing))  # 源有但子集丢 = 真漏字

    MISSING_REPORT.parent.mkdir(parents=True, exist_ok=True)
    MISSING_REPORT.write_text(
        f"total chars: {len(wanted)}\n"
        f"covered by subset: {len(wanted) - len(sub_missing)}\n"
        f"REAL missing (source has but subset dropped): {len(real_missing)}\n"
        f"  (源字体也没有, 会回退系统字体): {len(src_missing)}\n\n"
        f"REAL missing chars: {'|'.join(real_missing)}\n\n"
        f"fallback chars (not in original font): {'|'.join(src_missing)}\n",
        encoding="utf-8",
    )
    if real_missing:
        print(f"[verify] ERROR: {len(real_missing)} chars in source but dropped by subset")
        print("[verify] see tools/output/missing-chars.txt")
    else:
        print(f"[verify] coverage OK: {len(wanted)} chars, 0 real missing")
    if src_missing:
        print(f"[verify] NOTE: {len(src_missing)} chars not in original font "
              f"(will fallback to system font): {''.join(src_missing)}")
    return not real_missing


def emit_js() -> None:
    b64 = base64.b64encode(OUT_WOFF2.read_bytes()).decode("ascii")
    data_uri = f"data:font/woff2;base64,{b64}"
    js = (
        "// 自动生成 by tools/subset-font.py —— 请勿手改\n"
        "// 新增/修改文案后重跑: python tools/subset-font.py\n"
        "module.exports = '" + data_uri + "';\n"
    )
    OUT_JS.write_text(js, encoding="utf-8")
    kb = len(data_uri) / 1024
    print(f"[js] {OUT_JS.name} ({kb:.0f} KB base64, {len(js) / 1024:.0f} KB as file)")


if __name__ == "__main__":
    if not SRC_FONT.exists():
        print(f"FATAL: font not found: {SRC_FONT}")
        sys.exit(1)
    chars = scan_chars()
    print(f"[scan] unique chars: {len(chars)}")
    subset_font(chars)
    ok = verify(chars)
    emit_js()
    print("[done] all good" if ok else "[done] finished WITH missing chars")
    sys.exit(0 if ok else 2)
