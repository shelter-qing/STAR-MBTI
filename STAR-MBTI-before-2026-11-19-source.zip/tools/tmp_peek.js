#!/usr/bin/env node
// tmp_peek.js — 查看 data JSON 结构
'use strict';
const path = require('path');
const ROOT = path.join(__dirname, '..', 'data');
for (const f of ['mbti-pairs.json', 'zodiac-pairs.json', 'mbti-premium.json', 'zodiac-premium.json', 'scene-engine.json']) {
  const d = require(path.join(ROOT, f));
  console.log('=== ' + f + ' ===');
  const ks = Object.keys(d);
  console.log('top keys:', ks.slice(0, 8).join(', '), '... 共', ks.length);
  if (f.includes('scene')) continue;
  const sampleKey = ks[0];
  const v = d[sampleKey];
  console.log('key示例:', sampleKey, '| value:', JSON.stringify(v).slice(0, 200));
  // 统计 key 格式
  const keys = ks.filter(k => k.includes('_x_'));
  console.log('含 _x_ 的 key:', keys.length, '| 示例:', keys.slice(0, 3).join(' | '));
  console.log();
}
