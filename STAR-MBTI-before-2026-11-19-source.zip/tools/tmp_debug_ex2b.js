#!/usr/bin/env node
// tmp_debug_ex2b.js — 单点打印引擎中间值
'use strict';
const path = require('path');
const ROOT = path.join(__dirname, '..');
const { MBTI_TYPES, ZODIACS } = require(path.join(ROOT, 'utils', 'helper.js'));
const { calculateCompatibility } = require(path.join(ROOT, 'utils', 'score.js'));

const mA = 0, zA = 5, mB = 2, zB = 9; // INTJ·处女 × ENTP·摩羯
console.log('mbtiA:', MBTI_TYPES[mA], 'zA:', ZODIACS[zA].name, 'mbtiB:', MBTI_TYPES[mB], 'zB:', ZODIACS[zB].name);

// 手动复算引擎内部步骤
const ENG = require(path.join(ROOT, 'data', 'scene-engine.json'));
const MP = require(path.join(ROOT, 'data', 'mbti-premium.json'));
const ZP = require(path.join(ROOT, 'data', 'zodiac-premium.json'));
function pairKey(a, b) { return [a, b].sort().join('_x_'); }
const mKey = pairKey(MBTI_TYPES[mA], MBTI_TYPES[mB]);
const zKey = pairKey(ZODIACS[zA].name.replace('座', ''), ZODIACS[zB].name.replace('座', ''));
console.log('mKey:', mKey, 'zKey:', zKey);
console.log('mRec.base:', MP[mKey] ? MP[mKey].base : 'MISS');
console.log('zRec.base:', ZP[zKey] ? ZP[zKey].base : 'MISS');

// 用引擎算三场景
const r = calculateCompatibility(mA, zA, mB, zB, 'love');
console.log('引擎 scene:', JSON.stringify(r.scene));
console.log('引擎 love score:', r.score);
console.log('引擎 level/nickname:', r.level, r.nickname);
