'use strict';

const fs = require('fs');
const path = require('path');

const sampleRate = 22050;
const duration = 0.085;
const totalSamples = Math.floor(sampleRate * duration);
const output = path.join(__dirname, '..', 'assets', 'audio', 'gear-tick.wav');

const noise = new Float32Array(totalSamples);
let seed = 0x5eeda11;
let filteredNoise = 0;
for (let index = 0; index < totalSamples; index += 1) {
  seed ^= seed << 13;
  seed ^= seed >>> 17;
  seed ^= seed << 5;
  const white = (seed >>> 0) / 0x80000000 - 1;
  filteredNoise = filteredNoise * 0.58 + white * 0.42;
  noise[index] = white - filteredNoise * 0.42;
}

const samples = new Float32Array(totalSamples);
for (let index = 0; index < totalSamples; index += 1) {
  const time = index / sampleRate;
  // A single escapement click with a brief, lightly metallic resonance.
  const attack = Math.min(1, time / 0.00035);
  const noiseClick = noise[index] * Math.exp(-time / 0.0018) * 0.32;
  const midRing = Math.sin(2 * Math.PI * 1450 * time) * Math.exp(-time / 0.014) * 0.3;
  const highRing = Math.sin(2 * Math.PI * 2380 * time) * Math.exp(-time / 0.008) * 0.16;
  const body = Math.sin(2 * Math.PI * 540 * time) * Math.exp(-time / 0.018) * 0.12;
  const tail = Math.exp(-time / 0.027);
  samples[index] = (noiseClick + midRing + highRing + body) * attack * tail;
}

let peak = 0;
for (const value of samples) peak = Math.max(peak, Math.abs(value));
const gain = peak > 0 ? 0.78 / peak : 1;

const dataSize = totalSamples * 2;
const header = Buffer.alloc(44);
header.write('RIFF', 0);
header.writeUInt32LE(36 + dataSize, 4);
header.write('WAVE', 8);
header.write('fmt ', 12);
header.writeUInt32LE(16, 16);
header.writeUInt16LE(1, 20);
header.writeUInt16LE(1, 22);
header.writeUInt32LE(sampleRate, 24);
header.writeUInt32LE(sampleRate * 2, 28);
header.writeUInt16LE(2, 32);
header.writeUInt16LE(16, 34);
header.write('data', 36);
header.writeUInt32LE(dataSize, 40);

const data = Buffer.alloc(dataSize);
for (let index = 0; index < totalSamples; index += 1) {
  const value = Math.max(-1, Math.min(1, samples[index] * gain));
  data.writeInt16LE(Math.round(value * 32767), index * 2);
}

fs.writeFileSync(output, Buffer.concat([header, data]));
console.log(`Generated ${output} (${header.length + data.length} bytes)`);
