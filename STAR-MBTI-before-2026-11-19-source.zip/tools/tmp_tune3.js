#!/usr/bin/env node
/**
 * tmp_tune3.js — 分布整形调参模拟 v3
 *
 * 核心改进（相对 v2）：
 * 1. 加权快速模拟：136×78 = 10,608 个 (MBTI key × 星座 key) 组合带权重一次性统计，
 *    与全量 36,864 有序人配对完全等价，单次评估 ~3-8ms，可支撑上万次搜索。
 * 2. 基础分「分位数曲线拉伸」：非精品 key 按 (base, key) 稳定排序后，用 5 个控制点
 *    （0/25/50/75/100 分位 → 分数）分段线性插值重新赋分，彻底拉开中间堆积；
 *    精品 key 保持精品表分值（MBTI 封顶 87、星座封顶 91，保住精品最高分定位）。
 * 3. 修正系数按「表(人格/元素) × 场景(恋爱/友谊/职场)」独立 scaleP/scaleN/shift，
 *    共 18 参数，保留文档相对模式但允许各场景幅度不同。
 * 4. 随机搜索 + 两轮局部精修（σ 递减）。
 *
 * 用法：node tmp_tune3.js [ties|index]   （默认 ties：同分映射到同点；index：打散同分）
 */

'use strict';
const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const MD = path.join(ROOT, 'text', 'MBTI星座组合评价表.md');
const md = fs.readFileSync(MD, 'utf8');

const DIM_BUCKETS = { '理性型':['INTJ','INTP','ENTJ','ENTP'],'感性型':['INFJ','INFP','ENFJ','ENFP'],'控制型':['ISTJ','ISFJ','ESTJ','ESFJ'],'自由型':['ISTP','ISFP','ESTP','ESFP'] };
const DIM_OF = {};
for (const [d, ts] of Object.entries(DIM_BUCKETS)) for (const t of ts) DIM_OF[t] = d;
const DIMP = { '理性':0,'感性':1,'控制':2,'自由':3 };
const ZE = { 白羊:'火',金牛:'土',双子:'风',巨蟹:'水',狮子:'火',处女:'土',天秤:'风',天蝎:'水',射手:'火',摩羯:'土',水瓶:'风',双鱼:'水' };
const ELP = { '火':0,'土':1,'风':2,'水':3 };
const SCENES = ['love','friend','work'];
const SCENE_CN = { love:'恋爱', friend:'友谊', work:'职场' };
const LEVEL_NAMES = ['天作之合','默契搭档','互补成长','需要磨合','挑战满满'];
const COLLISION_ORDER = ['理性×理性','理性×感性','理性×控制','理性×自由','感性×感性','感性×控制','感性×自由','控制×控制','控制×自由','自由×自由'];
const ELEM_ORDER = ['火×火','火×土','火×风','火×水','土×土','土×风','土×水','水×水','风×风','风×水'];

function levelIdx(sc) { return sc >= 90 ? 0 : sc >= 80 ? 1 : sc >= 70 ? 2 : sc >= 60 ? 3 : 4; }

function extractTable(startKw, endKw) {
  const s = md.indexOf(startKw);
  if (s < 0) throw new Error('锚点缺失: ' + startKw);
  const e = endKw ? md.indexOf(endKw, s + startKw.length) : md.length;
  const lines = md.slice(s, e).split('\n').filter(l => l.trim().startsWith('|'));
  const header = lines[0].split('|').map(c => c.trim()).filter(Boolean);
  const rows = [];
  for (let i = 2; i < lines.length; i++) {
    const cells = lines[i].split('|').map(c => c.trim());
    const obj = {};
    header.forEach((h, j) => { obj[h] = cells[j + 1] !== undefined ? cells[j + 1] : ''; });
    if (Object.values(obj).some(v => v)) rows.push(obj);
  }
  return rows;
}
function parsePairs(rows) {
  const m = {};
  for (const r of rows) {
    const p = r['组合'].split('×').map(s => s.trim());
    m[[p[0], p[1]].sort().join('_x_')] = { a: p[0], b: p[1], base: parseInt(r['评分'], 10) };
  }
  return m;
}
function parseCollide(rows, keyCol) {
  const m = {};
  for (const r of rows) {
    const parts = r[keyCol].split('×').map(s => s.trim());
    const prio = keyCol === '碰撞' ? DIMP : ELP;
    const key = parts.slice().sort((x, y) => prio[x] - prio[y]).join('×');
    m[key] = { love: +r['恋爱修正'], friend: +r['友谊修正'], work: +r['职场修正'] };
  }
  return m;
}

const mbtiT = parsePairs(extractTable('## 六、MBTI 模板配对', '## 七、'));
const zodiacT = parsePairs(extractTable('## 七、星座模板配对', '## 八、'));
const mbtiP = parsePairs(extractTable('## 四、MBTI 精品配对', '## 五、'));
const zodiacP = parsePairs(extractTable('## 五、星座精品配对', '## 六、'));
const PA0 = parseCollide(extractTable('**表 A：人格碰撞修正系数', '**表 B'), '碰撞');
const EA0 = parseCollide(extractTable('**表 B：星座元素碰撞修正系数', '> 修正系数设计依据'), '元素碰撞');

const TARGETS = {
  '天作之合': { love: [3, 7], friend: [3, 7], work: [4, 8] },
  '默契搭档': { love: [14, 20], friend: [14, 20], work: [15, 22] },
  '互补成长': { love: [28, 36], friend: [28, 36], work: [28, 36] },
  '需要磨合': { love: [26, 34], friend: [26, 34], work: [24, 32] },
  '挑战满满': { love: [10, 18], friend: [10, 18], work: [8, 16] }
};
const CAP_M = 87, CAP_Z = 91;

// ---------- 预构建静态元数据 ----------
function buildMeta(tpl, isMbti) {
  const meta = {};
  for (const [k, r] of Object.entries(tpl)) {
    if (isMbti) {
      const dA = DIM_OF[r.a].replace('型', ''), dB = DIM_OF[r.b].replace('型', '');
      const pk = COLLISION_ORDER.indexOf([dA, dB].sort((x, y) => DIMP[x] - DIMP[y]).join('×'));
      meta[k] = { pk, ek: -1, freq: r.a === r.b ? 1 : 2 };
    } else {
      const eA = ZE[r.a], eB = ZE[r.b];
      const ek = ELEM_ORDER.indexOf([eA, eB].sort((x, y) => ELP[x] - ELP[y]).join('×'));
      meta[k] = { pk: -1, ek, freq: r.a === r.b ? 1 : 2 };
    }
  }
  return meta;
}
const mbtiMeta = buildMeta(mbtiT, true);
const zodiacMeta = buildMeta(zodiacT, false);
const mbtiPreKeys = new Set(Object.keys(mbtiP));
const zodiacPreKeys = new Set(Object.keys(zodiacP));

// 非精品列表（稳定排序）
function buildSorted(tpl, preKeys) {
  const list = [];
  for (const [k, r] of Object.entries(tpl)) {
    if (preKeys.has(k)) continue;
    list.push({ key: k, base: r.base });
  }
  list.sort((x, y) => x.base - y.base || (x.key < y.key ? -1 : x.key > y.key ? 1 : 0));
  return list;
}
const mbtiSorted = buildSorted(mbtiT, mbtiPreKeys);
const zodiacSorted = buildSorted(zodiacT, zodiacPreKeys);

function interp(f, cps) {
  const fracs = [0, 0.25, 0.5, 0.75, 1];
  for (let i = 0; i < 4; i++) {
    if (f <= fracs[i + 1]) {
      const t = (f - fracs[i]) / (fracs[i + 1] - fracs[i]);
      return cps[i] + t * (cps[i + 1] - cps[i]);
    }
  }
  return cps[4];
}
// mode 'index'：按排序位置逐个赋分（打散同分）；mode 'ties'：同分值映射到同一点
function applyCurve(list, cps, mode) {
  const n = list.length;
  if (mode === 'ties') {
    const groups = new Map();
    list.forEach((rec, i) => {
      if (!groups.has(rec.base)) groups.set(rec.base, [i, i]); else groups.get(rec.base)[1] = i;
    });
    return list.map(rec => {
      const [lo, hi] = groups.get(rec.base);
      const f = (lo + hi) / 2 / (n - 1);
      return { key: rec.key, base: Math.round(interp(f, cps)) };
    });
  }
  return list.map((rec, i) => ({ key: rec.key, base: Math.round(interp(n === 1 ? 0 : i / (n - 1), cps)) }));
}

// 完整 key 列表（精品用精品表分、非精品用映射分）
function fullList(tpl, preTable, preKeys, mapped, meta) {
  const map = new Map(mapped.map(r => [r.key, r.base]));
  const out = [];
  for (const [k, r] of Object.entries(tpl)) {
    const base = preKeys.has(k) ? preTable[k].base : map.get(k);
    const m = meta[k];
    out.push({ base, pk: m.pk, ek: m.ek, freq: m.freq });
  }
  return out;
}

// 修正系数：base(对象{碰撞key: {love,friend,work}}) × PARAMS(每场景 [sp,sn,sh]) → array[10][3]
function buildCorrArray(base, order, PARAMS) {
  const arr = new Array(10);
  for (let idx = 0; idx < 10; idx++) {
    const rec = base[order[idx]];
    const row = [0, 0, 0];
    for (let s = 0; s < 3; s++) {
      const v = rec[SCENES[s]];
      const [sp, sn, sh] = PARAMS[s];
      row[s] = Math.round(v >= 0 ? v * sp + sh : v * sn + sh);
    }
    arr[idx] = row;
  }
  return arr;
}

function simulate(mbtiKeys, zodiacKeys, PA, EA) {
  const dist = [[0, 0, 0, 0, 0], [0, 0, 0, 0, 0], [0, 0, 0, 0, 0]];
  let total = 0, diffSum = 0;
  const len = mbtiKeys.length, lenZ = zodiacKeys.length;
  for (let i = 0; i < len; i++) {
    const m = mbtiKeys[i];
    const pb = PA[m.pk];
    const mb = m.base, mf = m.freq;
    for (let j = 0; j < lenZ; j++) {
      const z = zodiacKeys[j];
      const eb = EA[z.ek];
      const zb = z.base;
      const w = mf * z.freq;
      total += w;
      let s0, s1, s2;
      {
        const x = mb + pb[0], y = zb + eb[0];
        s0 = Math.round((x < 45 ? 45 : x > 99 ? 99 : x) * 0.6 + (y < 45 ? 45 : y > 99 ? 99 : y) * 0.4);
      }
      {
        const x = mb + pb[1], y = zb + eb[1];
        s1 = Math.round((x < 45 ? 45 : x > 99 ? 99 : x) * 0.6 + (y < 45 ? 45 : y > 99 ? 99 : y) * 0.4);
      }
      {
        const x = mb + pb[2], y = zb + eb[2];
        s2 = Math.round((x < 45 ? 45 : x > 99 ? 99 : x) * 0.6 + (y < 45 ? 45 : y > 99 ? 99 : y) * 0.4);
      }
      dist[0][levelIdx(s0)] += w;
      dist[1][levelIdx(s1)] += w;
      dist[2][levelIdx(s2)] += w;
      diffSum += (Math.abs(s0 - s1) + Math.abs(s0 - s2) + Math.abs(s1 - s2)) * w;
    }
  }
  const out = { avgDiff: diffSum / total };
  for (let s = 0; s < 3; s++) {
    out[s] = {};
    for (let L = 0; L < 5; L++) out[s][LEVEL_NAMES[L]] = dist[s][L] * 100 / total;
  }
  return out;
}

function lossOf(out) {
  let loss = 0;
  const fails = [];
  let sum90 = 0;
  for (let s = 0; s < 3; s++) {
    const sname = SCENES[s];
    sum90 += out[s]['天作之合'];
    for (let L = 0; L < 5; L++) {
      const lname = LEVEL_NAMES[L];
      const pct = out[s][lname];
      const [lo, hi] = TARGETS[lname][sname];
      if (pct < lo) { const d = lo - pct; loss += d * d; fails.push(`${SCENE_CN[sname]}-${lname} 低${d.toFixed(1)}`); }
      else if (pct > hi) { const d = pct - hi; loss += d * d; fails.push(`${SCENE_CN[sname]}-${lname} 高${d.toFixed(1)}`); }
    }
  }
  if (sum90 > 20) { const d = sum90 - 20; loss += 1000 * d * d; }
  if (out.avgDiff < 10) { const d = 10 - out.avgDiff; loss += 1000 * d * d; }
  return { loss, fails, sum90 };
}

// ---------- 参数编码 ----------
// 布局：[cM0, dM1..dM4, cZ0, dZ1..dZ4] (10) + 表A love,friend,work + 表B love,friend,work 各 [sp,sn,sh] (18)
const R = { cM0: [45, 58], dM: [4, 13], cZ0: [45, 58], dZ: [4, 13], scaleP: [0.7, 3.0], scaleN: [0.7, 4.0], shift: [-5, 3] };

function decode(p) {
  let i = 0;
  const cM = [p[i++], 0, 0, 0, 0];
  for (let j = 1; j <= 4; j++) cM[j] = Math.min(CAP_M, cM[j - 1] + p[i++]);
  const cZ = [p[i++], 0, 0, 0, 0];
  for (let j = 1; j <= 4; j++) cZ[j] = Math.min(CAP_Z, cZ[j - 1] + p[i++]);
  const PARAMS = [];
  for (let s = 0; s < 3; s++) {
    PARAMS.push([p[i++], p[i++], p[i++]]); // 表A 场景s
  }
  for (let s = 0; s < 3; s++) {
    PARAMS.push([p[i++], p[i++], p[i++]]); // 表B 场景s
  }
  return { cM, cZ, PA_P: PARAMS.slice(0, 3), EA_P: PARAMS.slice(3) };
}

function randomParams() {
  const p = [];
  p.push(R.cM0[0] + Math.random() * (R.cM0[1] - R.cM0[0]));
  for (let j = 0; j < 4; j++) p.push(R.dM[0] + Math.random() * (R.dM[1] - R.dM[0]));
  p.push(R.cZ0[0] + Math.random() * (R.cZ0[1] - R.cZ0[0]));
  for (let j = 0; j < 4; j++) p.push(R.dZ[0] + Math.random() * (R.dZ[1] - R.dZ[0]));
  for (let t = 0; t < 6; t++) {
    p.push(R.scaleP[0] + Math.random() * (R.scaleP[1] - R.scaleP[0]));
    p.push(R.scaleN[0] + Math.random() * (R.scaleN[1] - R.scaleN[0]));
    p.push(R.shift[0] + Math.random() * (R.shift[1] - R.shift[0]));
  }
  return p;
}

const BOX = [
  R.cM0, R.dM, R.dM, R.dM, R.dM,
  R.cZ0, R.dZ, R.dZ, R.dZ, R.dZ,
  R.scaleP, R.scaleN, R.shift, R.scaleP, R.scaleN, R.shift, R.scaleP, R.scaleN, R.shift,
  R.scaleP, R.scaleN, R.shift, R.scaleP, R.scaleN, R.shift, R.scaleP, R.scaleN, R.shift
];
function perturb(p, frac) {
  const np = p.slice();
  for (let i = 0; i < np.length; i++) {
    const [lo, hi] = BOX[i];
    const sigma = (hi - lo) * frac;
    np[i] = Math.min(hi, Math.max(lo, np[i] + (Math.random() * 2 - 1) * sigma));
  }
  return np;
}

// ---------- 评估 ----------
function evalParams(p, mode) {
  const { cM, cZ, PA_P, EA_P } = decode(p);
  const mappedM = applyCurve(mbtiSorted, cM, mode);
  const mappedZ = applyCurve(zodiacSorted, cZ, mode);
  const mbtiKeys = fullList(mbtiT, mbtiP, mbtiPreKeys, mappedM, mbtiMeta);
  const zodiacKeys = fullList(zodiacT, zodiacP, zodiacPreKeys, mappedZ, zodiacMeta);
  const PA = buildCorrArray(PA0, COLLISION_ORDER, PA_P);
  const EA = buildCorrArray(EA0, ELEM_ORDER, EA_P);
  const out = simulate(mbtiKeys, zodiacKeys, PA, EA);
  const { loss, fails, sum90 } = lossOf(out);
  return { loss, fails, sum90, out, p, cM, cZ, PA, EA, mappedM, mappedZ };
}

function report(ev) {
  const { loss, fails, sum90, out } = ev;
  console.log(`[loss=${loss.toFixed(2)} sum90=${sum90.toFixed(1)}% avgDiff=${out.avgDiff.toFixed(1)}]`);
  for (let s = 0; s < 3; s++) {
    const sname = SCENES[s];
    const parts = LEVEL_NAMES.map(L => {
      const pct = out[s][L];
      const [lo, hi] = TARGETS[L][sname];
      const ok = pct >= lo && pct <= hi;
      return `${L} ${pct.toFixed(1)}%${ok ? '' : `(目标${lo}-${hi})`}`;
    });
    console.log(`  ${SCENE_CN[sname]}: ${parts.join(' | ')}`);
  }
  if (fails.length) console.log('  fails:', fails.join(' | '));
}

// ---------- 主流程 ----------
const MODE = process.argv[2] === 'index' ? 'index' : 'ties';
console.log(`映射模式: ${MODE === 'ties' ? '同分同点(保序)' : '按位置打散同分'}`);
console.time('搜索');

let best = { loss: Infinity };
let evals = 0;
let pool = [];

function update(ev) {
  evals++;
  if (ev.loss < best.loss) {
    best = ev;
    console.log(`  #${evals} loss=${ev.loss.toFixed(2)} sum90=${ev.sum90.toFixed(1)} avgDiff=${ev.out.avgDiff.toFixed(1)}`);
  }
  pool.push(ev);
}

const S1 = process.env.S1 ? +process.env.S1 : 5000;
const S2 = process.env.S2 ? +process.env.S2 : 1500;
const S3 = process.env.S3 ? +process.env.S3 : 2000;
const STAGE1 = S1;
for (let i = 0; i < STAGE1; i++) update(evalParams(randomParams(), MODE));
console.log(`Stage1 完成: ${evals} 次评估, 当前最优 loss=${best.loss.toFixed(2)}`);

pool.sort((a, b) => a.loss - b.loss);
pool = pool.slice(0, 12);
console.log('Stage2: σ=10% 局部精修...');
for (let i = 0; i < S2; i++) {
  const base = pool[Math.floor(Math.random() * pool.length)].p;
  update(evalParams(perturb(base, 0.1), MODE));
  if (best.loss === 0) break;
}
console.log(`Stage2 完成: 最优 loss=${best.loss.toFixed(2)}`);

pool.sort((a, b) => a.loss - b.loss);
pool = pool.slice(0, 6);
console.log('Stage3: σ=5% 局部精修...');
for (let i = 0; i < S3; i++) {
  const base = pool[Math.floor(Math.random() * pool.length)].p;
  update(evalParams(perturb(base, 0.05), MODE));
  if (best.loss === 0) break;
}
console.timeEnd('搜索');
console.log(`总评估 ${evals} 次\n`);

console.log('========== 最优方案 ==========');
report(best);
const { cM, cZ } = best;
console.log(`\nMBTI 非精品曲线控制点(0/25/50/75/100%): ${cM.join(', ')}`);
console.log(`星座 非精品曲线控制点(0/25/50/75/100%): ${cZ.join(', ')}`);
for (const [nm, arr] of [['MBTI', best.mappedM], ['星座', best.mappedZ]]) {
  const vals = arr.map(r => r.base).sort((a, b) => a - b);
  const cnt = vals.length;
  console.log(`${nm} 非精品 ${cnt} 条: min ${vals[0]} | p25 ${vals[Math.floor(0.25 * cnt)]} | p50 ${vals[Math.floor(0.5 * cnt)]} | p75 ${vals[Math.floor(0.75 * cnt)]} | max ${vals[cnt - 1]}`);
}
console.log('\n表 A（人格碰撞修正，最终值）:');
for (let idx = 0; idx < 10; idx++) {
  const key = COLLISION_ORDER[idx];
  console.log(`  ${key}: love ${best.PA[idx][0]} | friend ${best.PA[idx][1]} | work ${best.PA[idx][2]}`);
}
console.log('\n表 B（元素碰撞修正，最终值）:');
for (let idx = 0; idx < 10; idx++) {
  const key = ELEM_ORDER[idx];
  console.log(`  ${key}: love ${best.EA[idx][0]} | friend ${best.EA[idx][1]} | work ${best.EA[idx][2]}`);
}
const outMap = { mbti: {}, zodiac: {} };
for (const rec of best.mappedM) outMap.mbti[rec.key] = rec.base;
for (const rec of best.mappedZ) outMap.zodiac[rec.key] = rec.base;
fs.writeFileSync(path.join(__dirname, 'tmp_tune3_result.json'), JSON.stringify({ cM, cZ, PA: best.PA, EA: best.EA, baseMap: outMap }, null, 1));
console.log('\n结果已写入 tools/tmp_tune3_result.json');
