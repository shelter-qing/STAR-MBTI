#!/usr/bin/env node
// tmp_debug_ex2.js — 调试示例2 精品命中
'use strict';
const path = require('path');
const ROOT = path.join(__dirname, '..');
const MP = require(path.join(ROOT, 'data', 'mbti-premium.json'));
const ZP = require(path.join(ROOT, 'data', 'zodiac-premium.json'));
const MP2 = require(path.join(ROOT, 'data', 'mbti-pairs.json'));
const ZP2 = require(path.join(ROOT, 'data', 'zodiac-pairs.json'));
const ENG = require(path.join(ROOT, 'data', 'scene-engine.json'));

function pairKey(a, b) { return [a, b].sort().join('_x_'); }

const mKey = pairKey('INTJ', 'ENTP');
const zKey = pairKey('处女', '摩羯');
console.log('mKey:', mKey, '| 精品命中:', MP[mKey] ? JSON.stringify({ base: MP[mKey].base, name: MP[mKey].name }) : '❌ 未命中');
console.log('zKey:', zKey, '| 精品命中:', ZP[zKey] ? JSON.stringify({ base: ZP[zKey].base, name: ZP[zKey].name }) : '❌ 未命中');
console.log('mKey 模板:', MP2[mKey] ? MP2[mKey].base : '❌');
console.log('zKey 模板:', ZP2[zKey] ? ZP2[zKey].base : '❌');
console.log('zodiac-premium 全部 key:', Object.keys(ZP).join(' | '));
console.log('personaCollide 理性×理性 love:', ENG.personaCollide['理性×理性'] ? ENG.personaCollide['理性×理性'].love : '❌');
console.log('elementCollide 土×土 love:', ENG.elementCollide['土×土'] ? ENG.elementCollide['土×土'].love : '❌');
