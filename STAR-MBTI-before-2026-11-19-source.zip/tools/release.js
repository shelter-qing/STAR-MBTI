'use strict';

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { execFileSync } = require('child_process');

const ROOT = path.resolve(__dirname, '..');
const RELEASE_DIR = path.join(ROOT, 'releases');
const ENV_PATH = path.join(ROOT, 'cloudbase', 'env.json');

function git(args) {
  return execFileSync('git', args, { cwd: ROOT, encoding: 'utf8' }).trim();
}

function gitFileHash(file) {
  const content = execFileSync('git', ['show', `HEAD:${file}`], { cwd: ROOT });
  return crypto.createHash('sha256').update(content).digest('hex');
}

function usage() {
  console.log([
    '用法：',
    '  node tools/release.js status',
    '  node tools/release.js create <版本名>',
    '  node tools/release.js validate',
    '',
    'create 只创建本地候选版本记录，不会部署 CloudBase。'
  ].join('\n'));
}

function readEnv() {
  if (!fs.existsSync(ENV_PATH)) return null;
  try {
    return JSON.parse(fs.readFileSync(ENV_PATH, 'utf8'));
  } catch (error) {
    return { error: error.message };
  }
}

function configured(value) {
  return typeof value === 'string' && value.trim() && !value.includes('请填');
}

function status() {
  const env = readEnv();
  console.log(`Git 当前提交：${git(['rev-parse', '--short', 'HEAD'])}`);
  console.log(`工作区状态：${git(['status', '--short']) || '干净'}`);
  if (!env) {
    console.log('CloudBase：尚未创建 cloudbase/env.json');
    return;
  }
  if (env.error) {
    console.log(`CloudBase 配置错误：${env.error}`);
    return;
  }
  console.log(`CloudBase 测试环境：${configured(env.test && env.test.envId) ? '已填写' : '未填写'}`);
  console.log(`CloudBase 正式环境：${configured(env.production && env.production.envId) ? '已填写' : '未填写'}`);
}

function create(name) {
  if (!/^[a-z0-9][a-z0-9._-]{0,40}$/i.test(name || '')) {
    throw new Error('版本名只能使用字母、数字、点、下划线和短横线');
  }
  const file = path.join(RELEASE_DIR, `${name}.json`);
  if (fs.existsSync(file)) throw new Error(`版本已存在：${name}`);
  const sources = [
    'data/mbti-pairs.js',
    'data/mbti-premium.js',
    'data/mbti-traits.js',
    'data/zodiac-pairs.js',
    'data/zodiac-premium.js',
    'data/zodiac-traits.js',
    'data/scene-engine.js',
    'utils/relationship-copy.js',
    'utils/score.js'
  ];
  const changedSources = git(['status', '--short', '--', ...sources]);
  if (changedSources) {
    throw new Error('请先把本次文案和算法改动提交到 Git，再创建候选版本。');
  }
  const manifest = {
    releaseId: name,
    status: 'candidate',
    gitCommit: git(['rev-parse', 'HEAD']),
    createdAt: new Date().toISOString(),
    validationCommand: 'node tools/check-results.js',
    contentSources: sources.slice(0, -1),
    engineSources: ['utils/score.js'],
    sourceSha256: Object.fromEntries(sources.map(source => [source, gitFileHash(source)]))
  };
  fs.mkdirSync(RELEASE_DIR, { recursive: true });
  fs.writeFileSync(file, `${JSON.stringify(manifest, null, 2)}\n`, 'utf8');
  console.log(`已创建候选版本：releases/${name}.json`);
  console.log('下一步：node tools/release.js validate');
}

function validate() {
  execFileSync(process.execPath, [path.join(ROOT, 'tools', 'check-results.js')], {
    cwd: ROOT,
    stdio: 'inherit'
  });
}

const [command, value] = process.argv.slice(2);
try {
  if (command === 'status') status();
  else if (command === 'create') create(value);
  else if (command === 'validate') validate();
  else usage();
} catch (error) {
  console.error(`发布工具失败：${error.message}`);
  process.exitCode = 1;
}
