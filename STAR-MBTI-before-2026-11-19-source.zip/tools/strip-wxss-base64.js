// 删除指定 class 块内的 base64 background 与 background-size 行
// 用法: node tools/strip-wxss-base64.js <wxss路径> <class1,class2,...>
const fs = require('fs');

const file = process.argv[2];
const classes = process.argv[3].split(',');

let css = fs.readFileSync(file, 'utf8');
const before = css.length;

for (const cls of classes) {
  // 匹配 .cls { ... } 块，删除其中的 base64 background 与 background-size 行
  // 注意 background 是简写属性: url(...base64) 100% no-repeat; —— ) 后到 ; 之间可能有参数
  const re = new RegExp('(\\.' + cls + '\\s*\\{[^}]*?)(?:background:\\s*url\\(data:image/png;base64,[^)]*\\)[^;]*;\\s*|background-size:\\s*100% 100%;\\s*)+', 'g');
  css = css.replace(re, '$1');
}

fs.writeFileSync(file, css);
console.log('size', before, '->', css.length);

for (const cls of classes) {
  const re = new RegExp('\\.' + cls + '\\s*\\{[^}]*\\}');
  const m = css.match(re);
  console.log('==', cls, '==');
  console.log(m ? m[0].slice(0, 260) : 'NOT FOUND');
}
