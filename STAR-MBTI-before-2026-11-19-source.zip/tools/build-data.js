#!/usr/bin/env node
/**
 * tools/build-data.js — 评价表 → data/*.js 构建 + 全量校验
 *
 * 职责：
 *   1. 解析 text/MBTI星座组合评价表.md 的全部数据表
 *   2. 生成 data/ 下 7 个 JS 模块（module.exports，供小程序 require）
 *   3. 全量压力测试：192 pick × 192 pick × 3 场景 = 110,592 次评分
 *   4. 输出 tools/校验报告.md（三场景分布、一致性、稳定性、场景分化）
 *
 * 用法：node tools/build-data.js
 * 依赖：无第三方包，Node 内置 fs/path
 */

'use strict';

const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const MD_PATH = path.join(ROOT, 'text', 'MBTI星座组合评价表.md');
const DATA_DIR = path.join(ROOT, 'data');
const REPORT_PATH = path.join(ROOT, 'tools', '校验报告.md');

/* ================================================================
 * 常量
 * ================================================================ */

const MBTI_TYPES = [
  'INTJ', 'INTP', 'ENTJ', 'ENTP',
  'INFJ', 'INFP', 'ENFJ', 'ENFP',
  'ISTJ', 'ISFJ', 'ESTJ', 'ESFJ',
  'ISTP', 'ISFP', 'ESTP', 'ESFP'
];

// 与 utils/helper.js ZODIACS 顺序一致（去掉「座」后缀）
const ZODIACS = ['白羊', '金牛', '双子', '巨蟹', '狮子', '处女', '天秤', '天蝎', '射手', '摩羯', '水瓶', '双鱼'];

// 星座 → 元素（文档第三章权威）
const ZODIAC_ELEMENT = {
  白羊: '火', 金牛: '土', 双子: '风', 巨蟹: '水',
  狮子: '火', 处女: '土', 天秤: '风', 天蝎: '水',
  射手: '火', 摩羯: '土', 水瓶: '风', 双鱼: '水'
};

// 人格维度桶（文档「维度桶映射」权威）
const DIM_BUCKETS = {
  '理性型': ['INTJ', 'INTP', 'ENTJ', 'ENTP'],
  '感性型': ['INFJ', 'INFP', 'ENFJ', 'ENFP'],
  '控制型': ['ISTJ', 'ISFJ', 'ESTJ', 'ESFJ'],
  '自由型': ['ISTP', 'ISFP', 'ESTP', 'ESFP']
};
const DIM_OF = {};
for (const [dim, types] of Object.entries(DIM_BUCKETS)) {
  for (const t of types) DIM_OF[t] = dim;
}

// 表 A 碰撞 key 规范化优先级（与文档表 A 行序一致：理性<感性<控制<自由）
const DIM_PRIORITY = { '理性': 0, '感性': 1, '控制': 2, '自由': 3 };
// 表 B 元素碰撞 key 规范化优先级（与文档表 B 行序一致：火<土<风<水）
const ELEMENT_PRIORITY = { '火': 0, '土': 1, '风': 2, '水': 3 };

const SCENES = ['love', 'friend', 'work'];
const SCENE_CN = { love: '恋爱', friend: '友谊', work: '职场' };

const LEVELS = [
  { min: 90, name: '天作之合' },
  { min: 80, name: '默契搭档' },
  { min: 70, name: '互补成长' },
  { min: 60, name: '需要磨合' },
  { min: 0,  name: '挑战满满' }
];

function levelOf(score) {
  for (const L of LEVELS) if (score >= L.min) return L.name;
  return '挑战满满';
}
function clamp(n, lo, hi) { return Math.max(lo, Math.min(hi, n)); }

/* ================================================================
 * markdown 工具
 * ================================================================ */

const md = fs.readFileSync(MD_PATH, 'utf8');

/**
 * 提取 [startKw, endKw) 区块内第一个表格的表头 + 数据行。
 * startKw 可为章节标题或表头行本身；endKw 为下一个锚点子串。
 */
function extractTable(startKw, endKw) {
  const start = md.indexOf(startKw);
  if (start < 0) throw new Error('找不到小节锚点: ' + startKw);
  const end = endKw ? md.indexOf(endKw, start + startKw.length) : md.length;
  if (end < 0) throw new Error('找不到结束锚点: ' + endKw);
  const block = md.slice(start, end);
  const lines = block.split('\n').filter(l => l.trim().startsWith('|'));
  if (lines.length < 2) throw new Error('小节内无表格: ' + startKw);
  const header = lines[0].split('|').map(c => c.trim()).filter(Boolean);
  const rows = [];
  for (let i = 2; i < lines.length; i++) {
    const cells = lines[i].split('|').map(c => c.trim());
    const obj = {};
    header.forEach((h, j) => { obj[h] = (cells[j + 1] !== undefined ? cells[j + 1] : ''); });
    if (Object.values(obj).some(v => v)) rows.push(obj);
  }
  return rows;
}

// 单元格 <br> 拆数组
function splitBr(s) {
  return String(s).split('<br>').map(x => x.trim()).filter(Boolean);
}
// 单元格 • 列表拆数组（去项目符号）
function splitBullets(s) {
  return String(s).split('<br>').map(x => x.trim().replace(/^[•·]\s*/, '')).filter(Boolean);
}
// 归一化无序 key：'INTJ' + 'ENFP' → 'ENFP_x_INTJ'（字典序小者在前）
function normKey(a, b) {
  return [a, b].sort().join('_x_');
}
// 人格碰撞 key：'理性型' + '感性型' → '理性×感性'
function personaCollideKey(dimA, dimB) {
  const x = dimA.replace('型', ''), y = dimB.replace('型', '');
  const [p, q] = DIM_PRIORITY[x] <= DIM_PRIORITY[y] ? [x, y] : [y, x];
  return p + '×' + q;
}
// 元素碰撞 key：'火' + '风' → '火×风'
function elementCollideKey(elA, elB) {
  const [p, q] = ELEMENT_PRIORITY[elA] <= ELEMENT_PRIORITY[elB] ? [elA, elB] : [elB, elA];
  return p + '×' + q;
}
// '3%~7%' → {min:3, max:7}
function parsePct(s) {
  const m = String(s).match(/(\d+)%~?(\d+)%/);
  return m ? { min: +m[1], max: +m[2] } : null;
}

/* ================================================================
 * 解析各表
 * ================================================================ */

// 配对表（精品 / 模板共用）：组合列格式 `INTJ×ENFP` / `白羊×狮子`
function parsePairTable(rows) {
  const map = {};
  for (const r of rows) {
    const combo = r['组合'] || '';
    const parts = combo.split('×');
    if (parts.length !== 2) throw new Error('组合格式异常: ' + combo);
    const a = parts[0].trim(), b = parts[1].trim();
    const key = normKey(a, b);
    if (map[key]) throw new Error('重复组合: ' + combo);
    map[key] = {
      a, b, key,
      display: combo,
      name: r['关系名称'] || '',
      base: parseInt(r['评分'], 10),
      fit: splitBullets(r['契合点']),
      block: splitBullets(r['阻碍点']),
      summary: r['总结'] || ''
    };
  }
  return map;
}

const mbtiPremium  = parsePairTable(extractTable('## 四、MBTI 精品配对', '## 五、'));
const zodiacPremium = parsePairTable(extractTable('## 五、星座精品配对', '## 六、'));
const mbtiTemplate  = parsePairTable(extractTable('## 六、MBTI 模板配对', '## 七、'));
const zodiacTemplate = parsePairTable(extractTable('## 七、星座模板配对', '## 八、'));

// 模板与精品对齐（9.9 规则 1）：同 key 时模板基础分以精品为准（就地修改，保证 data JSON 正确）
function alignToPremium(tpl, pre, tag) {
  const issues = [];
  for (const [key, rec] of Object.entries(tpl)) {
    if (pre[key] && rec.base !== pre[key].base) {
      issues.push(`${tag} ${rec.display}：模板 ${rec.base} → 精品 ${pre[key].base}`);
      rec.base = pre[key].base;
    }
  }
  return issues;
}
const alignIssues = [
  ...alignToPremium(mbtiTemplate, mbtiPremium, 'MBTI'),
  ...alignToPremium(zodiacTemplate, zodiacPremium, '星座')
];

// 修正系数表（表 A / 表 B）
function parseCollide(rows, keyCol) {
  const map = {};
  for (const r of rows) {
    const k = (r[keyCol] || '').trim();
    const parts = k.split('×').map(s => s.trim());
    const prio = keyCol === '碰撞' ? DIM_PRIORITY : ELEMENT_PRIORITY;
    const key = parts.slice().sort((x, y) => prio[x] - prio[y]).join('×');
    map[key] = {
      love: parseInt(r['恋爱修正'], 10),
      friend: parseInt(r['友谊修正'], 10),
      work: parseInt(r['职场修正'], 10),
      example: r['代表组合'] || '',
      desc: r['场景底色'] || ''
    };
  }
  return map;
}
const personaCollide = parseCollide(extractTable('**表 A：人格碰撞修正系数', '**表 B'), '碰撞');
const elementCollide = parseCollide(extractTable('**表 B：星座元素碰撞修正系数', '> 修正系数设计依据'), '元素碰撞');

// 9.4 场景化关系命名
const namingRows = extractTable('| 等级区间 | 恋爱相性命名 | 友谊默契命名 | 职场搭档命名 |', '### 9.5');
const naming = { love: {}, friend: {}, work: {} };
for (const r of namingRows) {
  const m = (r['等级区间'] || '').match(/（(.+?)）/);
  const level = m ? m[1] : r['等级区间'];
  naming.love[level] = r['恋爱相性命名'] || '';
  naming.friend[level] = r['友谊默契命名'] || '';
  naming.work[level] = r['职场搭档命名'] || '';
}

// 9.5 场景文案模板
function parseCopy(rows, keyCol) {
  const map = {};
  for (const r of rows) {
    map[r[keyCol]] = { love: r['恋爱契合'] || r['恋爱阻碍'] || r['恋爱建议'] || '', friend: r['友谊契合'] || r['友谊阻碍'] || r['友谊建议'] || '', work: r['职场契合'] || r['职场阻碍'] || r['职场建议'] || '' };
  }
  return map;
}
const copyFitRows = extractTable('| 碰撞 | 恋爱契合 | 友谊契合 | 职场契合 |', '**9.5.2');
const copyBlockRows = extractTable('| 碰撞 | 恋爱阻碍 | 友谊阻碍 | 职场阻碍 |', '**9.5.3');
const adviceRows = extractTable('| 维度 | 恋爱建议 | 友谊建议 | 职场建议 |', '### 9.6');
const copyFit = {}; for (const r of copyFitRows) copyFit[r['碰撞']] = { love: r['恋爱契合'], friend: r['友谊契合'], work: r['职场契合'] };
const copyBlock = {}; for (const r of copyBlockRows) copyBlock[r['碰撞']] = { love: r['恋爱阻碍'], friend: r['友谊阻碍'], work: r['职场阻碍'] };
const advice = {}; for (const r of adviceRows) advice[r['维度']] = { love: r['恋爱建议'], friend: r['友谊建议'], work: r['职场建议'] };

// 12.5 相处建议文案池扩充（每维度 × 每场景 3 条，含原文案为第 1 条）
const advicePoolRows = extractTable('| 维度 | 场景 | 建议 1（※原） | 建议 2（新） | 建议 3（新） |', '### 12.6');
const advicePool = {};
for (const r of advicePoolRows) {
  const dim = r['维度'], scene = r['场景'];
  if (!advicePool[dim]) advicePool[dim] = {};
  advicePool[dim][scene] = [r['建议 1（※原）'], r['建议 2（新）'], r['建议 3（新）']].filter(Boolean);
}

// 12.6 句式模板表（特质亮点句 T1-T3 / 冲突触发句 T1-T3）
const traitTemplateRows = extractTable('**12.6.1 特质亮点句', '**12.6.2');
const traitTemplates = traitTemplateRows.map(r => r['模板']);
const conflictTemplateRows = extractTable('**12.6.2 冲突触发句', '### 12.7');
const conflictTemplates = conflictTemplateRows.map(r => r['模板']);

// 9.6 / 9.7 场景特质补充
const mbtiSceneRows = extractTable('| MBTI | 友谊风格 | 职场风格 |', '### 9.7');
const zodiacSceneRows = extractTable('| 星座 | 友谊风格 | 职场风格 |', '### 9.8');

// 第二章 MBTI 特质库
const mbtiTraitRows = extractTable('| MBTI | 昵称 | 大类 | 核心特质', '### 维度桶映射');
// 第三章 星座特质库
const zodiacTraitRows = extractTable('| 星座 | 元素 | 核心特质', '### 星座雷区');
// 第三章 星座雷区（第十二章冲突触发句 T2 用）
const zodiacMineRows = extractTable('| 星座 | 雷区（敏感点） | 爆发形态 |', '### 人格维度碰撞底色');
// 维度桶映射表（用于交叉验证硬编码）
const dimDocRows = extractTable('| 人格维度 | 包含类型 |', '## 三、');

// 9.8 分布目标
const targetRows = extractTable('| 等级区间 | 恋爱占比目标', '校验规则');
const targets = {};
for (const r of targetRows) {
  const raw = r['等级区间'] || '';
  const m = raw.match(/（(.+?)）/);
  const level = m ? m[1] : raw.replace(/^\d+-\d+\s*/, '').replace(/^<\d+\s*/, '').trim();
  targets[level] = {
    love: parsePct(r['恋爱占比目标']),
    friend: parsePct(r['友谊占比目标']),
    work: parsePct(r['职场占比目标'])
  };
}

/* ================================================================
 * 组装 traits
 * ================================================================ */

const mbtiTraits = {};
for (const r of mbtiTraitRows) {
  const t = r['MBTI'];
  mbtiTraits[t] = {
    nickname: r['昵称'], role: r['大类'],
    core: splitBr(r['核心特质']),
    loveStyle: r['恋爱风格'],
    strengths: r['优势'], weaknesses: r['弱点'],
    trigger: r['触发点'], comfort: r['安慰点'],
    pos: splitBullets(r['正面关键词']), neg: splitBullets(r['负面关键词'])
  };
}
for (const r of mbtiSceneRows) {
  const t = r['MBTI'];
  if (mbtiTraits[t]) { mbtiTraits[t].friendStyle = r['友谊风格']; mbtiTraits[t].workStyle = r['职场风格']; }
}

const zodiacMine = {};
for (const r of zodiacMineRows) {
  const z = String(r['星座']).replace('座', '');
  zodiacMine[z] = { mine: r['雷区（敏感点）'] || '', burst: r['爆发形态'] || '' };
}

const zodiacTraits = {};
for (const r of zodiacTraitRows) {
  const z = String(r['星座']).replace('座', '');
  zodiacTraits[z] = {
    element: r['元素'],
    core: splitBr(r['核心特质']),
    loveStyle: r['恋爱风格'],
    strengths: r['优势'], weaknesses: r['弱点'],
    amplify: {
      '理性型': r['修饰·理性型'], '感性型': r['修饰·感性型'],
      '自由型': r['修饰·自由型'], '控制型': r['修饰·控制型']
    },
    pos: splitBullets(r['正面关键词']), neg: splitBullets(r['负面关键词']),
    mine: zodiacMine[z] ? zodiacMine[z].mine : '',
    burst: zodiacMine[z] ? zodiacMine[z].burst : ''
  };
}
for (const r of zodiacSceneRows) {
  const z = String(r['星座']).replace('座', '');
  if (zodiacTraits[z]) { zodiacTraits[z].friendStyle = r['友谊风格']; zodiacTraits[z].workStyle = r['职场风格']; }
}

/* ================================================================
 * 组装 scene-engine.json
 * ================================================================ */

const sceneEngine = {
  scenes: SCENES,
  formula: { mbtiWeight: 0.6, zodiacWeight: 0.4, min: 45, max: 99 },
  levels: LEVELS,
  dimBuckets: DIM_BUCKETS,
  zodiacElement: ZODIAC_ELEMENT,
  personaCollide,
  elementCollide,
  naming,
  copyFit,
  copyBlock,
  advice,
  advicePool,
  traitTemplates,
  conflictTemplates
};

/* ================================================================
 * 评分引擎（纯函数，与 9.3 公式一致）
 * ================================================================ */

function sceneScore(mbtiPair, zodiacPair, scene) {
  const pk = personaCollideKey(DIM_OF[mbtiPair.a], DIM_OF[mbtiPair.b]);
  const pc = personaCollide[pk];
  const mbtiScore = clamp(mbtiPair.base + pc[scene], 45, 99);

  const ek = elementCollideKey(ZODIAC_ELEMENT[zodiacPair.a], ZODIAC_ELEMENT[zodiacPair.b]);
  const ec = elementCollide[ek];
  const zodiacScore = clamp(zodiacPair.base + ec[scene], 45, 99);

  const total = Math.round(mbtiScore * 0.6 + zodiacScore * 0.4);
  return { mbtiScore, zodiacScore, total, level: levelOf(total), pk, ek };
}

function lookupPair(map, a, b) {
  const rec = map[normKey(a, b)];
  if (!rec) throw new Error('查不到配对: ' + a + '×' + b);
  return rec;
}

/* ================================================================
 * 输出 JS 模块（module.exports，微信小程序 require 兼容）
 * ================================================================ */

fs.mkdirSync(DATA_DIR, { recursive: true });
function writeModule(name, obj) {
  const jsonName = name + '.json';
  const jsName = name + '.js';
  const jsonPath = path.join(DATA_DIR, jsonName);
  const jsPath = path.join(DATA_DIR, jsName);
  const jsonStr = JSON.stringify(obj, null, 2);
  // 保留 JSON 供人类审阅 / 外部工具使用
  fs.writeFileSync(jsonPath, jsonStr, 'utf8');
  // 生成 JS 模块供小程序 require（避免微信小程序 require('.json') 解析失败）
  fs.writeFileSync(jsPath, `// Auto-generated from ${jsonName} — DO NOT EDIT\nmodule.exports = ${jsonStr};\n`, 'utf8');
  console.log('  ✔ ' + jsName + '  (' + (fs.statSync(jsPath).size / 1024).toFixed(1) + ' KB)');
}
console.log('写入 data/ 模块：');
writeModule('mbti-pairs', mbtiTemplate);
writeModule('zodiac-pairs', zodiacTemplate);
writeModule('mbti-premium', mbtiPremium);
writeModule('zodiac-premium', zodiacPremium);
writeModule('mbti-traits', mbtiTraits);
writeModule('zodiac-traits', zodiacTraits);
writeModule('scene-engine', sceneEngine);

/* ================================================================
 * 校验
 * ================================================================ */

const report = [];
const pass = [];
const fail = [];

function check(cond, label) {
  if (cond) pass.push(label);
  else fail.push(label);
  return cond;
}

/* ---- 1. 完整性 ---- */
const mbtiCombos = MBTI_TYPES.length * (MBTI_TYPES.length + 1) / 2;          // 136
const zodiacCombos = ZODIACS.length * (ZODIACS.length + 1) / 2;              // 78
report.push('## 一、数据完整性');
report.push('');
const mbtiCoverage = Object.keys(mbtiTemplate).length;
const zodiacCoverage = Object.keys(zodiacTemplate).length;
check(mbtiCoverage === mbtiCombos, `MBTI 模板覆盖 ${mbtiCoverage}/${mbtiCombos} 组合`);
check(zodiacCoverage === zodiacCombos, `星座模板覆盖 ${zodiacCoverage}/${zodiacCombos} 组合`);
check(Object.keys(mbtiPremium).length === 15, 'MBTI 精品 15 条');
check(Object.keys(zodiacPremium).length === 15, '星座精品 15 条');
check(Object.keys(mbtiTraits).length === 16, 'MBTI 特质 16 型');
check(Object.keys(zodiacTraits).length === 12, '星座特质 12 座');
check(Object.keys(personaCollide).length === 10, '人格碰撞系数 10 种');
check(Object.keys(elementCollide).length === 10, '元素碰撞系数 10 种');
// 维度桶与文档对照
let dimDocOk = true;
for (const r of dimDocRows) {
  const dim = r['人格维度'];
  const types = String(r['包含类型']).split(',').map(s => s.trim());
  if (JSON.stringify(DIM_BUCKETS[dim]) !== JSON.stringify(types)) dimDocOk = false;
}
check(dimDocOk, '维度桶映射与文档一致');
// 星座元素与文档对照
let elDocOk = true;
for (const r of zodiacTraitRows) {
  const z = String(r['星座']).replace('座', '');
  if (ZODIAC_ELEMENT[z] !== r['元素']) elDocOk = false;
}
check(elDocOk, '星座元素映射与文档一致');
// 第十二章新数据校验
let advicePoolOk = true;
for (const dim of Object.keys(DIM_BUCKETS)) {
  if (!advicePool[dim]) { advicePoolOk = false; continue; }
  for (const s of SCENES) {
    const arr = advicePool[dim][SCENE_CN[s]];
    if (!arr || arr.length !== 3) advicePoolOk = false;
  }
}
check(advicePoolOk, '12.5 建议扩充池：4 维度 × 3 场景 × 3 条全量到位');
check(traitTemplates.length === 3, `12.6.1 特质亮点句模板 3 条（实际 ${traitTemplates.length}）`);
check(conflictTemplates.length === 3, `12.6.2 冲突触发句模板 3 条（实际 ${conflictTemplates.length}）`);
let mineOk = true;
for (const z of ZODIACS) {
  if (!zodiacTraits[z].mine || !zodiacTraits[z].burst) mineOk = false;
}
check(mineOk, '星座雷区/爆发形态 12 座全量到位');
report.push(...pass.length ? ['', `- 完整性通过项：${pass.length} 项全部 ✅`] : []);
// 重置 pass/fail 便于分节统计
const sectionPass = pass.splice(0);
const sectionFail = fail.splice(0);

/* ---- 2. 模板与精品对齐 ---- */
report.push('');
report.push('## 二、模板与精品对齐（9.9 规则 1）');
report.push('');
const mbtiHit = Object.keys(mbtiTemplate).filter(k => mbtiPremium[k]).length;
const zodiacHit = Object.keys(zodiacTemplate).filter(k => zodiacPremium[k]).length;
report.push(`- 同 key 命中：MBTI ${mbtiHit} 条、星座 ${zodiacHit} 条`);
if (alignIssues.length) {
  check(false, '模板与精品评分一致（存在自动对齐条目，需回填文档）');
  report.push('- ⚠️ 已由脚本自动对齐（文档模板分需回填为精品分）：');
  for (const s of alignIssues) report.push('  - ' + s);
} else {
  check(true, '模板与精品评分一致');
  report.push('- 不一致条目：0 ✅');
}

/* ---- 3. 模板基础分范围（9.9 规则 2 的结果验证） ---- */
let mbtiBaseMin = Infinity, mbtiBaseMax = -Infinity, zodiacBaseMin = Infinity, zodiacBaseMax = -Infinity;
for (const r of Object.values(mbtiTemplate)) { mbtiBaseMin = Math.min(mbtiBaseMin, r.base); mbtiBaseMax = Math.max(mbtiBaseMax, r.base); }
for (const r of Object.values(zodiacTemplate)) { zodiacBaseMin = Math.min(zodiacBaseMin, r.base); zodiacBaseMax = Math.max(zodiacBaseMax, r.base); }
report.push('');
report.push('## 三、模板基础分范围（整定后）');
report.push('');
report.push(`- MBTI 模板：${mbtiBaseMin} ~ ${mbtiBaseMax}（目标：存在 <60 档）`);
report.push(`- 星座模板：${zodiacBaseMin} ~ ${zodiacBaseMax}（目标：存在 <60 档）`);
check(mbtiBaseMin < 60, 'MBTI 模板存在 <60 基础分（低分区真实存在）');
check(zodiacBaseMin < 60, '星座模板存在 <60 基础分（低分区真实存在）');

/* ---- 4. 全量压力测试 ---- */
console.log('\n全量压力测试：192 pick × 192 pick × 3 场景 …');
const picks = [];
for (let i = 0; i < 16; i++) for (let j = 0; j < 12; j++) picks.push({ mbti: MBTI_TYPES[i], zodiac: ZODIACS[j] });
const N = picks.length;

const dist = {};
for (const s of SCENES) { dist[s] = {}; for (const L of LEVELS) dist[s][L.name] = 0; }

let diffSum = 0;
let bidirMismatch = 0;
let totalScored = 0;

for (let i = 0; i < N; i++) {
  for (let j = 0; j < N; j++) {
    const pa = picks[i], pb = picks[j];
    const mp = lookupPair(mbtiTemplate, pa.mbti, pb.mbti);
    const zp = lookupPair(zodiacTemplate, pa.zodiac, pb.zodiac);
    const res = {};
    for (const s of SCENES) res[s] = sceneScore(mp, zp, s);
    for (const s of SCENES) dist[s][res[s].level]++;
    totalScored++;
    diffSum += Math.abs(res.love.total - res.friend.total)
             + Math.abs(res.love.total - res.work.total)
             + Math.abs(res.friend.total - res.work.total);
    // 双向 key 验证：A×B 与 B×A 应一致（仅对 i>j 的对做对称比较）
    if (j > i) {
      const mp2 = lookupPair(mbtiTemplate, pb.mbti, pa.mbti);
      const zp2 = lookupPair(zodiacTemplate, pb.zodiac, pa.zodiac);
      for (const s of SCENES) {
        const r1 = sceneScore(mp, zp, s);
        const r2 = sceneScore(mp2, zp2, s);
        if (r1.total !== r2.total) bidirMismatch++;
      }
    }
  }
}
const avgDiff = diffSum / totalScored;

console.log(`  完成：${totalScored.toLocaleString()} 组 × 3 场景评分`);
console.log('  恋爱分布:', Object.entries(dist.love).map(([k, v]) => `${k} ${(v * 100 / totalScored).toFixed(1)}%`).join(' | '));
console.log('  友谊分布:', Object.entries(dist.friend).map(([k, v]) => `${k} ${(v * 100 / totalScored).toFixed(1)}%`).join(' | '));
console.log('  职场分布:', Object.entries(dist.work).map(([k, v]) => `${k} ${(v * 100 / totalScored).toFixed(1)}%`).join(' | '));

/* ---- 5. 分布目标判定 ---- */
report.push('');
report.push(`## 四、评分分布（全量 ${totalScored.toLocaleString()} 有序组合 × 3 场景）`);
report.push('');
report.push('| 等级 | 恋爱实际 | 恋爱目标 | 判定 | 友谊实际 | 友谊目标 | 判定 | 职场实际 | 职场目标 | 判定 |');
report.push('|---|---|---|---|---|---|---|---|---|---|');
const distResults = {};
for (const L of LEVELS) {
  const level = L.name;
  const cells = [];
  for (const s of SCENES) {
    const pct = dist[s][level] * 100 / totalScored;
    const t = targets[level][s];
    const ok = t && pct >= t.min && pct <= t.max;
    if (t) check(ok, `${SCENE_CN[s]}「${level}」占比 ${pct.toFixed(1)}% ∈ [${t.min}%, ${t.max}%]`);
    cells.push(`${pct.toFixed(1)}%`, t ? `${t.min}%~${t.max}%` : '—', ok ? '✅' : '❌');
    if (!distResults[s]) distResults[s] = {};
    distResults[s][level] = pct;
  }
  report.push('| ' + [level, ...cells].join(' | ') + ' |');
}

/* ---- 6. 客观性硬规则 ---- */
report.push('');
report.push('## 五、客观性硬规则（9.8 校验规则 1-3）');
report.push('');
for (const s of SCENES) {
  const low = dist[s]['挑战满满'] * 100 / totalScored;
  const high = dist[s]['天作之合'] * 100 / totalScored;
  check(low >= 8, `${SCENE_CN[s]}「挑战满满」占比 ${low.toFixed(1)}% ≥ 8%（低分真实存在）`);
  check(high <= 20, `${SCENE_CN[s]}「天作之合(90+)」占比 ${high.toFixed(1)}% ≤ 20%（高分稀缺）`);
  report.push(`- ${SCENE_CN[s]}：挑战满满 ${low.toFixed(1)}% ｜ 天作之合 ${high.toFixed(1)}%`);
}
check(avgDiff >= 10, `场景分化均值 ${avgDiff.toFixed(1)} 分 ≥ 10（场景真实影响结果）`);
report.push(`- 场景分化均值：${avgDiff.toFixed(1)} 分（|love-friend|+|love-work|+|friend-work| 的全量平均，目标 ≥ 10）`);

/* ---- 7. 双向 key & 稳定性 ---- */
report.push('');
report.push('## 六、一致性与稳定性（9.9 规则 3/5）');
report.push('');
check(bidirMismatch === 0, '双向 key：A×B 与 B×A 全部一致');
report.push(`- 双向 key 对称比较：${bidirMismatch} 处不一致（应 0）`);

// 稳定性：抽 500 组重算两次比较
let seed = 42;
function rnd() { seed = (seed * 1664525 + 1013904223) % 4294967296; return seed / 4294967296; }
let stableOk = true;
for (let k = 0; k < 500; k++) {
  const i = Math.floor(rnd() * N), j = Math.floor(rnd() * N);
  const pa = picks[i], pb = picks[j];
  const mp = lookupPair(mbtiTemplate, pa.mbti, pb.mbti);
  const zp = lookupPair(zodiacTemplate, pa.zodiac, pb.zodiac);
  for (const s of SCENES) {
    if (sceneScore(mp, zp, s).total !== sceneScore(mp, zp, s).total) stableOk = false;
  }
}
check(stableOk, '稳定性：抽样 500 组 × 3 场景，两次调用完全一致');
report.push('- 稳定性：抽样 500 组 × 3 场景，两次调用完全一致 ✅（评分纯函数无随机；交叉句稳定性由 hash seed 保证，score.js 阶段验证）');

/* ---- 8. 结论 ---- */
report.push('');
report.push('## 七、结论');
report.push('');
const allOk = fail.length === 0;
report.push(allOk
  ? '✅ **全部校验通过 —— 评价表文档合格，可接入 result 页。**'
  : `❌ **存在 ${fail.length} 项未达标，需修正文档后重跑。**`);
report.push('');
report.push('---');
report.push('');
report.push('> 本报告由 `tools/build-data.js` 自动生成。数据源：`text/MBTI星座组合评价表.md`。');
report.push('> 生成时间：' + new Date().toLocaleString('zh-CN'));

/* ---- 9. 输出 ---- */
fs.writeFileSync(REPORT_PATH, report.join('\n'), 'utf8');
console.log('\n校验报告已写入: tools/校验报告.md');
console.log(allOk ? '\n✅ 全部通过 —— 评价表文档合格，可接入 result 页。' : `\n❌ ${fail.length} 项未达标，需修正文档后重跑。`);
for (const f of fail) console.log('  ❌ ' + f);
process.exit(allOk ? 0 : 1);
