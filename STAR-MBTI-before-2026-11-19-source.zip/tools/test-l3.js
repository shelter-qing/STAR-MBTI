#!/usr/bin/env node
/**
 * tools/test-l3.js — L3 文案多样化层回归测试（第十二章验收标准）
 *
 * 校验项（12.9）：
 *   1. 评分分布：全量 192×192×3 与独立公式逐一对算（评分逻辑零改动）
 *   2. 三场景示例：第十一章三组示例的 score / level / nickname 对齐
 *   3. 稳定性：抽样 500 组 × 3 场景，连续调用 3 次输出 100% 一致
 *   4. 重复率：随机采样 500 对组合，结果页实际展示文案句级重复率
 *   5. 命名度：输出文案含具体标识（MBTI代码/星座名/特质词/组合昵称）占比
 *
 * 用法：node tools/test-l3.js
 */

'use strict';

const path = require('path');
const { calculateCompatibility } = require('../utils/score');
const { MBTI_TYPES, ZODIACS } = require('../utils/helper');
const MBTI_PAIRS = require('../data/mbti-pairs');
const ZODIAC_PAIRS = require('../data/zodiac-pairs');
const MBTI_PREMIUM = require('../data/mbti-premium');
const ZODIAC_PREMIUM = require('../data/zodiac-premium');
const ENGINE = require('../data/scene-engine');

const SCENES = ENGINE.scenes;
const pass = [], fail = [];
function check(cond, label) {
  (cond ? pass : fail).push(label);
  console.log((cond ? '  ✅ ' : '  ❌ ') + label);
}

/* ---------- 1. 评分回归：独立公式逐一对算 ---------- */
console.log('\n[1] 评分回归（192×192×3 = 110,592 次对算）…');
const DIM_BUCKETS = ENGINE.dimBuckets;
const DIM_OF = {};
for (const [dim, types] of Object.entries(DIM_BUCKETS)) {
  for (const t of types) DIM_OF[t] = dim.replace('型', '');
}
const DIM_PRIORITY = { '理性': 0, '感性': 1, '控制': 2, '自由': 3 };
const ELEMENT_PRIORITY = { '火': 0, '土': 1, '风': 2, '水': 3 };
const clamp = (n) => Math.max(ENGINE.formula.min, Math.min(ENGINE.formula.max, n));
const pairKey = (a, b) => [a, b].sort().join('_x_');
const collideKey = (x, y, p) => (p[x] <= p[y] ? [x, y] : [y, x]).join('×');

let scoreMismatch = 0;
const picks = [];
for (let i = 0; i < 16; i++) for (let j = 0; j < 12; j++) picks.push({ m: i, z: j });
const N = picks.length;
for (let i = 0; i < N && scoreMismatch < 5; i++) {
  for (let j = 0; j < N && scoreMismatch < 5; j++) {
    const pa = picks[i], pb = picks[j];
    const tA = MBTI_TYPES[pa.m], tB = MBTI_TYPES[pb.m];
    const zA = ZODIACS[pa.z].name.replace('座', ''), zB = ZODIACS[pb.z].name.replace('座', '');
    const mRec = MBTI_PREMIUM[pairKey(tA, tB)] || MBTI_PAIRS[pairKey(tA, tB)];
    const zRec = ZODIAC_PREMIUM[pairKey(zA, zB)] || ZODIAC_PAIRS[pairKey(zA, zB)];
    const pk = collideKey(DIM_OF[tA], DIM_OF[tB], DIM_PRIORITY);
    const ek = collideKey(ENGINE.zodiacElement[zA], ENGINE.zodiacElement[zB], ELEMENT_PRIORITY);
    for (const s of SCENES) {
      const expect = Math.round(
        clamp(mRec.base + ENGINE.personaCollide[pk][s]) * ENGINE.formula.mbtiWeight +
        clamp(zRec.base + ENGINE.elementCollide[ek][s]) * ENGINE.formula.zodiacWeight
      );
      const got = calculateCompatibility(pa.m, pa.z, pb.m, pb.z, s);
      if (got.score !== expect) scoreMismatch++;
    }
  }
}
check(scoreMismatch === 0, `评分与独立公式全量一致（不一致 ${scoreMismatch} 处）`);

/* ---------- 2. 第十一章三示例对齐 ---------- */
console.log('\n[2] 第十一章三示例（score / level / nickname）…');
const examples = [
  { name: 'INTJ·天蝎 × ENFP·狮子', mA: 0, zA: 7, mB: 7, zB: 4,
    love: [82, '默契搭档', '双星恋人'], friend: [72, '互补成长', '趣味相投'], work: [76, '互补成长', '靠谱队友'] },
  { name: 'INTJ·处女 × ENTP·摩羯', mA: 0, zA: 5, mB: 3, zB: 9,
    love: [86, '默契搭档', '双星恋人'], friend: [90, '天作之合', '生死之交'], work: [96, '天作之合', '黄金搭档'] },
  { name: 'INTJ·金牛 × ESFP·水瓶', mA: 0, zA: 1, mB: 15, zB: 10,
    love: [46, '挑战满满', '平行宇宙'], friend: [47, '挑战满满', '点头之交'], work: [51, '挑战满满', '合作困难'] }
];
for (const ex of examples) {
  let ok = true;
  for (const s of SCENES) {
    const r = calculateCompatibility(ex.mA, ex.zA, ex.mB, ex.zB, s);
    if (r.score !== ex[s][0] || r.level !== ex[s][1] || r.nickname !== ex[s][2]) {
      ok = false;
      console.log(`    ${ex.name} ${s}: 期望 ${ex[s]}，实际 ${r.score}/${r.level}/${r.nickname}`);
    }
  }
  check(ok, `${ex.name}：三场景分数/等级/命名全部对齐`);
}

/* ---------- 3. 稳定性 ---------- */
console.log('\n[3] 稳定性（500 组 × 3 场景 × 3 次调用）…');
let seed = 42;
function rnd() { seed = (seed * 1664525 + 1013904223) % 4294967296; return seed / 4294967296; }
let stableOk = true;
const samples = [];
for (let k = 0; k < 500; k++) {
  const i = Math.floor(rnd() * N), j = Math.floor(rnd() * N);
  const s = SCENES[Math.floor(rnd() * 3)];
  samples.push({ pa: picks[i], pb: picks[j], s });
  const a = JSON.stringify(calculateCompatibility(picks[i].m, picks[i].z, picks[j].m, picks[j].z, s));
  const b = JSON.stringify(calculateCompatibility(picks[i].m, picks[i].z, picks[j].m, picks[j].z, s));
  const c = JSON.stringify(calculateCompatibility(picks[i].m, picks[i].z, picks[j].m, picks[j].z, s));
  if (a !== b || b !== c) stableOk = false;
}
check(stableOk, '同一组合同一场景连续调用 3 次，输出 100% 一致');

/* ---------- 4. 重复率（用户会话视角） ---------- */
console.log('\n[4] 重复率（200 个模拟用户 × 每人连续查看 10 对随机组合）…');
// 单次查看的句子集：summary1 + 契合4 + 磨合4 + advice4 = 13 句
function viewSentences(pa, pb, s) {
  const r = calculateCompatibility(pa.m, pa.z, pb.m, pb.z, s);
  return [r.summary, ...r.fitItems.map(item => item.detail), ...r.grindItems.map(item => item.detail), ...r.adviceText.split('\n')];
}
const sessionRates = [];
for (let u = 0; u < 200; u++) {
  const seen = {};
  let total = 0;
  for (let v = 0; v < 10; v++) {
    const pa = picks[Math.floor(rnd() * N)], pb = picks[Math.floor(rnd() * N)];
    const s = SCENES[Math.floor(rnd() * 3)];
    for (const t of viewSentences(pa, pb, s)) { total++; seen[t] = (seen[t] || 0) + 1; }
  }
  let dup = 0;
  for (const c of Object.values(seen)) dup += c - 1;
  sessionRates.push(dup / total * 100);
}
sessionRates.sort((a, b) => a - b);
const avgRate = sessionRates.reduce((a, b) => a + b, 0) / sessionRates.length;
const p95 = sessionRates[Math.floor(sessionRates.length * 0.95)];
const maxR = sessionRates[sessionRates.length - 1];
console.log(`    会话内重复率：均值 ${avgRate.toFixed(2)}% ｜ P95 ${p95.toFixed(2)}% ｜ 最大 ${maxR.toFixed(2)}%（每人 130 句）`);
console.log(`    对照：旧版同一场景的摘要、标题和共同建议高度复用`);
check(avgRate < 10, `会话内重复率均值 ${avgRate.toFixed(2)}% < 10%`);

// 组合唯一性：500 对采样中，不同 (MBTI对, 星座对, 场景) 的完整输出不得相同
// 注：配对为无序（A×B 与 B×A 是同一组合，双向一致是既有验收规则），key 需归一化
const fullOutputs = {};
let uniqViolation = 0;
for (const { pa, pb, s } of samples) {
  const key = [[pa.m, pa.z], [pb.m, pb.z]].sort((x, y) => (x[0] - y[0]) || (x[1] - y[1])).map(p => p.join('.')).join('_x_') + '_' + s;
  const out = JSON.stringify(viewSentences(pa, pb, s));
  if (fullOutputs[key] === undefined) {
    // 该组合首次出现：完整输出不应与任何其他组合撞车
    if (Object.values(fullOutputs).includes(out)) uniqViolation++;
    fullOutputs[key] = out;
  }
}
check(uniqViolation === 0, `500 对采样中不同组合完整输出零撞车（撞车 ${uniqViolation} 处）`);

// advice 多样性：500 次查看的去重评语文本数
const adviceSeen = new Set();
for (const { pa, pb, s } of samples) {
  adviceSeen.add(calculateCompatibility(pa.m, pa.z, pb.m, pb.z, s).adviceText);
}
console.log(`    advice 去重后 ${adviceSeen.size} 种`);
check(adviceSeen.size > 300, `advice 多样性：500 次查看产生 ${adviceSeen.size} 种不同建议（>300）`);

/* ---------- 5. 命名度（含具体标识的句子占比） ---------- */
console.log('\n[5] 命名度（含 MBTI代码/星座名/「特质词·昵称」/维度词标识）…');
const zNames = ZODIACS.map(z => z.name.replace('座', ''));
const IDENT_RE = new RegExp('(' + MBTI_TYPES.join('|') + '|' + zNames.join('|') + '|「|理性|感性|控制|自由)');
let named = 0, namedTotal = 0;
const unnamedExamples = [];
for (const { pa, pb, s } of samples) {
  const report = calculateCompatibility(pa.m, pa.z, pb.m, pb.z, s);
  const namedSentences = [report.summary, ...report.fitItems.map(item => item.detail), ...report.grindItems.map(item => item.detail)];
  for (const t of namedSentences) {
    namedTotal++;
    if (IDENT_RE.test(t)) named++;
    else if (unnamedExamples.length < 5) unnamedExamples.push(t);
  }
}
const namedRate = named / namedTotal * 100;
console.log(`    命名度：${named}/${namedTotal} = ${namedRate.toFixed(1)}%`);
for (const t of unnamedExamples) console.log(`    未命名示例: ${t.slice(0, 50)}…`);
check(namedRate >= 80, `结果页主体文案命名度 ${namedRate.toFixed(1)}% >= 80%`);

/* ---------- 结果 ---------- */
console.log('\n========================================');
console.log(fail.length === 0 ? '✅ L3 文案多样化层全部验收通过' : `❌ ${fail.length} 项未达标`);
for (const f of fail) console.log('  ❌ ' + f);
process.exit(fail.length === 0 ? 0 : 1);
