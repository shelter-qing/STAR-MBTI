#!/usr/bin/env node
'use strict';
const fs = require('fs');
const path = require('path');
const ROOT = path.resolve(__dirname, '..');
const md = fs.readFileSync(path.join(ROOT, 'text', 'MBTI星座组合评价表.md'), 'utf8');
function extractTable(startKw, endKw) {
  const s = md.indexOf(startKw);
  const e = endKw ? md.indexOf(endKw, s + startKw.length) : md.length;
  const lines = md.slice(s, e).split('\n').filter(l => l.trim().startsWith('|'));
  const header = lines[0].split('|').map(c => c.trim()).filter(Boolean);
  const rows = [];
  for (let i = 2; i < lines.length; i++) {
    const cells = lines[i].split('|').map(c => c.trim());
    const obj = {};
    header.forEach((h, j) => { obj[h] = cells[j + 1] !== undefined ? cells[j + 1] : ''; });
    if (Object.values(obj).some(v => v)) rows.push(obj);
  }
  return rows;
}
function parsePairs(rows) {
  const m = {};
  for (const r of rows) {
    const p = r['组合'].split('×').map(s => s.trim());
    m[[p[0], p[1]].sort().join('_x_')] = { a: p[0], b: p[1], base: parseInt(r['评分'], 10) };
  }
  return m;
}
function normKey(a, b) { return [a, b].sort().join('_x_'); }
const mbtiT = parsePairs(extractTable('## 六、MBTI 模板配对', '## 七、'));
const zodiacT = parsePairs(extractTable('## 七、星座模板配对', '## 八、'));
const mbtiP = parsePairs(extractTable('## 四、MBTI 精品配对', '## 五、'));
const zodiacP = parsePairs(extractTable('## 五、星座精品配对', '## 六、'));

function stats(name, tpl, pre) {
  const preKeys = new Set(Object.keys(pre));
  const vals = Object.values(tpl).map(r => r.base).sort((a, b) => a - b);
  const n = vals.length;
  const pct = p => vals[Math.min(n - 1, Math.floor(p * n))];
  const tie = {};
  for (const v of vals) tie[v] = (tie[v] || 0) + 1;
  const ties = Object.entries(tie).sort((a, b) => b[1] - a[1]).slice(0, 8);
  console.log(`\n=== ${name} ===  共 ${n} 条`);
  console.log(`min ${vals[0]} | p10 ${pct(0.1)} | p25 ${pct(0.25)} | p50 ${pct(0.5)} | p75 ${pct(0.75)} | p90 ${pct(0.9)} | max ${vals[n - 1]}`);
  console.log(`<60: ${vals.filter(v => v < 60).length} 条 | 60-69: ${vals.filter(v => v >= 60 && v < 70).length} 条 | 70-79: ${vals.filter(v => v >= 70 && v < 80).length} 条 | 80-89: ${vals.filter(v => v >= 80 && v < 90).length} 条 | 90+: ${vals.filter(v => v >= 90).length} 条`);
  console.log('最高频同分:', ties.map(([v, c]) => `${v}分×${c}条`).join(', '));
  const preVals = Object.values(pre).map(r => r.base).sort((a, b) => a - b);
  console.log(`精品层: ${preVals.length} 条, 分值 ${preVals[0]} ~ ${preVals[preVals.length - 1]}`);
  const np = Object.values(tpl).filter(r => !preKeys.has(normKey(r.a, r.b))).map(r => r.base).sort((a, b) => a - b);
  console.log(`非精品 ${np.length} 条: min ${np[0]} ~ max ${np[np.length - 1]}`);
}
stats('MBTI 模板', mbtiT, mbtiP);
stats('星座 模板', zodiacT, zodiacP);
