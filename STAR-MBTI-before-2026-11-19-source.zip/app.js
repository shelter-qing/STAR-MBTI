// app.js
const FONT_FAMILY = 'HYDaSongJ-2';

/**
 * 加载全局字体。
 * 微信小程序不支持 CSS @font-face 加载本地文件，必须用 wx.loadFontFace。
 * - source 本地路径：微信开发者工具支持（调试用）
 * - 真机预览/体验版：source 必须为 https 网络地址或 base64，
 *   届时替换 FONT_SOURCE（见下方备用注释），或由构建脚本注入。
 *
 * 当前采用「子集化 + base64 内嵌」：
 *   全量字体 4.38MB 超主包 2MB 限制，由 tools/subset-font.py 裁出
 *   项目实际用字(1638 字符)生成 utils/font-face-data.js(约 537KB)。
 *   注意：新增/修改文案后需重跑 python tools/subset-font.py，否则真机会缺字。
 */
const FONT_SOURCE = 'url("' + require('./utils/font-face-data') + '")';
// 真机备用（网络字体，需自行托管后启用，可省去主包 537KB）：
// const FONT_SOURCE = 'url("https://your-host/HYDaSongJ-2-subset.woff2")';

const SOUND_SOURCES = {
  tick: '/assets/audio/gear-tick.wav',
  confirm: '/assets/audio/hit.wav'
};
const SOUND_VOLUMES = { tick: 0.065, confirm: 0.095 };
const SOUND_POOL_SIZE = 3;

function loadFont() {
  if (!wx.loadFontFace) return;
  wx.loadFontFace({
    family: FONT_FAMILY,
    source: FONT_SOURCE,
    global: true,
    scopes: ['webview', 'native'], // native 让 canvas 进度环也能用该字体
    fail(err) {
      // 失败不阻塞业务，自动走系统衬线体兜底
      console.warn('[font] loadFontFace fail:', err && err.errMsg);
    }
  });
}

App({
  globalData: {
    fontFamily: FONT_FAMILY,
    guideEntryId: 0,
    soundPools: {},
    soundCursors: {}
  },

  onLaunch() {
    loadFont();
    this._initSounds();
    // 纯前端工具，不登录、不采集任何用户信息
  },

  onShow() {
    this.globalData.guideEntryId += 1;
    if (typeof getCurrentPages !== 'function') return;
    const pages = getCurrentPages();
    const page = pages[pages.length - 1];
    if (page && typeof page.onAppEntry === 'function') page.onAppEntry();
  },

  _initSounds() {
    this.globalData.soundPools = {};
    this.globalData.soundCursors = {};
  },

  _getSoundPool(name) {
    if (!wx.createInnerAudioContext || !SOUND_SOURCES[name]) return [];
    if (this.globalData.soundPools[name]) return this.globalData.soundPools[name];
    const pool = [];
    for (let index = 0; index < SOUND_POOL_SIZE; index += 1) {
      const context = wx.createInnerAudioContext();
      context.src = SOUND_SOURCES[name];
      context.volume = SOUND_VOLUMES[name];
      if (typeof context.onError === 'function') {
        context.onError(error => {
          console.warn('[sound] playback failed:', error && (error.errMsg || error.message));
        });
      }
      pool.push(context);
    }
    this.globalData.soundPools[name] = pool;
    this.globalData.soundCursors[name] = 0;
    return pool;
  },

  playSound(name) {
    const pool = this._getSoundPool(name);
    if (!pool.length) return;
    const cursor = this.globalData.soundCursors[name] || 0;
    const context = pool[cursor % pool.length];
    this.globalData.soundCursors[name] = (cursor + 1) % pool.length;
    try {
      context.stop();
      context.play();
    } catch (error) {
      // 音效失败不应影响页面交互。
      console.warn('[sound] playback failed:', error && (error.errMsg || error.message));
    }
  }
});
