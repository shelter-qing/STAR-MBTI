# CloudBase 环境

本项目需要两个 CloudBase 环境：

- `test`：开发版和体验版使用，可以反复测试。
- `production`：正式版使用，只部署已经确认的版本。

## 创建环境

1. 用绑定了小程序 `wxd24abb8e618488b6` 的微信账号登录微信开发者工具。
2. 打开“云开发”面板，创建一个环境，名称建议为 `mbti-star-test`。
3. 再创建一个环境，名称建议为 `mbti-star-production`。
4. 把两个环境的环境 ID 填入 `cloudbase/env.json`。

`env.json` 是本机配置，不要提交到 Git。可以从 `cloudbase/env.example.json` 复制一份。

创建环境后，先只接入测试环境。正式环境在候选版本确认后再使用。
