'use strict';

const assert = require('assert');
const fs = require('fs');
const path = require('path');

assert(fs.existsSync(path.join(__dirname, '../assets/audio/gear-tick.wav')));
assert(fs.existsSync(path.join(__dirname, '../assets/audio/hit.wav')));
const indexWxml = fs.readFileSync(path.join(__dirname, '../pages/index/index.wxml'), 'utf8');
assert(!indexWxml.includes('music-toggle') && !indexWxml.includes('onToggleMusic'),
  'The home page should not expose a background music control');
assert(!indexWxml.includes('sound-toggle') && !indexWxml.includes('onToggleSound'),
  'Interaction sounds should not have a UI switch');
const projectConfig = JSON.parse(fs.readFileSync(path.join(__dirname, '../project.config.json'), 'utf8'));
assert(projectConfig.packOptions.ignore.some(item => item.value === 'music' && item.type === 'folder'),
  'Large local preview tracks must stay out of uploaded mini-program packages');

const contexts = [];
global.wx = {
  getStorageSync() { return false; }, // A previous mute preference must not disable effects.
  setStorageSync() {},
  createInnerAudioContext() {
    const calls = [];
    const handlers = {};
    const context = {
      calls,
      handlers,
      onPlay() {}, onPause() {}, onStop() {}, onEnded(callback) { handlers.ended = callback; }, onError() {},
      stop() { calls.push('stop'); },
      play() { calls.push('play'); },
      pause() { calls.push('pause'); }
    };
    contexts.push(context);
    return context;
  }
};

let app;
global.App = definition => { app = definition; };
require('../app');
app.onLaunch();

assert.strictEqual(contexts.length, 0, 'Background music is disabled');

let guideEntryNotifications = 0;
const homePage = { onAppEntry() { guideEntryNotifications += 1; } };
global.getCurrentPages = () => [homePage];
app.onShow();
assert.strictEqual(app.globalData.guideEntryId, 1);
assert.strictEqual(guideEntryNotifications, 1, 'An app entry should notify the visible home page');
global.getCurrentPages = () => [homePage, { route: 'pages/result/result' }];
app.onShow();
assert.strictEqual(app.globalData.guideEntryId, 2);
assert.strictEqual(guideEntryNotifications, 1, 'An app entry on the report must not manipulate the hidden home page');
global.getCurrentPages = () => [];
app.onShow();
assert.strictEqual(app.globalData.guideEntryId, 3, 'Cold launch entries should be counted before pages exist');
delete global.getCurrentPages;

app.playSound('tick');
assert.strictEqual(contexts.length, 3, 'The tick pool is created only when first needed');
assert.deepStrictEqual(contexts[0].calls, ['stop', 'play']);
assert.strictEqual(contexts[0].volume, 0.065, 'Keep the quiet tick volume');
app.playSound('tick');
app.playSound('tick');
app.playSound('tick');
assert.deepStrictEqual(contexts[0].calls, ['stop', 'play', 'stop', 'play'],
  'Rapid effects rotate through the reusable player pool');

app.playSound('confirm');
assert.strictEqual(contexts.length, 6, 'The confirmation pool is also lazy');
assert.deepStrictEqual(contexts[3].calls, ['stop', 'play'],
  'Confirmation sounds also play regardless of the old mute preference');
assert.strictEqual(contexts[3].volume, 0.095, 'Keep the quiet confirmation volume');

console.log('Interaction audio checks passed.');
