'use strict';

const assert = require('assert');
const fs = require('fs');
const path = require('path');

const privateConfig = JSON.parse(fs.readFileSync(path.join(__dirname, '../project.private.config.json'), 'utf8'));
assert.strictEqual(privateConfig.setting.compileHotReLoad, false, 'DevTools must rebuild changed asset dependencies');
assert.strictEqual(privateConfig.setting.ignoreDevUnusedFiles, true, 'DevTools must omit unreferenced design assets');
assert(!privateConfig.packOptions, 'Private config must not override the shared package ignore list');
const projectConfig = JSON.parse(fs.readFileSync(path.join(__dirname, '../project.config.json'), 'utf8'));
assert(projectConfig.packOptions.ignore.some(item => item.value === '.tmp-check' && item.type === 'folder'),
  'Shared package rules must exclude temporary render artifacts');
assert(projectConfig.packOptions.ignore.some(item => item.value === 'assets/refer/bubble/mbti-bubbles' && item.type === 'folder'),
  'Shared package rules must exclude only the unused small bubble folder');
const indexWxml = fs.readFileSync(path.join(__dirname, '../pages/index/index.wxml'), 'utf8');
const indexWxss = fs.readFileSync(path.join(__dirname, '../pages/index/index.wxss'), 'utf8');
assert(indexWxss.includes('transform: translateY(80rpx)'), 'The composed home UI should shift down as one unit');
['purple-ring1', 'purple-ring2', 'purple-ring3', 'blue-ring1', 'blue-ring2', 'blue-ring3'].forEach(name => {
  assert(indexWxml.includes(`assets/refer/bubble/ring/${name}.png`), `Wheel ring must use PNG fallback: ${name}`);
  assert(fs.existsSync(path.join(__dirname, '../assets/refer/bubble/ring', `${name}.png`)), `Missing wheel ring asset: ${name}`);
});

let indexPage;
global.Page = definition => { indexPage = definition; };
require('../pages/index/index.js');
['bubblesA', 'bubblesB', 'starBubblesA', 'starBubblesB'].forEach(key => {
  indexPage.data[key].forEach(item => {
    assert(item.file.endsWith('.png'), `Unexpected image format for ${item.file}`);
    assert(fs.existsSync(path.resolve(__dirname, '../pages/index', item.file)), `Missing dynamic image asset: ${item.file}`);
  });
});

function loadComponent(relativePath) {
  let definition;
  global.Component = value => { definition = value; };
  const file = path.join(__dirname, '..', relativePath);
  delete require.cache[require.resolve(file)];
  require(file);
  assert(definition, `${relativePath} did not register a component`);
  return definition;
}

global.wx = {};
assert(indexWxml.includes('class="guide-overlay"'), 'The guide should annotate the home screen');
assert(indexWxml.includes('catchtouchmove="stopGuideTouch"'), 'The guide must block background gestures');
assert(indexWxml.includes('旋转轮盘，选择双方 MBTI 与星座'), 'Step one should explain wheel selection');
assert(indexWxml.includes('选好后，点击确定选型'), 'Step two should explain confirmation');
assert(indexWxml.includes('catchtap="onGuideNext"'), 'The guide must offer a next/finish action');
assert(indexWxml.includes("guideStep === 0 ? '下一步' : '开始探索'"), 'Use the revised primary action labels');
assert(indexWxml.includes('catchtouchmove="onGuideTouchMove"'), 'The guide card and wheel practice areas should accept swipes');
assert(!indexWxml.includes('guide-action-focus') && !indexWxml.includes('guide-back'), 'Remove duplicate actions and the back button');
['block_10', 'block_11'].forEach(name => {
  assert(indexWxml.includes(`wx:if="{{!guideVisible}}" class="${name}"`), 'Hide underlying home actions during the guide');
});
assert(indexWxml.includes('class="guide-progress"'), 'The guide should show two-step progress');
assert(!indexWxml.includes('guide-dismiss'), 'The old corner dismiss action should be removed');
['wheel-arrows.png', 'swipe-hand.png', 'connector.png', 'spark.png', 'chevron.png', 'divider.png', 'wheel-spotlight.png'].forEach(name => {
  assert(fs.existsSync(path.join(__dirname, '../assets/guide', name)), `Missing guide artwork: ${name}`);
});

const guideStorage = new Map();
const guideConfig = require('../utils/guide-config');
const configuredRepeatMode = guideConfig.repeatOnEntry;
guideConfig.repeatOnEntry = false;
const guideApp = { globalData: { guideEntryId: 1 } };
global.getApp = () => guideApp;
wx.getStorageSync = key => guideStorage.get(key);
wx.setStorageSync = (key, value) => guideStorage.set(key, value);
wx.getWindowInfo = () => ({ windowWidth: 375, windowHeight: 667 });
guideStorage.set('mbti-star:guide-seen-v2', true);
function makeIndexPage() {
  return Object.assign({}, indexPage, {
    data: { ...indexPage.data },
    setData(patch) { Object.assign(this.data, patch); }
  });
}
const firstVisitPage = makeIndexPage();
firstVisitPage.onLoad();
assert.strictEqual(firstVisitPage.data.guideVisible, true, 'Existing users should see the revised guide once');
assert.strictEqual(firstVisitPage.data.guideStep, 0);
assert(firstVisitPage.data.guideScale * 1584 <= 667 * 2, 'The guide must fit short screens');
firstVisitPage.onGuideNext();
assert.strictEqual(firstVisitPage.data.guideStep, 1);
assert.strictEqual(firstVisitPage.data.guideVisible, true);
assert.strictEqual(guideStorage.has('mbti-star:guide-seen-v3'), false, 'Step one must not mark the whole guide complete');
firstVisitPage.onGuideNext();
assert.strictEqual(firstVisitPage.data.guideVisible, false);
assert.strictEqual(guideStorage.get('mbti-star:guide-seen-v3'), true);

const returningPage = makeIndexPage();
returningPage.onLoad();
assert.strictEqual(returningPage.data.guideVisible, false, 'Completed guides should stay closed');
const reviewPage = makeIndexPage();
reviewPage.onLoad({ guide: '1' });
assert.strictEqual(reviewPage.data.guideVisible, true, 'The review query should reopen the guide');
assert.strictEqual(reviewPage.data.guideStep, 0);
const originalRot = reviewPage.data.rotA_mbti;
reviewPage.onRandom();
reviewPage.onSubmit();
assert.strictEqual(reviewPage.data.rotA_mbti, originalRot, 'The overlay should prevent background randomization');
assert.strictEqual(reviewPage.data.submitting, false, 'The overlay should prevent background navigation');
reviewPage.onGuideNext();
reviewPage.onGuideNext();
assert.strictEqual(reviewPage.data.guideVisible, false);
const storageFailurePage = makeIndexPage();
storageFailurePage.onLoad({ guide: '1' });
const saveGuidePreference = wx.setStorageSync;
wx.setStorageSync = () => { throw new Error('storage unavailable'); };
storageFailurePage.onGuideNext();
storageFailurePage.onGuideNext();
assert.strictEqual(storageFailurePage.data.guideVisible, false, 'Storage failures must not trap users in the guide');
wx.setStorageSync = saveGuidePreference;

function touchEvent(x, y, which) {
  return { touches: [{ clientX: x, clientY: y }], currentTarget: { dataset: which ? { which } : {} } };
}
function endTouch(x, y) {
  return { changedTouches: [{ clientX: x, clientY: y }] };
}
for (const endX of [30, 160]) {
  const swipePage = makeIndexPage();
  swipePage.onLoad({ guide: '1' });
  swipePage.onGuideTouchStart(touchEvent(100, 200));
  swipePage.onGuideTouchMove(touchEvent(endX, 202));
  swipePage.onGuideTouchEnd(endTouch(endX, 202));
  assert.strictEqual(swipePage.data.guideStep, 1, 'Swiping either direction must advance to step two');
  assert.strictEqual(swipePage.data.guideVisible, true, 'A swipe must not dismiss both steps');
  swipePage.onGuideTouchEnd(endTouch(endX, 202));
  swipePage.onGuideTouchStart(touchEvent(100, 200));
  swipePage.onGuideTouchEnd(endTouch(160, 200));
  assert.strictEqual(swipePage.data.guideVisible, true, 'Step two must require the explicit start action');
}
for (const [endX, endY] of [[104, 201], [110, 290], [160, 280]]) {
  const rejectedSwipe = makeIndexPage();
  rejectedSwipe.onLoad({ guide: '1' });
  rejectedSwipe.onGuideTouchStart(touchEvent(100, 200));
  rejectedSwipe.onGuideTouchMove(touchEvent(endX, endY));
  rejectedSwipe.onGuideTouchEnd(endTouch(endX, endY));
  assert.strictEqual(rejectedSwipe.data.guideStep, 0, 'Taps, vertical movement and steep diagonals must not advance');
}
const cancelledSwipe = makeIndexPage();
cancelledSwipe.onLoad({ guide: '1' });
cancelledSwipe.onGuideTouchStart(touchEvent(100, 200));
cancelledSwipe.onGuideTouchMove(touchEvent(160, 201));
cancelledSwipe.onGuideTouchCancel();
cancelledSwipe.onGuideTouchEnd(endTouch(160, 201));
assert.strictEqual(cancelledSwipe.data.guideStep, 0, 'Cancelled swipes must not advance');
const multiTouchSwipe = makeIndexPage();
multiTouchSwipe.onLoad({ guide: '1' });
multiTouchSwipe.onGuideTouchStart(touchEvent(100, 200));
const multipleTouches = touchEvent(160, 200);
multipleTouches.touches.push({ clientX: 200, clientY: 200 });
multiTouchSwipe.onGuideTouchMove(multipleTouches);
multiTouchSwipe.onGuideTouchEnd(endTouch(160, 200));
assert.strictEqual(multiTouchSwipe.data.guideStep, 0, 'Multi-touch must not accidentally advance');

wx.createSelectorQuery = () => ({
  in() { return this; }, select() { return this; },
  boundingClientRect(callback) { callback({ left: 0, top: 0, width: 200, height: 200 }); return this; },
  exec() {}
});
for (const which of ['A', 'B']) {
  const wheelPractice = makeIndexPage();
  wheelPractice.onLoad({ guide: '1' });
  const rotKey = 'rot' + which + '_mbti';
  const before = wheelPractice.data[rotKey];
  wheelPractice.onGuideTouchStart(touchEvent(150, 25, which));
  wheelPractice.onGuideTouchMove(touchEvent(210, 25, which));
  assert.notStrictEqual(wheelPractice.data[rotKey], before, 'A horizontal practice swipe should turn the actual wheel');
  wheelPractice.onGuideTouchEnd(endTouch(210, 25));
  assert.strictEqual(wheelPractice.data.guideStep, 1);
  assert.strictEqual(wheelPractice.data[rotKey] % (360 / 16), 0, 'The practiced wheel should snap to a valid sector');
  assert.strictEqual(wheelPractice['state' + which].mbtiIdx, wheelPractice._resolvePickMbti(wheelPractice.data[rotKey], which),
    'Practice should update the selected type consistently');
}
delete wx.createSelectorQuery;

guideConfig.repeatOnEntry = true;
const repeatPage = makeIndexPage();
repeatPage.onLoad();
assert.strictEqual(repeatPage.data.guideVisible, true, 'Test mode should show the guide despite a saved completion');
repeatPage.onGuideNext();
repeatPage.onShow();
assert.strictEqual(repeatPage.data.guideStep, 1, 'Page lifecycle callbacks must not reset an active guide');
repeatPage.onGuideNext();
assert.strictEqual(guideStorage.get('mbti-star:guide-seen-v3'), true, 'Test mode must preserve the completion record');
repeatPage.onShow();
assert.strictEqual(repeatPage.data.guideVisible, false, 'Returning from the report in the same entry must not reopen the guide');

guideApp.globalData.guideEntryId += 1;
repeatPage.onAppEntry();
assert.strictEqual(repeatPage.data.guideVisible, true, 'Returning from the background should reopen the guide');
assert.strictEqual(repeatPage.data.guideStep, 0, 'Each app entry should restart at step one');
repeatPage.onGuideNext();
repeatPage.onAppEntry();
repeatPage.onShow();
assert.strictEqual(repeatPage.data.guideStep, 1, 'Duplicate callbacks for the same entry must keep the current step');
repeatPage.onGuideNext();

guideApp.globalData.guideEntryId += 1;
repeatPage.onShow();
assert.strictEqual(repeatPage.data.guideVisible, true, 'An entry while on the report should show the guide on returning home');
const coldEntryPage = makeIndexPage();
coldEntryPage.onLoad();
assert.strictEqual(coldEntryPage.data.guideVisible, true, 'A fresh launch should show the guide in test mode');

guideConfig.repeatOnEntry = false;
const restoredPage = makeIndexPage();
restoredPage.onLoad();
assert.strictEqual(restoredPage.data.guideVisible, false, 'Turning off test mode must restore saved first-visit behavior');
guideApp.globalData.guideEntryId += 1;
restoredPage.onAppEntry();
restoredPage.onShow();
assert.strictEqual(restoredPage.data.guideVisible, false, 'Normal mode must stay closed across app entries after completion');
guideStorage.delete('mbti-star:guide-seen-v3');
const restoredFirstVisit = makeIndexPage();
restoredFirstVisit.onLoad();
assert.strictEqual(restoredFirstVisit.data.guideVisible, true, 'Normal mode must still show the guide to a new user');
guideConfig.repeatOnEntry = configuredRepeatMode;
delete global.getApp;

const ring = loadComponent('components/result-ring/result-ring.js');
const ringWxml = fs.readFileSync(path.join(__dirname, '../components/result-ring/result-ring.wxml'), 'utf8');
const ringWxss = fs.readFileSync(path.join(__dirname, '../components/result-ring/result-ring.wxss'), 'utf8');
assert(!/<canvas\b/i.test(ringWxml), 'The result score ring must not use canvas');
assert(ringWxss.includes('conic-gradient('), 'The score arc should use a CSS gradient');

const timers = new Map();
let timerId = 0;
let now = 0;
const originalSetTimeout = global.setTimeout;
const originalClearTimeout = global.clearTimeout;
const originalNow = Date.now;
function runNextTimer() {
  assert(timers.size > 0, 'Expected an animation timer');
  const [id, callback] = timers.entries().next().value;
  timers.delete(id);
  callback();
}
function makeRing(score = 75) {
  return Object.assign({
    properties: { score },
    data: { ...ring.data },
    callbacks: [],
    setData(patch, callback) {
      Object.assign(this.data, patch);
      if (callback) this.callbacks.push(callback);
    }
  }, ring.methods);
}
try {
  global.setTimeout = callback => { timers.set(++timerId, callback); return timerId; };
  global.clearTimeout = id => timers.delete(id);
  Date.now = () => now;
  const ringInstance = makeRing();
  ring.lifetimes.ready.call(ringInstance);
  ringInstance.callbacks.shift()();
  ring.properties.score.observer.call(ringInstance, 82);
  now += 700;
  runNextTimer();
  assert.strictEqual(ringInstance.data.displayScoreText, '82%');
  assert.strictEqual(ringInstance.data.progressAngle, 295.2);
  assert(ringInstance.data.progressGradient.includes('295.2deg'));
  ring.lifetimes.detached.call(ringInstance);
  assert.strictEqual(timers.size, 0);
} finally {
  global.setTimeout = originalSetTimeout;
  global.clearTimeout = originalClearTimeout;
  Date.now = originalNow;
}

async function runPageTests() {
  let resultPage;
  global.Page = value => { resultPage = value; };
  require('../pages/result/result');
  const viewTicks = [];
  wx.nextTick = callback => viewTicks.push(callback);
  const resultWxml = fs.readFileSync(path.join(__dirname, '../pages/result/result.wxml'), 'utf8');
  const resultWxss = fs.readFileSync(path.join(__dirname, '../pages/result/result.wxss'), 'utf8');
  assert(resultWxml.includes('class="share-modal"'));
  assert(resultWxml.includes('open-type="share"'));
  assert(resultWxml.includes('src="{{sharePosterPath}}"'));
  assert(!/<canvas\b/i.test(resultWxml), 'The result page must not mount a canvas');
  assert(resultWxml.includes('class="page-background"'));
  assert(resultWxss.includes('.page-background'));
  assert(resultWxss.includes('position: fixed'), 'Background must stay attached to the viewport');
  assert(resultWxss.includes('background-image: none'), 'Scrollable content must not own the star-field background');

  function makePage() {
    const page = Object.assign({
      data: { ...resultPage.data },
      setData(patch, callback) { Object.assign(this.data, patch); if (callback) callback(); }
    }, {
      _mountRingWhenReady: resultPage._mountRingWhenReady,
      _ensureSharePoster: resultPage._ensureSharePoster.bind(null),
      onSaveCard: resultPage.onSaveCard
    });
    page._ensureSharePoster = function () { return resultPage._ensureSharePoster.call(this); };
    return page;
  }

  const poster = require('../utils/share-poster');
  const model = poster.cardModel({
    mA: 0, zA: 4, mB: 1, zB: 6, ringScore: 82, scene: 'friend',
    sceneLabel: '友情默契', levelName: '高契合', keyword: '并行宇宙', summary: '关系说明'.repeat(12)
  });
  assert.strictEqual(model.typeA, 'INTJ');
  assert.strictEqual(model.zodiacB, '天秤座');
  assert.strictEqual(model.score, 82);
  const lines = poster.wrappedLines({ measureText(value) { return { width: Array.from(value).length * 20 }; } }, model.summary, 180, 3);
  assert(lines.length <= 3);

  const encoder = require('../utils/vendor/upng');
  const pixels = new Uint8Array(16 * 16 * 4);
  for (let i = 3; i < pixels.length; i += 4) pixels[i] = 255;
  const png = Buffer.from(encoder.encode([pixels.buffer], 16, 16, 0));
  assert.strictEqual(png.toString('hex', 0, 8), '89504e470d0a1a0a');

  const fileStore = new Map();
  const drawEvents = [];
  let failImage = '';
  let failWrite = '';
  let failReadback = false;
  wx.env = { USER_DATA_PATH: '/user-data' };
  const ctx = {
    measureText(value) { return { width: Array.from(String(value)).length * 20 }; },
    createLinearGradient() { return { addColorStop() {} }; },
    createRadialGradient() { return { addColorStop() {} }; },
    beginPath() {}, moveTo() {}, lineTo() {}, arcTo() {}, closePath() {}, arc() {}, fill() { drawEvents.push('fill'); }, stroke() {},
    fillRect() {}, fillText() {}, drawImage(image) { drawEvents.push(image.source); }, putImageData() {}, save() {}, translate() {}, rotate() {}, restore() {},
    getImageData(x, y, width, height) {
      if (failReadback) throw new Error('pixel readback failed');
      const rgba = new Uint8Array(width * height * 4);
      for (let i = 3; i < rgba.length; i += 4) rgba[i] = 255;
      return { data: rgba };
    }
  };
  wx.createOffscreenCanvas = ({ width, height }) => ({
    width, height,
    getContext() { return ctx; },
    createImage() {
      const image = { width: 0, height: 0, onload: null, onerror: null };
      Object.defineProperty(image, 'src', { set(source) {
        image.source = source;
        const bytes = fs.readFileSync(path.join(__dirname, '..', source));
        // Emulate a device decoder that handles JPEG/PNG but rejects WebP.
        const supported = bytes.readUInt16BE(0) === 0xffd8 || bytes.toString('hex', 0, 8) === '89504e470d0a1a0a';
        if (!supported || source === failImage) {
          image.onerror({ errMsg: 'image decode failed' });
          return;
        }
        image.width = 900;
        image.height = 1350;
        image.onload();
      } });
      return image;
    }
  });
  wx.getFileSystemManager = () => ({
    writeFile({ filePath, data, success, fail }) {
      if (failWrite && filePath.includes(failWrite)) return fail({ errMsg: 'writeFile:fail storage error' });
      fileStore.set(filePath, Buffer.from(data));
      success();
    },
    unlink({ filePath }) { fileStore.delete(filePath); }
  });
  const generated = await poster.createPoster(model);
  const planetDrawIndex = drawEvents.indexOf('/images/share/planet-overlay.jpg');
  assert(planetDrawIndex > drawEvents.indexOf('/images/share/poster-bg.jpg'));
  assert(drawEvents.slice(0, planetDrawIndex).includes('fill'), 'Planet artwork must draw above the card overlay');
  assert.strictEqual(Buffer.from(fileStore.get(generated.posterPath)).readUInt32BE(16), poster.WIDTH);
  assert.strictEqual(Buffer.from(fileStore.get(generated.posterPath)).readUInt32BE(20), poster.HEIGHT);
  assert.strictEqual(Buffer.from(fileStore.get(generated.thumbnailPath)).readUInt32BE(16), 500);

  const filesBeforeFailure = fileStore.size;
  failReadback = true;
  await assert.rejects(poster.createPoster(model), error => error.stage === 'png-encode');
  failReadback = false;
  failWrite = 'mbti-thumb-';
  await assert.rejects(poster.createPoster(model), error =>
    error.stage === 'file-write' && error.source.includes('mbti-thumb-') && error.message.includes('storage error'));
  failWrite = '';
  assert.strictEqual(fileStore.size, filesBeforeFailure, 'A failed thumbnail must also remove its completed poster');

  const retryPage = makePage();
  resultPage._renderScene.call(retryPage, 0, 4, 1, 6, 'friend');
  failImage = '/images/share/planet-overlay.jpg';
  const previousConsoleError = console.error;
  const diagnostics = [];
  try {
    console.error = (...args) => diagnostics.push(args);
    await resultPage.onShare.call(retryPage);
  } finally {
    console.error = previousConsoleError;
    failImage = '';
  }
  assert.strictEqual(retryPage.data.shareLoading, false);
  assert.strictEqual(retryPage.data.sharePosterPath, '');
  assert(retryPage.data.shareError.includes('重试'));
  assert.strictEqual(diagnostics[0][1].stage, 'image-load');
  assert.strictEqual(diagnostics[0][1].source, '/images/share/planet-overlay.jpg');
  assert.strictEqual(fileStore.size, filesBeforeFailure);
  await resultPage.onShare.call(retryPage);
  assert(retryPage.data.sharePosterPath, 'Retry should generate a card once the image loads');
  assert.strictEqual(retryPage.data.shareError, '');
  resultPage.onUnload.call(retryPage);

  const page = makePage();
  resultPage._renderScene.call(page, 0, 4, 1, 6, 'friend');
  await resultPage.onShare.call(page);
  assert.strictEqual(page.data.shareVisible, true);
  assert.strictEqual(page.data.sharePosterPath, page._poster.posterPath);
  assert.strictEqual(fileStore.has(page._poster.posterPath), true);
  const payload = resultPage.onShareAppMessage.call(page);
  assert(payload.path.endsWith('&scene=friend'));
  assert.strictEqual(payload.imageUrl, page._poster.thumbnailPath);

  let savedPath = '';
  let toast = '';
  wx.saveImageToPhotosAlbum = options => { savedPath = options.filePath; options.success(); };
  wx.showToast = options => { toast = options.title; };
  await resultPage.onSaveCard.call(page);
  assert.strictEqual(savedPath, page._poster.posterPath);
  assert.strictEqual(toast, '已保存到相册');

  let settingsPrompted = false;
  const oldPosterPath = page._poster.posterPath;
  resultPage._renderScene.call(page, 0, 4, 1, 6, 'work');
  assert.strictEqual(fileStore.has(oldPosterPath), false);
  assert.strictEqual(page.data.sharePosterPath, '');
  await resultPage.onShare.call(page);
  assert(page.data.sharePosterPath);
  assert(page._poster.key.endsWith('-work'));
  wx.saveImageToPhotosAlbum = options => options.fail({ errMsg: 'saveImageToPhotosAlbum:fail auth deny' });
  wx.showModal = options => { settingsPrompted = options.confirmText === '去设置'; };
  wx.openSetting = () => {};
  await resultPage.onSaveCard.call(page);
  assert(settingsPrompted);
  resultPage.onUnload.call(page);

  for (let visit = 0; visit < 3; visit++) {
    const routePage = makePage();
    const events = visit % 2 ? ['onRouteDone', 'onReady'] : ['onReady', 'onRouteDone'];
    resultPage[events[0]].call(routePage);
    assert.strictEqual(routePage.data.ringMounted, false);
    resultPage[events[1]].call(routePage);
    viewTicks.shift()();
    assert.strictEqual(routePage.data.ringMounted, true);
  }

  const scenes = loadComponent('components/result-scenes/result-scenes.js');
  const sceneEvents = [];
  const sceneInstance = { properties: { scene: 'love' }, triggerEvent(name, detail) { sceneEvents.push({ name, detail }); } };
  scenes.methods.onSceneTap.call(sceneInstance, { currentTarget: { dataset: { scene: 'work' } } });
  assert.deepStrictEqual(sceneEvents, [{ name: 'change', detail: { scene: 'work' } }]);
  for (const name of ['result-vs', 'result-insights', 'result-advice', 'result-actions']) loadComponent(`components/${name}/${name}.js`);
  poster.removePoster(generated);
  assert.strictEqual(fileStore.size, 0);
  console.log('result components and share poster: PASS');
}

runPageTests().catch(error => {
  console.error(error);
  process.exitCode = 1;
});
