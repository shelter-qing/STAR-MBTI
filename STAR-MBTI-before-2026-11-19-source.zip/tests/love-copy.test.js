'use strict';

const assert = require('assert');
const { calculateCompatibility } = require('../utils/score');
const { MBTI_TYPES, ZODIACS } = require('../utils/helper');

function zodiacName(index) {
  return ZODIACS[index].name.replace('座', '');
}

for (let mA = 0; mA < MBTI_TYPES.length; mA += 1) {
  for (let zA = 0; zA < ZODIACS.length; zA += 1) {
    for (let mB = 0; mB < MBTI_TYPES.length; mB += 1) {
      for (let zB = 0; zB < ZODIACS.length; zB += 1) {
        const result = calculateCompatibility(mA, zA, mB, zB, 'love');
        const lines = result.adviceText.split('\n');
        const labelA = `${MBTI_TYPES[mA]}·${zodiacName(zA)}`;
        const labelB = `${MBTI_TYPES[mB]}·${zodiacName(zB)}`;

        assert.strictEqual(lines.length, 4);
        assert(lines[0].includes(`给用户A（${labelA}）`));
        assert(lines[1].includes(`给用户B（${labelB}）`));
        assert(lines[0].includes('你更倾向') && lines[0].includes('当'));
        assert(lines[1].includes('你更倾向') && lines[1].includes('当'));
        assert(lines[2].startsWith('共同做法：'));
        assert(lines[3].startsWith(`一句话总结：${MBTI_TYPES[mA]}×${MBTI_TYPES[mB]}`));

        assert.strictEqual(result.fitItems.length, 4);
        assert.strictEqual(result.grindItems.length, 4);
        assert(result.fitItems[0].detail.includes(`${MBTI_TYPES[mA]}（用户A）`));
        assert(result.fitItems[1].detail.includes(`${MBTI_TYPES[mB]}（用户B）`));
        assert(result.fitItems[3].detail.includes(`${zodiacName(zA)}（用户A）`));
        assert(result.fitItems[3].detail.includes(`${zodiacName(zB)}（用户B）`));
        assert(result.grindItems[0].detail.includes(`${MBTI_TYPES[mA]}（用户A）`));
        assert(result.grindItems[1].detail.includes(`${MBTI_TYPES[mB]}（用户B）`));
        [...result.fitItems, ...result.grindItems].forEach(item => {
          assert(item.title && item.detail);
          assert(item.detail.length <= 46, `${item.detail} exceeds the detail limit`);
          assert(!/\{\w+\}/.test(item.detail), 'Relationship templates must be fully resolved');
        });
      }
    }
  }
}

const mA = MBTI_TYPES.indexOf('INTJ');
const zA = ZODIACS.findIndex(item => item.name === '狮子座');
const mB = MBTI_TYPES.indexOf('INTP');
const zB = ZODIACS.findIndex(item => item.name === '天秤座');
assert.strictEqual(
  calculateCompatibility(mA, zA, mB, zB, 'friend').adviceText,
  '给用户A（INTJ）：你更倾向好友稀少但极深，重质不重量，只和能谈深度话题的人交往。主动分享近况，朋友之间不必每次都等一个需要解决的问题\n' +
  '给用户B（INTP）：你更倾向兴趣圈社交，聊起专业滔滔不绝，平时神隐但不失联。主动分享近况，朋友之间不必每次都等一个需要解决的问题\n' +
  '共同做法：聊完观点后也交换近况，友谊需要一些没有目的的陪伴。\n' +
  '一句话总结：聊得深不等于聊得近，友谊需要一点生活里的参与。'
);
assert.strictEqual(
  calculateCompatibility(mA, zA, mB, zB, 'work').adviceText,
  '给用户A（INTJ）：你更倾向战略规划者，独立高效，最烦无效会议和低效协作。给结论之前补上背景、目标和依据，让团队知道你是怎么判断的\n' +
  '给用户B（INTP）：你更倾向方案军师，创意爆棚，拒绝循规蹈矩的重复劳动。给结论之前补上背景、目标和依据，让团队知道你是怎么判断的\n' +
  '共同做法：各自说明判断依据，再统一方向，效率会高于争夺主导权。\n' +
  '一句话总结：判断和拆解都很强，难点是统一方向而不是争夺主导权。'
);

console.log('Love copy personalization checks passed for all 36,864 combinations. Friend/work advice unchanged.');
