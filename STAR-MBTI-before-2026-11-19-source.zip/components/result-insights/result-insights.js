Component({
  properties: {
    fitItems: {
      type: Array,
      value: []
    },
    grindItems: {
      type: Array,
      value: []
    }
  }
});
