Component({
  methods: {
    onRedial() {
      this.triggerEvent('redial');
    },
    onShare() {
      this.triggerEvent('share');
    }
  }
});
