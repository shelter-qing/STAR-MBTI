Component({
  properties: {
    scene: {
      type: String,
      value: 'love'
    }
  },
  methods: {
    onSceneTap(e) {
      const scene = e.currentTarget.dataset.scene;
      if (scene !== this.properties.scene) this.triggerEvent('change', { scene });
    }
  }
});
