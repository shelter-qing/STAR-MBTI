Component({
  properties: {
    pickAText: String,
    pickBText: String,
    zodiacIconA: String,
    zodiacIconB: String
  }
});
