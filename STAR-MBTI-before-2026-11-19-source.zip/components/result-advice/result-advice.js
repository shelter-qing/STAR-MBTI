Component({
  properties: {
    adviceLines: {
      type: Array,
      value: []
    },
    tags: {
      type: Array,
      value: ['', '']
    }
  }
});
