function clampScore(value) {
  const score = Number.isFinite(value) ? value : 0;
  return Math.max(0, Math.min(100, score));
}

function gradientForAngle(angle) {
  const sweep = Math.max(0, Math.min(360, angle));
  return `conic-gradient(from 0deg, #fbdba0 0deg, #f9c057 ${sweep * 0.55}deg, #ecb246 ${sweep}deg, transparent ${sweep}deg 360deg)`;
}

Component({
  properties: {
    score: {
      type: Number,
      value: 0,
      observer(value) {
        this._scoreValue = clampScore(value);
        if (this._ringMounted) {
          this._animateTo(this._scoreValue, this._displayScore);
        }
      }
    }
  },

  data: {
    displayScoreText: '0%',
    progressAngle: 0,
    progressGradient: gradientForAngle(0),
    hasProgress: false,
    ringVisible: false
  },

  lifetimes: {
    ready() {
      this._ringMounted = true;
      this._scoreValue = clampScore(this.properties.score);
      this.setData({ ringVisible: true }, () => {
        if (this._ringMounted) this._animateTo(this._scoreValue, 0);
      });
    },
    detached() {
      this._ringMounted = false;
      this._ringAnimToken = (this._ringAnimToken || 0) + 1;
      this._stopAnimation();
    }
  },

  methods: {
    _stopAnimation() {
      if (this._ringAnimTimer) {
        clearTimeout(this._ringAnimTimer);
        this._ringAnimTimer = null;
      }
    },

    _animateTo(targetScore, startScore) {
      const start = clampScore(Number.isFinite(startScore) ? startScore : targetScore);
      const target = clampScore(targetScore);
      const token = (this._ringAnimToken || 0) + 1;
      this._ringAnimToken = token;
      this._stopAnimation();
      this._displayScore = start;

      const startedAt = Date.now();
      const duration = 620;
      const tick = () => {
        if (!this._ringMounted || this._ringAnimToken !== token) return;
        const progress = Math.min(1, (Date.now() - startedAt) / duration);
        const eased = 1 - Math.pow(1 - progress, 3);
        const value = start + (target - start) * eased;
        const angle = value * 3.6;
        this._displayScore = value;
        this.setData({
          displayScoreText: `${Math.round(value)}%`,
          progressAngle: angle,
          progressGradient: gradientForAngle(angle),
          hasProgress: value > 0
        });

        if (progress < 1) this._ringAnimTimer = setTimeout(tick, 16);
        else this._ringAnimTimer = null;
      };

      tick();
    }
  }
});
