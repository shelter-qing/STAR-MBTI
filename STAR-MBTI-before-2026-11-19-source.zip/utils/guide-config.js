// Keep false for release. Enable temporarily when testing the onboarding flow.
module.exports = {
  repeatOnEntry: false
};
