// 结果页关系文案生成层。
// 只负责展示文案，不参与评分。内容以 MBTI 偏好、太阳星座的元素/模式和组合素材为依据，
// 使用“倾向、容易、可能”等措辞，避免把类型描述写成对个人的绝对判断。

const SCENE_LABEL = { love: '恋爱', friend: '友谊', work: '职场' };

const SCENE_COPY = {
  love: {
    fitTitles: ['相互吸引的理由', '靠近时的默契', '气质带来的火花', '舒服相处的条件'],
    blockTitles: ['最容易卡住的地方', '表达错位的时刻', '节奏不合的信号', '冲突发生以后'],
    mode: '先回应，再解决',
    summaryHooks: {
      '理性×理性': ['被彼此的脑内世界吸引，也要给关系留一点温度', '默契来自观点相近，课题是把感受也放进对话'],
      '理性×感性': ['互补感很强，误会常发生在“讲道理”和“想被理解”之间', '一个想把事情想清楚，一个想先确认自己被在乎'],
      '理性×控制': ['都认真对待关系，靠近以后容易把相处过成标准检查', '稳定感不缺，柔软和弹性需要被刻意保留'],
      '理性×自由': ['新鲜感很强，真正的考验是确定感和空间如何同时存在', '彼此欣赏不同的活法，也要把承诺说得具体'],
      '感性×感性': ['很容易接住彼此的情绪，也容易一起陷进没有说出口的猜测', '共鸣来得快，关系需要有人把感受翻译成明确需求'],
      '感性×控制': ['一个在意被理解，一个习惯用行动照顾，温度和边界要同时在线', '安全感有基础，关心不能替代询问'],
      '感性×自由': ['浪漫和新鲜感都不缺，长期靠的是稳定回应', '一个想靠近，一个需要空间，直接确认比猜测更重要'],
      '控制×控制': ['认真、可靠、可预期，偶尔也会因为各自的标准不肯松手', '生活容易安稳，关系需要主动制造轻松感'],
      '控制×自由': ['一个带来秩序，一个带来变化，吸引力和摩擦会一起出现', '相处不缺互补，冲突常来自“现在就定下来”还是“再看看”'],
      '自由×自由': ['相处轻松又有火花，长期需要有人把喜欢落实成安排', '快乐很自然，稳定回应不能只靠临时起意']
    }
  },
  friend: {
    fitTitles: ['成为朋友的理由', '聊得来的地方', '相处节奏的互补', '友谊能走远的条件'],
    blockTitles: ['联系频率的落差', '话题之外的距离', '边界容易错位', '冷下来以前的信号'],
    mode: '先听见，再给建议',
    summaryHooks: {
      '理性×理性': ['观点容易同频，真正的亲近来自没有目的的陪伴', '聊得深不等于聊得近，友谊需要一点生活里的参与'],
      '理性×感性': ['一个提供思路，一个接住情绪，彼此需要不同形式的回应', '能聊观点也能聊心事，误会常来自支持方式不同'],
      '理性×控制': ['一个带来新视角，一个带来可靠感，别把朋友相处变成讲理比赛', '共同做事很稳，彼此留余地才能一直舒服'],
      '理性×自由': ['一起探索很有趣，联系频率和承诺感要提前说清楚', '一个看重稳定回应，一个习惯来去自如，别把神隐当成默认'],
      '感性×感性': ['很会互相接住，但低落时需要有人把彼此带回现实', '心事容易被听懂，旧情绪也容易被一起放大'],
      '感性×控制': ['一个愿意倾听，一个愿意照顾，边界清楚才能让关心保持轻松', '可靠和被理解都很重要，帮忙之前先问一句更合适'],
      '感性×自由': ['一个分享感受，一个带人体验新鲜事，节奏不同却能互相打开世界', '轻松相处很自然，长期友谊仍需要主动联系'],
      '控制×控制': ['都是可以托付事情的人，意见不同的时候要少一点标准感', '务实和守信让友谊稳定，别让相处只剩安排和执行'],
      '控制×自由': ['一个负责靠谱，一个负责好玩，临时起意和提前安排要找到平衡', '互补很明显，别让“我来安排”和“随便都行”互相消耗'],
      '自由×自由': ['一起玩很轻松，真正维持友谊的是有人愿意持续出现', '快乐不缺，关系要靠主动联系留下连续性']
    }
  },
  work: {
    fitTitles: ['合作的优势', '思路如何接上', '分工带来的效率', '把结果做出来的条件'],
    blockTitles: ['推进节奏的冲突', '沟通方式的误差', '标准容易不一致', '分歧出现以后'],
    mode: '先对齐，再推进',
    summaryHooks: {
      '理性×理性': ['判断和拆解都很强，难点是统一方向而不是争夺主导权', '战略思维容易接上，执行前要把“谁来定”说清楚'],
      '理性×感性': ['一个看方向，一个看人和现场，分工清楚就能同时顾到效率和共识', '洞察和结构可以互补，表达时要让彼此都拿到依据'],
      '理性×控制': ['一个善于建模，一个重视落地，标准先对齐，合作会很稳', '方向与执行都有人守，流程别叠加到失去弹性'],
      '理性×自由': ['一个搭框架，一个找突破口，创意和交付需要同一张时间表', '变化能带来机会，负责人和截止时间要先确定'],
      '感性×感性': ['团队感和洞察力都不错，关键决策需要补上数据与期限', '能看见人的需要，推进时要有人把判断落到行动'],
      '感性×控制': ['一个照顾协作感，一个守住执行线，边界清晰时很适合长期配合', '关怀和标准可以并存，职责不要靠默契猜'],
      '感性×自由': ['创意和应变都很强，增加结构和跟进才能把想法交付出去', '一个捕捉可能，一个快速试错，收尾机制要提前约定'],
      '控制×控制': ['执行可靠、标准明确，流程叠加时要主动留下弹性', '适合把复杂事情做稳，也要防止每一步都需要批准'],
      '控制×自由': ['一个把风险按住，一个把机会打开，先约定底线，再允许过程变化', '秩序和突破各有价值，别把差异误读成不负责'],
      '自由×自由': ['临场反应很快，项目需要明确负责人和截止时间', '点子和行动都不缺，计划是让效率持续的支点']
    }
  }
};

const ELEMENT_COPY = {
  '火×火': { fit: '都更容易被直接、热烈的行动带动', block: '推进太快时，双方都可能不愿先退一步' },
  '火×土': { fit: '一方带来冲劲，一方帮助事情稳稳落地', block: '一个嫌节奏慢，一个担心事情太急' },
  '火×风': { fit: '热情和点子互相放大，容易把气氛带起来', block: '开始很快，后续需要有人把想法持续落地' },
  '火×水': { fit: '直接的行动遇上细腻的感受，反差会带来吸引力', block: '表达强度不同，热烈可能被读成压力' },
  '土×土': { fit: '都重视稳定、承诺和持续投入', block: '各自的标准都很清楚，分歧时容易一起坚持' },
  '土×风': { fit: '一方提供落点，一方带来新的视角', block: '一个需要确定，一个更愿意保留变化' },
  '土×水': { fit: '务实和温柔可以互相托住，连接通常比较安静', block: '沉默消化和情绪确认之间容易出现空档' },
  '风×风': { fit: '话题和想法自然流动，相处轻盈而有弹性', block: '讨论很多、决定很少时，容易缺少落地的人' },
  '风×水': { fit: '新鲜感和情绪深度会让彼此看到不同的世界', block: '一方需要空间，一方更在意稳定回应' },
  '水×水': { fit: '感受细腻，建立信任后关系浓度容易上升', block: '双方都把话放在心里时，猜测会一起变多' }
};

const LOVE_DIMENSION_COPY = {
  '理性×理性': {
    summary: ['问题能聊透，感受也要说出口；别只讨论谁更有道理。', '观点很容易同频，需求也要讲明白，别让默契变成猜测。'],
    fitTitle: '想法接得上',
    fit: ['{mbtiA}和{mbtiB}都愿意追问理由；语气放软，讨论更像一起找答案。', '{mbtiA}和{mbtiB}都重视讲清楚；补上彼此没想到的角度，讨论更容易有结果。'],
    blockTitle: '聊着聊着变辩论',
    block: ['{mbtiA}和{mbtiB}一有分歧就各自补理由；先说介意什么，再聊方案。', '{mbtiA}和{mbtiB}都等对方理解逻辑；先确认在乎，再讨论对错。'],
    closing: ['先把在乎说出来，再一起把问题聊清楚。', '聊得来是默契，肯表达才是亲密。']
  },
  '理性×感性': {
    summary: ['你说累，对方先给办法；先回应，再一起解决。', '你刚说委屈，对方可能先分析；先被听见，再一起找办法。'],
    fitTitle: '回应对上频道',
    fit: ['{rationalType}能把复杂事拆成几步，{feelingType}会把感受说清；一起聊时，既有方向也有温度。', '{feelingType}带来新话题，{rationalType}愿意继续追问；一个打开新窗口，一个把想法落到下一步。'],
    blockTitle: '安慰和方案错频道',
    block: ['{feelingType}刚说委屈，{rationalType}已开始分析；好意容易被听成纠正。', '{rationalType}想整理好再回复，{feelingType}可能把空白读成冷淡；先约定忙时怎么说。'],
    closing: ['先回应感受，再一起找办法。', '一个说清需要，一个认真听见，关心才会落地。']
  },
  '理性×控制': {
    summary: ['一个追问为什么，一个先确认怎么做；把标准说清，少一点互相挑错。', '都想把事情做好，约会也别变成一张待办清单。'],
    fitTitle: '认真也能互相托底',
    fit: ['{rationalType}追问原因，{controlType}确认做法；先对齐目标，计划更容易落地。', '{rationalType}梳理原因，{controlType}留意安排细节；明确分工后更容易落地。'],
    blockTitle: '标准容易变成检查',
    block: ['{rationalType}追问原因，{controlType}在意做法；别把商量变成检查。', '{rationalType}还想继续分析，{controlType}已经在意执行细节；先说清各自的标准。'],
    closing: ['把标准说成商量，认真才不会变成压力。', '计划可以周全，关系也要留点轻松。']
  },
  '理性×自由': {
    summary: ['一个想定下安排，一个想保留选择；先说好重点，临时起意也能安心。', '新鲜感不缺，重要约定要落下来，别让“再看看”代替回应。'],
    fitTitle: '计划里留着新鲜感',
    fit: ['{rationalType}拆解步骤，{freeType}带来新可能；先定方向，再留空间临时发挥。', '{rationalType}整理计划，{freeType}打开思路；先定一个节点，其余保留弹性。'],
    blockTitle: '确定和自由在拉扯',
    block: ['{rationalType}想先定计划，{freeType}想留选项；说清哪些事要确定。', '{rationalType}怕安排落空，{freeType}怕被计划绑住；提前说清哪些不能改。'],
    closing: ['重要的事先说定，剩下的留给即兴。', '把期待说清楚，空间也就不再像疏远。']
  },
  '感性×感性': {
    summary: ['一句回复短了，两个人都开始猜；直接说需要什么，比读语气轻松。', '彼此很会察觉情绪，也别让没说出口的期待替你们做决定。'],
    fitTitle: '小情绪也容易被看见',
    fit: ['{mbtiA}和{mbtiB}都留意语气变化；说清需求，比互相猜更轻松。', '{mbtiA}和{mbtiB}都愿意分享感受；及时说出需要什么，亲密更不靠猜。'],
    blockTitle: '两个人一起陷进猜测',
    block: ['{mbtiA}一句回复短了，{mbtiB}也开始猜；直接问比读语气轻松。', '{mbtiA}和{mbtiB}都等对方先发现委屈；沉默久了，体谅也会变成失望。'],
    closing: ['把感受说出来，别让沉默替你们回答。', '少一点猜，多一点直接的安慰和确认。']
  },
  '感性×控制': {
    summary: ['一个希望被理解，一个急着把事情安排好；先问一声，关心才不会变压力。', '照顾和回应都重要，安排之前先确认对方想要什么。'],
    fitTitle: '照顾能落到日常里',
    fit: ['{feelingType}留意情绪变化，{controlType}把照顾落在行动上；先问需求，关心更容易被接住。', '{feelingType}说出感受，{controlType}提供稳定支持；把照顾变成商量，亲密也有边界。'],
    blockTitle: '好意可能变成安排',
    block: ['{feelingType}想先被听见，{controlType}马上开始安排；关心容易变压力。', '{feelingType}没说哪里不舒服，{controlType}以为安排妥当；先问需求再帮忙。'],
    closing: ['先问对方需要什么，再把关心落到行动里。', '照顾要有回应，安排也要留选择。']
  },
  '感性×自由': {
    summary: ['一个想确认在乎，一个需要呼吸空间；说清下一次回应，靠近就不必靠猜。', '浪漫和新鲜感都有，稳定回应也要留在关系里。'],
    fitTitle: '空间里仍然有回应',
    fit: ['{feelingType}直接表达在意，{freeType}带来新体验；把下次见面说定，浪漫更有连续性。', '{feelingType}分享心情，{freeType}提议新体验；约好再联系的时间，双方更安心。'],
    blockTitle: '空间容易被读成冷淡',
    block: ['{feelingType}想确认在乎，{freeType}需要独处；说清何时再联系。', '{feelingType}等稳定回应，{freeType}想留独处时间；把联系节奏说清。'],
    closing: ['给彼此空间，也把下次联系说清楚。', '新鲜感可以随性，回应别只靠猜。']
  },
  '控制×控制': {
    summary: ['约会细节都想安排妥当；最难的不是计划，是谁愿意先松一点。', '认真经营能带来稳定，偶尔不做计划也很重要。'],
    fitTitle: '愿意把日子安排好',
    fit: ['{mbtiA}和{mbtiB}都肯安排日常；把标准说成商量，稳定里也能留出轻松。', '{mbtiA}和{mbtiB}都愿意投入承诺；安排之外也留一段不做计划的时间。'],
    blockTitle: '安排里也要留余地',
    block: ['{mbtiA}和{mbtiB}都不想先改主意；先说最重要的一件事。', '{mbtiA}和{mbtiB}都想按自己的标准安排；先分清底线和偏好。'],
    closing: ['把重要的安排做好，也给意外留个位置。', '有些时刻不必计划，陪在一起就够了。']
  },
  '控制×自由': {
    summary: ['一个想早点定时间，一个想留给临时起意；先定底线，剩下的自由发挥。', '稳定和新鲜可以同时有，先说清哪些约定不能含糊。'],
    fitTitle: '稳定里也有新鲜感',
    fit: ['{controlType}把计划安排稳，{freeType}带来变化；先说好底线，惊喜就不必变压力。', '{controlType}考虑时间地点，{freeType}带来新点子；留些弹性，安排不必变成控制。'],
    blockTitle: '临时变化要提前说',
    block: ['{controlType}想早定时间，{freeType}想看当天状态；先定重要约定。', '{controlType}怕变化太多，{freeType}怕安排太满；先约定哪些事能变。'],
    closing: ['先定好彼此在意的事，再一起给日子留惊喜。', '约定给人安心，弹性让相处更轻松。']
  },
  '自由×自由': {
    summary: ['约会总能临时成行，重要的话题却容易留到以后；把下次说定，关系更有着落。', '轻松和新鲜感不缺，主动安排也是在表达认真。'],
    fitTitle: '一起探索很自在',
    fit: ['{mbtiA}和{mbtiB}一起探索很自在；把下次见面定下来，轻松也有延续。', '{mbtiA}和{mbtiB}都有新点子；把重要日子记下来，喜欢就有了着落。'],
    blockTitle: '“改天”容易一拖再拖',
    block: ['{mbtiA}和{mbtiB}都等对方先提；定个具体时间比“改天”可靠。', '{mbtiA}和{mbtiB}都以为下次再说；联系和承诺就一起往后拖。'],
    closing: ['把下一次见面定下来，轻松也会有延续。', '主动安排不是失去自由，是让喜欢有着落。']
  }
};

const LOVE_ELEMENT_COPY = {
  '火×火': {
    fit: ['想到什么约会就一起行动，热情容易互相传染', '想做什么通常不用催；也可以一起慢下来，享受不赶行程的约会'],
    block: ['两个人都急着推进时，容易抢着说完最后一句', '安排临时变动时，双方都想照自己的节奏来；先约定一个折中点']
  },
  '火×土': {
    fit: ['一方提议新玩法，另一方把时间和路线安排稳；心动更容易落地', '一个先点燃兴致，一个照看好细节；出门后不必一路临时补计划'],
    block: ['一个嫌节奏慢，一个担心太仓促；先说清时间和预算', '临时起意和提前安排撞上时，先确定不能改的部分']
  },
  '火×风': {
    fit: ['聊天里的一个新点子，很快会变成实际安排；记得顺手定好时间', '临时改行程时，两个人都能接住变化；不用把每一步都提前定死'],
    block: ['开头很热闹，后续安排容易没人接手', '临时换话题和改计划都很轻松，重要约定却可能被冲淡']
  },
  '火×水': {
    fit: ['一方直接说想法，一方能察觉情绪变化；说开以后更容易靠近', '热情和细腻放在一起，约会既有行动也有照顾'],
    block: ['直说可能被听成太冲，沉默又容易让人猜', '一个希望当下说开，一个需要时间消化；告诉对方何时再聊']
  },
  '土×土': {
    fit: ['会认真记住见面安排和小承诺；稳定感常来自这些日常', '一起把饭吃好、路线安排妥，是表达在意的一种方式'],
    block: ['两边都坚持自己的做法，小事也可能僵住', '约会细节都想安排妥当，最后反而争起谁的方案更合适']
  },
  '土×风': {
    fit: ['一个给计划落点，一个带来新想法；定好安排再留弹性', '先把时间定下，去哪儿可以临时决定；稳定和新鲜感都留得住'],
    block: ['一个需要确定时间，一个还想保留选项', '计划定得太早会觉得受限，临时变动又让人不安；先说好可变范围']
  },
  '土×水': {
    fit: ['一方把照顾落在日常，一方记得情绪细节；安稳里也有温度', '愿意为彼此多做一点小事；说出感谢，行动才不会被当成理所当然'],
    block: ['一个沉默消化，一个等回应；空档拖久了容易多想', '都不想给对方添麻烦时，需求容易被藏起来；直接问更轻松']
  },
  '风×风': {
    fit: ['话题自然接续，临时约会也容易找到共同兴趣', '从聊天到分享新地点很顺；一起收集有趣的小事，关系更有连续感'],
    block: ['一直聊新玩法，见面时间却可能迟迟没敲定', '都愿意保留选择，最后容易没人定下时间；给下次约会一个具体日期']
  },
  '风×水': {
    fit: ['一方带来轻松话题，一方留意情绪变化；聊开后更容易靠近', '一个让气氛松下来，一个把没说出口的在意听出来；需要时就问一句'],
    block: ['一方需要空间，一方更在意稳定回应', '轻松带过的话题可能正好是对方的心事；不确定时先问问']
  },
  '水×水': {
    fit: ['都愿意留意语气和细节；认真倾听能让信任慢慢加深', '记得彼此在意的小事；说出谢谢和想念，比等对方察觉更清楚'],
    block: ['双方都等对方先开口，失望可能一起累积', '一句回复短了，两个人都开始猜；直接问比读语气轻松']
  }
};

const LOVE_ACTIONS = {
  理性: ['先回应感受，再给分析或方案；忙时说清什么时候能继续聊。', '对方分享时先复述听到的重点，给建议前问一句需不需要。'],
  感性: ['把期待说具体：想被听、想见面，还是想一起找办法。', '别只靠语气暗示；直接说出希望对方怎么回应。'],
  控制: ['安排前先问对方；重要约定说清时间，也给计划留点弹性。', '把“我都安排好了”换成“你想怎么过”，关心也留出选择。'],
  自由: ['临时改主意时及时说一声；保留空间，也把下一次联系定下来。', '说清哪些事需要确定，其他安排可以留给临时起意。']
};

const DIM_ACTIONS = {
  love: {
    理性: '先回应感受，再给判断；一句“我听见了”常常比完整方案更有效',
    感性: '把需要说成具体请求，直接区分“想被陪着”还是“想一起想办法”',
    控制: '安排之前先问对方，照顾只有在被看见选择权时才不会变成压力',
    自由: '把随性变成明确回应，给空间的同时说清楚下一次联系和承诺'
  },
  friend: {
    理性: '主动分享近况，朋友之间不必每次都等一个需要解决的问题',
    感性: '先说自己想要倾听、建议还是陪伴，减少让朋友猜的部分',
    控制: '愿意帮忙之前先问对方是否需要，可靠不等于替朋友做决定',
    自由: '重要的约定要落下来，空间可以保留，长期失联会让关系失去连续性'
  },
  work: {
    理性: '给结论之前补上背景、目标和依据，让团队知道你是怎么判断的',
    感性: '把直觉补成数据、例子或节点，洞察才容易转成共识',
    控制: '先说清真正重要的标准，再给执行留下可调整的余地',
    自由: '把想法写成负责人和截止时间，变化才不会变成别人眼里的不确定'
  }
};

const TAGS = {
  love: {
    '理性×理性': ['智性同频', '温度补课'], '理性×感性': ['互补心动', '翻译彼此'],
    '理性×控制': ['稳定靠近', '少些标准'], '理性×自由': ['新鲜拉扯', '说清承诺'],
    '感性×感性': ['情绪共振', '别让猜测'], '感性×控制': ['温柔托底', '保留边界'],
    '感性×自由': ['浪漫有风', '回应要稳'], '控制×控制': ['可靠日常', '制造轻松'],
    '控制×自由': ['秩序与惊喜', '给彼此余地'], '自由×自由': ['轻松有火花', '把喜欢落地']
  },
  friend: {
    '理性×理性': ['观点同频', '陪伴也重要'], '理性×感性': ['懂道理也懂心事', '支持要对频道'],
    '理性×控制': ['靠谱有分寸', '别把友谊讲成理'], '理性×自由': ['探索搭子', '联系要具体'],
    '感性×感性': ['互相接住', '一起回到现实'], '感性×控制': ['倾听与照顾', '先问再帮'],
    '感性×自由': ['打开新世界', '别让节奏失联'], '控制×控制': ['长期可靠', '留一点余地'],
    '控制×自由': ['靠谱加好玩', '安排和随性'], '自由×自由': ['最佳玩伴', '主动维护']
  },
  work: {
    '理性×理性': ['判断同频', '统一主导权'], '理性×感性': ['方向与洞察', '依据要共享'],
    '理性×控制': ['结构与执行', '标准先对齐'], '理性×自由': ['框架与破局', '节点要落地'],
    '感性×感性': ['团队共识', '决策补证据'], '感性×控制': ['关怀与执行', '边界清晰'],
    '感性×自由': ['创意与应变', '跟进到交付'], '控制×控制': ['稳健推进', '流程留弹性'],
    '控制×自由': ['风险与机会', '底线先约定'], '自由×自由': ['临场破局', '负责人明确']
  }
};

const JOINT_ACTIONS = {
  love: {
    '理性×理性': ['把想法说出来，也把在乎说出来；别只讨论问题本身。', '发生分歧时先暂停辩论，轮流说一件自己真正介意的事。'],
    '理性×感性': ['先问“你想被听见还是想一起想办法”，再决定要不要分析。', '一个先复述感受，一个再提出方案，别让关心听起来像纠错。'],
    '理性×控制': ['安排前互相确认，稳定感不需要靠单方面做主来证明。', '把标准变成可商量的约定，别让日常像一张检查清单。'],
    '理性×自由': ['把需要的空间和下一次回应一起说清楚，承诺才不会像束缚。', '一个说清期待，一个说清边界，关系就有了呼吸感。'],
    '感性×感性': ['情绪升高时先命名感受，别让沉默替你们做决定。', '轮流说“我现在需要什么”，比互相猜测更能保护亲密。'],
    '感性×控制': ['照顾之前先问一句，关心和选择权可以同时存在。', '一个说需要，一个说能做到什么，别把“为你好”当成答案。'],
    '感性×自由': ['把喜欢落实成一次具体见面，空间里也要有稳定回应。', '提前约定联系节奏，既保留新鲜感，也不让对方一直猜。'],
    '控制×控制': ['共同安排之后留一点不安排的时间，让关系不只剩下完成任务。', '意见不同时先说底线，再决定哪些地方可以让步。'],
    '控制×自由': ['先约定底线，再给过程留弹性，别把不同节奏当成不在乎。', '一方少替对方决定，一方多给明确回应，摩擦会少很多。'],
    '自由×自由': ['把下一次见面定下来，轻松相处也需要有人认真维护。', '临时起意很有趣，也要偶尔为关系留一段确定的时间。']
  },
  friend: {
    '理性×理性': ['聊完观点后也交换近况，友谊需要一些没有目的的陪伴。', '别只在有问题时联系，分享一件小事也能让关系继续生长。'],
    '理性×感性': ['先问对方要倾听还是建议，支持方式对上频道才有用。', '一个少一点分析，一个多说一点需要，误会会少很多。'],
    '理性×控制': ['意见不同时留出余地，朋友不需要每次都分出谁更有道理。', '共同做事前先说各自的标准，做完也别忘了聊点无用的事。'],
    '理性×自由': ['把“下次约”换成具体时间，也接受计划临时变化。', '联系频率提前说清楚，别让一个等回应、一个等对方主动。'],
    '感性×感性': ['一起低落时安排一个小行动，把情绪从原地带出来。', '先接住对方，再一起想一件能让今天变轻一点的事。'],
    '感性×控制': ['帮忙前先问是否需要，关系会更轻松。', '一个直接说需要，一个先尊重边界，关心就不会变成管束。'],
    '感性×自由': ['重要约定记下来，临时改变时及时说一声。', '一个多给明确回应，一个少把沉默当成默认，友谊会更稳。'],
    '控制×控制': ['计划之外留点随意，别让朋友相处只剩下守时和执行。', '意见不合时先保留关系，再讨论谁的方案更好。'],
    '控制×自由': ['提前安排和临时起意都保留一半，找到双方都舒服的节奏。', '一方别包办，一方别失联，可靠和轻松可以同时成立。'],
    '自由×自由': ['共同记住一个固定的联系点，友谊才不会只停在“有空再约”。', '一起玩之外也聊一次近况，让快乐关系有连续性。']
  },
  work: {
    '理性×理性': ['开始前先定谁拍板，讨论才不会变成无休止的方案竞争。', '各自说明判断依据，再统一方向，效率会高于争夺主导权。'],
    '理性×感性': ['一个说明目标和依据，一个补充现场和人的影响，再一起定方案。', '先共享背景，再讨论结论，洞察和结构才能真正接上。'],
    '理性×控制': ['先对齐标准和优先级，执行过程中少用额外流程打断推进。', '方向由谁定、细节谁负责要提前写清，稳定感才不会变成层层审批。'],
    '理性×自由': ['把创意留给过程，把负责人和截止时间写进计划。', '先确定不可变的底线，再给方法保留试错空间。'],
    '感性×感性': ['把共识写成三条可执行的决定，再给每条决定一个期限。', '先确认团队感受，再补上数据和负责人，讨论才会往前走。'],
    '感性×控制': ['关心协作感，也明确职责边界，别让帮忙变成越权。', '一个负责把人照顾好，一个守住交付线，遇到变化及时重排优先级。'],
    '感性×自由': ['把灵感变成下一步动作，给试错设置一个复盘时间。', '一个补充用户和团队视角，一个负责快速验证，收尾要有人跟进。'],
    '控制×控制': ['先定真正重要的标准，其他细节留给执行者判断。', '流程和流程相撞时回到目标，别为了完整而牺牲速度。'],
    '控制×自由': ['先写底线和交付节点，再让方法自由变化。', '一方守住风险，一方提出突破，复盘时一起看结果而不是互相归因。'],
    '自由×自由': ['开始前确定负责人和截止时间，执行中再保留灵活调整。', '把点子先记下来，再挑一个能在本周完成的小步验证。']
  }
};

function stableHash(value) {
  let hash = 5381;
  const text = String(value);
  for (let i = 0; i < text.length; i++) hash = ((hash * 33) ^ text.charCodeAt(i)) >>> 0;
  return hash >>> 0;
}

function pick(value, list) {
  if (!list || !list.length) return '';
  return list[stableHash(value) % list.length];
}

function cleanText(value, maxLength = 46) {
  const raw = String(value || '').replace(/^「[^」]+」[：:]\s*/, '').replace(/\s+/g, ' ').trim();
  if (raw.length <= maxLength) return raw.replace(/[。；]$/, '');
  const clauses = raw.split(/[，。；！？]/).map(v => v.trim()).filter(Boolean);
  let result = '';
  for (const clause of clauses) {
    const next = result ? `${result}，${clause}` : clause;
    if (next.length > maxLength) break;
    result = next;
  }
  if (result) return result;
  return `${Array.from(raw).slice(0, Math.max(1, maxLength - 1)).join('')}…`;
}

function traitWord(trait, index, fallback) {
  const words = (trait && trait.pos) || [];
  return words[index] || words[0] || fallback;
}

function negativeWord(trait, index, fallback) {
  const words = (trait && trait.neg) || [];
  return words[index] || words[0] || fallback;
}

function styleFor(trait, scene) {
  const key = scene === 'love' ? 'loveStyle' : scene === 'friend' ? 'friendStyle' : 'workStyle';
  return cleanText(trait && trait[key], 28) || '用自己的节奏建立连接';
}

function triggerPhrase(value, fallback) {
  const raw = String(value || fallback).trim().replace(/[。；，、]+$/, '');
  return raw.replace(/时$/, '') || fallback;
}

function firstClause(value, maxLength = 20) {
  const clause = String(value || '').split(/[，,；;。！？]/)[0].trim();
  return cleanText(clause, maxLength);
}

function triggerContext(value) {
  const trigger = triggerPhrase(value, '感到不被理解');
  if (/^(对方|伴侣)/.test(trigger)) return `当${trigger}时`;
  return `当你${trigger}时`;
}

function comfortPhrase(value) {
  return firstClause(triggerPhrase(value, '得到明确回应'), 14)
    .replace(/伴侣/g, '对方')
    .replace(/其/g, '你的');
}

function pairRecordDetail(a, b, records, seed, fallback) {
  const source = pick(seed, records || []) || fallback;
  return cleanText(`${a}×${b}：${source}`, 46);
}

function buildLoveRelationshipCopy(options) {
  const { pk, ek, mbtiA, mbtiB, zAName, zBName, mtA, mtB, ztA, ztB, mRec, zRec } = options;
  const pairCopy = LOVE_DIMENSION_COPY[pk] || LOVE_DIMENSION_COPY['理性×感性'];
  const seed = `${mbtiA}|${zAName}|${mbtiB}|${zBName}|love`;
  const dimA = options.dimA || '理性';
  const dimB = options.dimB || '感性';
  const mbtiFit = mRec.fit || pairCopy.fit;
  const mbtiBlock = mRec.block || pairCopy.block;
  const fallbackElement = LOVE_ELEMENT_COPY[ek] || LOVE_ELEMENT_COPY['风×水'];
  const zodiacFit = zRec.fit || fallbackElement.fit;
  const zodiacBlock = zRec.block || fallbackElement.block;
  const jointOptions = JOINT_ACTIONS.love[pk] || JOINT_ACTIONS.love['理性×感性'];
  const tagOptions = TAGS.love[pk] || ['彼此影响', '把话说开'];
  const actionAOptions = LOVE_ACTIONS[dimA] || LOVE_ACTIONS.理性;
  const actionBOptions = LOVE_ACTIONS[dimB] || LOVE_ACTIONS.感性;
  const actionA = pick(`${seed}|love-action-a`, actionAOptions);
  const actionB = pick(`${seed}|love-action-b`, actionBOptions);
  const profileA = firstClause(mtA && mtA.loveStyle, 17) || '按自己的节奏靠近';
  const profileB = firstClause(mtB && mtB.loveStyle, 17) || '按自己的节奏靠近';
  const comfortA = comfortPhrase(mtA && mtA.comfort);
  const comfortB = comfortPhrase(mtB && mtB.comfort);
  const triggerA = triggerPhrase(mtA && mtA.trigger, '感到不被理解');
  const triggerB = triggerPhrase(mtB && mtB.trigger, '感到不被理解');
  const weakA = negativeWord(mtA, 0, '收起表达');
  const weakB = negativeWord(mtB, 0, '收起表达');
  const pairBlock = pick(`${seed}|love-mbti-block`, mbtiBlock) || pick(`${seed}|fallback-block`, pairCopy.block);
  const zodiacProfile = cleanText(
    `${zAName}（用户A）：${firstClause(ztA && ztA.loveStyle, 12)}；${zBName}（用户B）：${firstClause(ztB && ztB.loveStyle, 12)}`,
    46
  );

  return {
    summary: cleanText(`${mbtiA}×${mbtiB}：${pick(`${seed}|love-summary`, pairCopy.summary)}`, 40),
    fitItems: [
      { title: '用户A的靠近方式', detail: cleanText(`${mbtiA}（用户A）：你的倾向是${profileA}；${comfortA}时更安心`, 46) },
      { title: '用户B的靠近方式', detail: cleanText(`${mbtiB}（用户B）：你的倾向是${profileB}；${comfortB}时更安心`, 46) },
      { title: 'MBTI组合里的默契', detail: pairRecordDetail(mbtiA, mbtiB, mbtiFit, `${seed}|love-mbti-fit`, `${pairCopy.fitTitle}。`) },
      { title: '星座带来的相处节奏', detail: zodiacProfile || pairRecordDetail(zAName, zBName, zodiacFit, `${seed}|love-zodiac-fit`, '相处节奏可以互相补足。') }
    ],
    grindItems: [
      { title: '用户A的触发点', detail: cleanText(`${mbtiA}（用户A）：${triggerContext(triggerA)}，可能表现出${weakA}倾向`, 46) },
      { title: '用户B的触发点', detail: cleanText(`${mbtiB}（用户B）：${triggerContext(triggerB)}，可能表现出${weakB}倾向`, 46) },
      { title: 'MBTI互动中的卡点', detail: pairRecordDetail(mbtiA, mbtiB, mbtiBlock, `${seed}|love-mbti-block`, '表达方式不同，容易错过彼此的需要。') },
      { title: '星座节奏的磨合', detail: pairRecordDetail(zAName, zBName, zodiacBlock, `${seed}|love-zodiac-block`, '约会节奏不同，提前说好彼此的期待。') }
    ],
    adviceText: [
      `给用户A（${mbtiA}·${zAName}）：你更倾向${profileA}；${triggerContext(triggerA)}，${actionA}`,
      `给用户B（${mbtiB}·${zBName}）：你更倾向${profileB}；${triggerContext(triggerB)}，${actionB}`,
      `共同做法：你们容易卡在${cleanText(pairBlock, 42)}；${pick(`${seed}|love-joint`, jointOptions)}`,
      `一句话总结：${mbtiA}×${mbtiB}的关系课题是${pick(`${seed}|love-closing`, pairCopy.closing)}`
    ].join('\n'),
    tags: tagOptions.slice(0, 2)
  };
}

function sceneTitle(scene, pk, ek, slot) {
  const copy = SCENE_COPY[scene];
  if (slot === 0) return copy.fitTitles[stableHash(`${scene}|${pk}|fit0`) % copy.fitTitles.length];
  if (slot === 3) return `${ek}元素的节奏`;
  return slot === 1 ? '组合里的长处' : '星座气质的加成';
}

function sceneBlockTitle(scene, pk, ek, slot) {
  const copy = SCENE_COPY[scene];
  if (slot === 0) return copy.blockTitles[stableHash(`${scene}|${pk}|block0`) % copy.blockTitles.length];
  if (slot === 3) return `${ek}元素的敏感点`;
  return slot === 1 ? '组合里的卡点' : '星座气质的摩擦';
}

function buildRelationshipCopy(options) {
  const { scene, pk, ek, mbtiA, mbtiB, zAName, zBName, mtA, mtB, ztA, ztB, mRec, zRec } = options;
  if (scene === 'love') return buildLoveRelationshipCopy(options);

  const sceneCopy = SCENE_COPY[scene] || SCENE_COPY.love;
  const sceneLabel = SCENE_LABEL[scene] || SCENE_LABEL.love;
  const seed = `${mbtiA}|${zAName}|${mbtiB}|${zBName}|${scene}`;
  const elementCopy = ELEMENT_COPY[ek] || ELEMENT_COPY['风×水'];
  const sceneFitSource = options.copyFit && options.copyFit[pk] && options.copyFit[pk][scene];
  const sceneBlockSource = options.copyBlock && options.copyBlock[pk] && options.copyBlock[pk][scene];
  const fitSource = pick(`${seed}|mfit`, mRec.fit || []);
  const zodiacFitSource = pick(`${seed}|zfit`, zRec.fit || []);
  const blockSource = pick(`${seed}|mblock`, mRec.block || []);
  const zodiacBlockSource = pick(`${seed}|zblock`, zRec.block || []);
  const hook = pick(`${seed}|summary`, sceneCopy.summaryHooks[pk] || sceneCopy.summaryHooks['理性×感性']);
  // 双方信息已经在结果页顶部展示；摘要保留 MBTI 组合，给判断本身留出完整空间。
  const summary = cleanText(`${mbtiA}×${mbtiB}：${hook}。`, 44);

  const aPos = traitWord(mtA, 0, '表达');
  const bPos = traitWord(mtB, 0, '表达');
  const aPos2 = traitWord(mtA, 1, aPos);
  const bPos2 = traitWord(mtB, 1, bPos);
  const aNeg = negativeWord(mtA, 0, '收起表达');
  const bNeg = negativeWord(mtB, 0, '把话放在心里');
  const sameType = mbtiA === mbtiB;
  const styleA = styleFor(mtA, scene);
  const styleB = styleFor(mtB, scene);

  const fitItems = [
    { title: sceneTitle(scene, pk, ek, 0), detail: cleanText(sameType ? `两位${mbtiA}都看重${aPos}和${aPos2}；相似会带来默契，也可能让相同盲区一起出现。` : `${mbtiA}更看重${aPos}和${aPos2}，${mbtiB}更看重${bPos}和${bPos2}；差异可能让彼此看到不熟悉的一面。`, 46) },
    { title: sceneTitle(scene, pk, ek, 1), detail: cleanText(`${sceneLabel}里，${sceneFitSource || `${mbtiA}的${aPos}和${mbtiB}的${bPos}可以互相补足`}`, 46) },
    { title: sceneTitle(scene, pk, ek, 2), detail: cleanText(`${zAName}偏${traitWord(ztA, 0, '气质')}，${zBName}偏${traitWord(ztB, 0, '气质')}；${elementCopy.fit}。`, 46) },
    { title: sceneTitle(scene, pk, ek, 3), detail: cleanText(sameType ? `双方的${aPos2}都很突出，${sceneCopy.mode}时，要刻意补上彼此都不习惯的部分。` : `${mbtiA}的${aPos2}和${mbtiB}的${bPos2}各有用处，${sceneCopy.mode}时，优势更容易被对方看见。`, 46) }
  ];

  const blockItems = [
    { title: sceneBlockTitle(scene, pk, ek, 0), detail: cleanText(`${sceneBlockSource || `双方关注点不同，容易把不同需求误读成不在乎`}。`, 46) },
    { title: sceneBlockTitle(scene, pk, ek, 1), detail: cleanText(`${sceneLabel}里，${blockSource || `${mbtiA}和${mbtiB}可能用不同方式处理分歧`}`, 46) },
    { title: sceneBlockTitle(scene, pk, ek, 2), detail: cleanText(`${zAName}和${zBName}在${traitWord(ztA, 1, '节奏')}与${traitWord(ztB, 1, '回应')}上可能错开；${elementCopy.block}。`, 46) },
    { title: sceneBlockTitle(scene, pk, ek, 3), detail: cleanText(sameType ? `双方在${triggerPhrase(mtA.trigger, '感到被误解')}时都可能显得${aNeg}；相似的反应若不说开，容易把沉默当成答案。` : `${mbtiA}在${triggerPhrase(mtA.trigger, '感到被误解')}时可能显得${aNeg}，${mbtiB}在${triggerPhrase(mtB.trigger, '感到没有回应')}时可能${bNeg}；早点说出触发点，会比事后猜原因轻松。`, 50) }
  ];

  const dA = options.dimA || '理性';
  const dB = options.dimB || '感性';
  const actionA = DIM_ACTIONS[scene][dA] || DIM_ACTIONS[scene].理性;
  const actionB = sameType
    ? ({ love: { 理性: '可以轮流先说感受，再一起讨论方案', 感性: '把猜测换成直接提问，别等对方自动读懂', 控制: '安排前互相确认，给彼此保留选择空间', 自由: '把下一次联系定下来，让轻松相处有连续性' }, friend: { 理性: '也主动分享一点近况，让友谊不只停在观点', 感性: '低落时先说需要什么，别让两个人一起猜', 控制: '先问是否需要帮忙，再决定要不要介入', 自由: '共同记住重要约定，避免两个人都以为下次再说' }, work: { 理性: '轮流说明判断依据，避免两个人都只给结论', 感性: '共同补上数据和节点，让共识能继续推进', 控制: '约定谁拍板、哪些地方可以调整', 自由: '共同确认负责人和期限，给变化留下边界' } }[scene][dB] || actionA)
    : (DIM_ACTIONS[scene][dB] || DIM_ACTIONS[scene].感性);
  const joint = `共同做法：${pick(`${seed}|joint`, JOINT_ACTIONS[scene][pk] || JOINT_ACTIONS[scene]['理性×感性'])}`;
  const closing = pick(`${seed}|closing`, sceneCopy.summaryHooks[pk] || sceneCopy.summaryHooks['理性×感性']);
  const adviceLines = [
    `给用户A（${mbtiA}）：你更倾向${styleA}。${actionA}`,
    `给用户B（${mbtiB}）：你更倾向${styleB}。${actionB}`,
    joint,
    `一句话总结：${closing}。`
  ];

  return {
    summary,
    fitItems,
    grindItems: blockItems,
    adviceText: adviceLines.join('\n'),
    tags: (TAGS[scene][pk] || ['彼此影响', '需要沟通']).slice(0, 2)
  };
}

module.exports = { buildRelationshipCopy, ELEMENT_COPY, SCENE_COPY };
