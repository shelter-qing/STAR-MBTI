// utils/helper.js — MBTI / 星座常量与通用工具

const MBTI_TYPES = [
  'INTJ', 'INTP', 'ENTJ', 'ENTP',
  'INFJ', 'INFP', 'ENFJ', 'ENFP',
  'ISTJ', 'ISFJ', 'ESTJ', 'ESFJ',
  'ISTP', 'ISFP', 'ESTP', 'ESFP'
];

// 16 型 MBTI 归类与色彩（PRD 4.2：分析家紫 / 外交官绿 / 哨兵蓝 / 探险家黄）
const MBTI_ROLES = {
  'INTJ': { role: '分析家', color: '#8e44ad' },
  'INTP': { role: '分析家', color: '#8e44ad' },
  'ENTJ': { role: '分析家', color: '#9b59b6' },
  'ENTP': { role: '分析家', color: '#9b59b6' },
  'INFJ': { role: '外交官', color: '#27ae60' },
  'INFP': { role: '外交官', color: '#27ae60' },
  'ENFJ': { role: '外交官', color: '#2ecc71' },
  'ENFP': { role: '外交官', color: '#2ecc71' },
  'ISTJ': { role: '哨兵', color: '#2980b9' },
  'ISFJ': { role: '哨兵', color: '#2980b9' },
  'ESTJ': { role: '哨兵', color: '#3498db' },
  'ESFJ': { role: '哨兵', color: '#3498db' },
  'ISTP': { role: '探险家', color: '#d35400' },
  'ISFP': { role: '探险家', color: '#d35400' },
  'ESTP': { role: '探险家', color: '#e67e22' },
  'ESFP': { role: '探险家', color: '#e67e22' }
};

const ZODIACS = [
  { name: '白羊座', symbol: '♈', element: 'fire', color: '#e74c3c' },
  { name: '金牛座', symbol: '♉', element: 'earth', color: '#27ae60' },
  { name: '双子座', symbol: '♊', element: 'air', color: '#16a085' },
  { name: '巨蟹座', symbol: '♋', element: 'water', color: '#2980b9' },
  { name: '狮子座', symbol: '♌', element: 'fire', color: '#e67e22' },
  { name: '处女座', symbol: '♍', element: 'earth', color: '#16a085' },
  { name: '天秤座', symbol: '♎', element: 'air', color: '#f39c12' },
  { name: '天蝎座', symbol: '♏', element: 'water', color: '#8e44ad' },
  { name: '射手座', symbol: '♐', element: 'fire', color: '#d35400' },
  { name: '摩羯座', symbol: '♑', element: 'earth', color: '#34495e' },
  { name: '水瓶座', symbol: '♒', element: 'air', color: '#2980b9' },
  { name: '双鱼座', symbol: '♓', element: 'water', color: '#9b59b6' }
];

// 星座四元素 → 中文名（文案用）
const ELEMENT_NAMES = { fire: '火象', earth: '土象', air: '风象', water: '水象' };

// 角度归一化到 [0, 2π)
function normAngle(rad) {
  const twoPi = Math.PI * 2;
  let n = rad % twoPi;
  if (n < 0) n += twoPi;
  return n;
}

// 格式化成 `INTJ · 天蝎座 ♏`
function formatPick(mbtiIdx, zodiacIdx) {
  const z = ZODIACS[zodiacIdx];
  return `${MBTI_TYPES[mbtiIdx]} · ${z.name} ${z.symbol}`;
}

// 简短格式 `INTJ·天蝎`（结果页信息头用）
function formatPickShort(mbtiIdx, zodiacIdx) {
  const z = ZODIACS[zodiacIdx];
  return `${MBTI_TYPES[mbtiIdx]}·${z.name.replace('座', '')}`;
}

module.exports = {
  MBTI_TYPES,
  MBTI_ROLES,
  ZODIACS,
  ELEMENT_NAMES,
  normAngle,
  formatPick,
  formatPickShort
};
