// utils/score.js — 匹配评分引擎（正式版：三层架构 + 场景层 + L3 文案多样化）
//
// 架构（对应《MBTI星座组合评价表》第九、十二章）：
//   L1 精品层：MBTI Top15 / 星座 Top15，同 key 命中精品优先（精品分权威）
//   L2 模板层：MBTI 136 / 星座 78，精品未命中时兜底
//   L3 交叉修饰：文案层，多槽位 hash seed 稳定输出（无随机数，可复现）
//   场景层公式（零随机，与 build-data.js 全量压测一致）：
//     场景综合分   = round(场景MBTI分 × 0.6 + 场景星座分 × 0.4)
//     场景MBTI分   = clamp(MBTI基础分 + 人格碰撞修正[场景], 45, 99)
//     场景星座分   = clamp(星座基础分 + 元素碰撞修正[场景], 45, 99)
//
// L3 文案多样化（第十二章）：
//   - 槽位 seed：seed(slot) = hash(`${mKey}|${zKey}|${dim}|${slot}`)，槽位间独立
//   - pros/cons 各 4 条：碰撞场景句 + MBTI 组合句(hash 选) + 星座组合句(hash 选)
//     + 特质亮点句/冲突触发句（12.6 模板 × 双方特质词）
//   - advice 三段式：组合级功课 + 给 A 建议 + 给 B 建议（12.5 扩充池）
//   - summary：碰撞底色(表 A 场景底色) + 组合 summary 槽位二选一
//
// 数据源：data/*.js（由 tools/build-data.js 从评价表文档构建）

const { MBTI_TYPES, ZODIACS } = require('./helper');

const MBTI_PAIRS = require('../data/mbti-pairs');       // 136 条
const ZODIAC_PAIRS = require('../data/zodiac-pairs');   // 78 条
const MBTI_PREMIUM = require('../data/mbti-premium');   // 15 条
const ZODIAC_PREMIUM = require('../data/zodiac-premium'); // 15 条
const MBTI_TRAITS = require('../data/mbti-traits');     // 16 型特质库
const ZODIAC_TRAITS = require('../data/zodiac-traits'); // 12 座特质库（含雷区）
const ENGINE = require('../data/scene-engine');
const { buildRelationshipCopy } = require('./relationship-copy');

const {
  formula, levels, dimBuckets, zodiacElement,
  personaCollide, elementCollide, naming,
  copyFit, copyBlock,
  advicePool, traitTemplates, conflictTemplates
} = ENGINE;

// 人格维度桶索引（'理性型' → '理性'）
const DIM_OF = {};
for (const [dim, types] of Object.entries(dimBuckets)) {
  for (const t of types) DIM_OF[t] = dim.replace('型', '');
}
const SCENE_CN = { love: '恋爱', friend: '友谊', work: '职场' };

// 无序配对 key（双向可查）：'INTJ_x_ENFP' 与 'ENFP_x_INTJ' 命中同一记录
function pairKey(a, b) {
  return [a, b].sort().join('_x_');
}
// 碰撞 key 规范化（与文档表 A/B 行序一致，优先级而非字典序）
const DIM_PRIORITY = { '理性': 0, '感性': 1, '控制': 2, '自由': 3 };
const ELEMENT_PRIORITY = { '火': 0, '土': 1, '风': 2, '水': 3 };
function collideKey(x, y, prio) {
  return (prio[x] <= prio[y] ? [x, y] : [y, x]).join('×');
}
function clamp(n) {
  return Math.max(formula.min, Math.min(formula.max, n));
}
function levelOf(score) {
  for (const L of levels) if (score >= L.min) return L.name;
  return levels[levels.length - 1].name;
}
// 稳定字符串 hash（L3 交叉修饰 seed，无随机数，保证可复现）
function hashCode(str) {
  let h = 5381;
  for (let i = 0; i < str.length; i++) h = ((h * 33) ^ str.charCodeAt(i)) >>> 0;
  return h;
}
// 模板变量填充：'{typeA} 自带「{pA}」…' → 实际文案
function fillTemplate(tpl, vars) {
  return String(tpl).replace(/\{(\w+)\}/g, (_, k) => (vars[k] !== undefined ? vars[k] : '{' + k + '}'));
}

// 「句句点名」校验：文案至少含 1 个具体标识（MBTI代码/星座名/「特质词·组合名」/维度词）
const ZODIAC_NAMES = ZODIACS.map(z => z.name.replace('座', ''));
const IDENT_RE = new RegExp(
  '(' + MBTI_TYPES.join('|') + '|' + ZODIAC_NAMES.join('|') + '|「|理性|感性|控制|自由)'
);
// 无标识句兜底：加「组合名」前缀（如「INTJ×ENFP」：相似的软肋…）
function ensureNamed(text, fallbackLabel) {
  const t = String(text);
  return IDENT_RE.test(t) ? t : `「${fallbackLabel}」：${t}`;
}
// 碰撞句维度前缀（提升命名度与可读性）：'理性×感性' → '理性遇上感性：'
function collidePrefix(pk) {
  const [x, y] = pk.split('×');
  return x === y ? `同为${x}型：` : `${x}遇上${y}：`;
}

/**
 * 计算两人匹配度（按索引输入）
 * @param {number} mA 用户A MBTI 索引（0-15）
 * @param {number} zA 用户A 星座索引（0-11）
 * @param {number} mB 用户B MBTI 索引（0-15）
 * @param {number} zB 用户B 星座索引（0-11）
 * @param {string} [dimension] 'love' | 'friend' | 'work'，默认 love
 * @returns {object} { score, level, nickname, scene, summary, advice, pros, cons, tags }
 */
function calculateCompatibility(mA, zA, mB, zB, dimension) {
  const dim = ENGINE.scenes.indexOf(dimension) >= 0 ? dimension : 'love';
  const mbtiA = MBTI_TYPES[mA];
  const mbtiB = MBTI_TYPES[mB];
  const zAName = ZODIACS[zA].name.replace('座', '');
  const zBName = ZODIACS[zB].name.replace('座', '');

  // ---------- L1 精品层 → L2 模板层 ----------
  const mKey = pairKey(mbtiA, mbtiB);
  const zKey = pairKey(zAName, zBName);
  const mRec = MBTI_PREMIUM[mKey] || MBTI_PAIRS[mKey];
  const zRec = ZODIAC_PREMIUM[zKey] || ZODIAC_PAIRS[zKey];

  // ---------- 碰撞 key ----------
  const pk = collideKey(DIM_OF[mbtiA], DIM_OF[mbtiB], DIM_PRIORITY); // 人格碰撞（表 A）
  const ek = collideKey(zodiacElement[zAName], zodiacElement[zBName], ELEMENT_PRIORITY); // 元素碰撞（表 B）

  // ---------- 场景层（评分零改动） ----------
  const sceneM = clamp(mRec.base + personaCollide[pk][dim]);
  const sceneZ = clamp(zRec.base + elementCollide[ek][dim]);
  const score = Math.round(sceneM * formula.mbtiWeight + sceneZ * formula.zodiacWeight);

  const level = levelOf(score);
  const nickname = naming[dim][level];
  const sceneCn = SCENE_CN[dim];
  // 三场景全量分（切换预取 / 分享卡片用）
  const scene = {};
  for (const s of ENGINE.scenes) {
    scene[s] = Math.round(
      clamp(mRec.base + personaCollide[pk][s]) * formula.mbtiWeight +
      clamp(zRec.base + elementCollide[ek][s]) * formula.zodiacWeight
    );
  }

  // ---------- L3 交叉修饰（文案层，多槽位 hash seed，12.2 规则） ----------
  const slotSeed = (slot) => hashCode(`${mKey}|${zKey}|${dim}|${slot}`);
  const pick = (slot, arr) => arr[slotSeed(slot) % arr.length];
  // 从 arr 选一个不等于 exclIdx 的下标（advice 组合级与磨合点 2/3 条不重复）
  const pickExcl = (slot, arr, exclIdx) => {
    if (!arr || arr.length === 0) return '';
    if (arr.length === 1) return arr[0];
    const idx = (exclIdx + 1 + slotSeed(slot) % (arr.length - 1)) % arr.length;
    return arr[idx];
  };

  const mtA = MBTI_TRAITS[mbtiA] || {};
  const mtB = MBTI_TRAITS[mbtiB] || {};
  const ztA = ZODIAC_TRAITS[zAName] || {};
  const ztB = ZODIAC_TRAITS[zBName] || {};

  // ===== 契合点 pros[4]（12.3）=====
  const pmIdx = slotSeed('pm') % mRec.fit.length;
  const pzIdx = slotSeed('pz') % zRec.fit.length;
  const ptVars = {
    typeA: mbtiA, typeB: mbtiB,
    zA: zAName, zB: zBName,
    scene: sceneCn,
    pA: pick('ptA', mtA.pos || []),
    pB: pick('ptB', mtB.pos || [])
  };
  // 同类型组合排除 T3（"补上对方的短板"对同类型语义不通），从 T1/T2 中选
  const ptPool = (mbtiA === mbtiB) ? traitTemplates.slice(0, 2) : traitTemplates;
  const pros = [
    collidePrefix(pk) + copyFit[pk][dim],        // 1. 人格碰撞场景句（9.5.1，维度前缀）
    ensureNamed(mRec.fit[pmIdx], mRec.display),  // 2. MBTI 组合契合句（hash 三选一，兜底命名）
    ensureNamed(zRec.fit[pzIdx], zRec.display),  // 3. 星座组合契合句（hash 三选一，兜底命名）
    fillTemplate(pick('pt', ptPool), ptVars)     // 4. 特质亮点句（12.6.1 模板）
  ];

  // ===== 磨合点 cons[4]（12.3）=====
  const cmIdx = slotSeed('cm') % mRec.block.length;
  const czIdx = slotSeed('cz') % zRec.block.length;
  const ctVars = {
    typeA: mbtiA, typeB: mbtiB,
    zA: zAName, zB: zBName,
    trigA: mtA.trigger || '', trigB: mtB.trigger || '',
    mineA: ztA.mine || '', mineB: ztB.mine || '',
    negA: pick('ctA', mtA.neg || []),
    negB: pick('ctB', mtB.neg || [])
  };
  const cons = [
    collidePrefix(pk) + copyBlock[pk][dim],   // 1. 人格碰撞场景句（9.5.2，维度前缀）
    ensureNamed(mRec.block[cmIdx], mRec.display), // 2. MBTI 组合磨合句（hash 二选一，兜底命名）
    ensureNamed(zRec.block[czIdx], zRec.display), // 3. 星座组合磨合句（hash 二选一，兜底命名）
    fillTemplate(pick('ct', conflictTemplates), ctVars) // 4. 冲突触发句（12.6.2 模板）
  ];

  // ===== 相处建议：三段式（12.4）=====
  // 段 1 组合级：槽位 as 定 MBTI/星座侧，句中同时点名双侧组合名（组合级唯一，抗重复）
  const asZodiac = slotSeed('as') % 2 === 1;
  const advSide = asZodiac ? zRec : mRec;
  const advExcl = asZodiac ? czIdx : cmIdx;
  const advBlock = pickExcl('as', advSide.block, advExcl);
  const adviceSeg1 = `你们这对「${mRec.name}」×「${zRec.name}」最需要修炼的：${advBlock}`;

  // 段 2/3 给 A / 给 B：12.5 扩充池按维度 × 场景三选一，前缀具体到人
  const dA = DIM_OF[mbtiA];
  const dB = DIM_OF[mbtiB];
  const poolA = (advicePool[dA + '型'] || {})[sceneCn] || [];
  const poolB = (advicePool[dB + '型'] || {})[sceneCn] || [];
  const fallbackA = ((ENGINE.advice || {})[dA + '型'] || {})[dim] || '';
  const fallbackB = ((ENGINE.advice || {})[dB + '型'] || {})[dim] || '';
  const adviceSeg2 = `给 ${mbtiA}（${mtA.nickname || dA + '型'}）：${poolA.length ? pick('aa', poolA) : fallbackA}`;
  // 双方同维度时共用同一文案池，强制给 B 选与 A 不同的句子（避免"两个人收到同一句建议"）
  const advB = (dA === dB && poolB.length && poolA.length)
    ? pickExcl('ab', poolB, slotSeed('aa') % poolA.length)
    : (poolB.length ? pick('ab', poolB) : fallbackB);
  const adviceSeg3 = `给 ${mbtiB}（${mtB.nickname || dB + '型'}）：${advB}`;

  const advice = [adviceSeg1, adviceSeg2, adviceSeg3].join('\n');
  // ---------- 关系文案层（不参与评分） ----------
  const relationCopy = buildRelationshipCopy({
    scene: dim,
    pk,
    ek,
    mbtiA,
    mbtiB,
    zAName,
    zBName,
    dimA: dA,
    dimB: dB,
    mtA,
    mtB,
    ztA,
    ztB,
    mRec,
    zRec,
    copyFit,
    copyBlock
  });

  return {
    score,
    level,
    nickname,
    scene,
    summary: relationCopy.summary,
    advice,
    adviceText: relationCopy.adviceText,
    pros,
    cons,
    fitItems: relationCopy.fitItems,
    grindItems: relationCopy.grindItems,
    tags: relationCopy.tags
  };
}

module.exports = { calculateCompatibility };
