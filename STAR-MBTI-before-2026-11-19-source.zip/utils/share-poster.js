const { MBTI_TYPES, ZODIACS } = require('./helper');

const WIDTH = 900;
const HEIGHT = 1350;
const THUMB_WIDTH = 500;
const THUMB_HEIGHT = 400;
const BACKGROUND = '/images/share/poster-bg.jpg';
// JPEG strip already includes the translucent artwork over the shaded card background.
// Keep it above the card overlay without relying on device-side WebP decoding.
const PLANET_OVERLAY = '/images/share/planet-overlay.jpg';
// 小程序码占位：正式版发布后，在 mp 后台/服务端用 wxacode.getUnlimited 生成小程序码图片，
// 存到 images/share/ 下并把路径填到这里，海报右下角即会出现可扫码入口。
// 体验版阶段保持 null（不绘制）。注意：网络 URL 需配 downloadFile 合法域名，本地路径直接可用。
const QR_IMAGE = null;
const QR_RECT = { x: 764, y: 1176, size: 104 }; // 右下角圆角白底区域
const TYPE_NAMES = [
  '独立的战略家', '思想的探索者', '果断的指挥官', '灵感的辩论家',
  '深邃的洞察者', '诗意的理想家', '温暖的引路人', '自由的追梦者',
  '可靠的实干家', '细腻的守护者', '坚定的组织者', '热忱的联结者',
  '冷静的行动派', '敏锐的艺术家', '勇敢的冒险家', '鲜活的表演者'
];

function cardModel(data) {
  return {
    key: [data.mA, data.zA, data.mB, data.zB, data.scene].join('-'),
    typeA: MBTI_TYPES[data.mA], typeB: MBTI_TYPES[data.mB],
    nameA: TYPE_NAMES[data.mA], nameB: TYPE_NAMES[data.mB],
    zodiacA: ZODIACS[data.zA].name, zodiacB: ZODIACS[data.zB].name,
    score: Math.max(0, Math.min(100, Number(data.ringScore) || 0)),
    sceneLabel: data.sceneLabel, level: data.levelName,
    keyword: data.keyword, summary: data.summary
  };
}

function roundRect(ctx, x, y, width, height, radius) {
  ctx.beginPath();
  ctx.moveTo(x + radius, y);
  ctx.arcTo(x + width, y, x + width, y + height, radius);
  ctx.arcTo(x + width, y + height, x, y + height, radius);
  ctx.arcTo(x, y + height, x, y, radius);
  ctx.arcTo(x, y, x + width, y, radius);
  ctx.closePath();
}

function text(ctx, value, x, y, size, color = '#fff0d3', align = 'center', maxWidth) {
  ctx.fillStyle = color;
  ctx.textAlign = align;
  ctx.font = `${size}px "HYDaSongJ-2", "Microsoft YaHei", serif`;
  while (maxWidth && ctx.measureText(value).width > maxWidth && size > 16) {
    size -= 1;
    ctx.font = `${size}px "HYDaSongJ-2", "Microsoft YaHei", serif`;
  }
  ctx.fillText(value, x, y);
}

function wrappedLines(ctx, value, maxWidth, maxLines) {
  const chars = Array.from(String(value || ''));
  const lines = [];
  let line = '';
  for (let index = 0; index < chars.length; index++) {
    const char = chars[index];
    if (char !== '\n' && ctx.measureText(line + char).width <= maxWidth) {
      line += char;
      continue;
    }
    if (lines.length === maxLines - 1) {
      while (line && ctx.measureText(line + '…').width > maxWidth) line = line.slice(0, -1);
      lines.push(line + '…');
      return lines;
    }
    lines.push(line);
    line = char === '\n' ? '' : char;
  }
  if (line) lines.push(line);
  return lines;
}

function ring(ctx, x, y, radius, score, lineWidth) {
  ctx.lineWidth = lineWidth;
  ctx.lineCap = 'round';
  ctx.strokeStyle = '#293879';
  ctx.beginPath();
  ctx.arc(x, y, radius, 0, Math.PI * 2);
  ctx.stroke();
  if (score > 0) {
    const gradient = ctx.createLinearGradient(x - radius, y - radius, x + radius, y + radius);
    gradient.addColorStop(0, '#fff0ba');
    gradient.addColorStop(0.6, '#f3ce8f');
    gradient.addColorStop(1, '#a56bea');
    ctx.strokeStyle = gradient;
    ctx.beginPath();
    ctx.arc(x, y, radius, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * score / 100);
    ctx.stroke();
  }
}

function background(ctx, image, width, height) {
  const scale = Math.max(width / image.width, height / image.height);
  const w = image.width * scale;
  const h = image.height * scale;
  ctx.drawImage(image, (width - w) / 2, (height - h) / 2, w, h);
  ctx.fillStyle = 'rgba(2, 6, 30, 0.48)';
  ctx.fillRect(0, 0, width, height);
}

function drawPoster(ctx, model, images) {
  background(ctx, images.background, WIDTH, HEIGHT);
  ctx.fillStyle = 'rgba(3, 8, 34, 0.54)';
  ctx.strokeStyle = '#a18be4';
  ctx.lineWidth = 2;
  roundRect(ctx, 32, 32, 836, 1286, 36);
  ctx.fill();
  ctx.stroke();

  text(ctx, 'MBTI星座', 76, 119, 56, '#fff0d3', 'left');
  text(ctx, '相性测试', 76, 184, 56, '#fff0d3', 'left');
  text(ctx, '探索两人之间的奇妙宇宙', 78, 226, 22, '#e0d5f5', 'left');
  ctx.save();
  ctx.translate(680, 130);
  ctx.rotate(-0.17);
  ctx.font = 'italic 30px Georgia, serif';
  ctx.textAlign = 'center';
  ctx.fillStyle = '#cdb2ff';
  ctx.fillText('Two Souls', 0, 0);
  ctx.fillText('One Universe', 0, 39);
  ctx.restore();

  const people = [
    { x: 72, type: model.typeA, name: model.nameA, zodiac: model.zodiacA, label: '用户 A' },
    { x: 550, type: model.typeB, name: model.nameB, zodiac: model.zodiacB, label: '用户 B' }
  ];
  people.forEach(person => {
    ctx.fillStyle = 'rgba(5, 12, 45, 0.45)';
    ctx.strokeStyle = '#7474ce';
    ctx.lineWidth = 1.5;
    roundRect(ctx, person.x, 274, 278, 232, 35);
    ctx.fill();
    ctx.stroke();
    text(ctx, person.label, person.x + 139, 312, 21, '#d6c5f1');
    text(ctx, person.type, person.x + 139, 377, 53);
    text(ctx, person.name, person.x + 139, 417, 20, '#d8cdef');
    text(ctx, person.zodiac, person.x + 139, 470, 26, '#e8d7af');
  });
  ring(ctx, 450, 388, 94, model.score, 19);
  text(ctx, `${model.score}%`, 450, 394, 41, '#ffedc5', 'center', 165);
  text(ctx, '匹配度', 450, 429, 22, '#dfd4f6');
  text(ctx, model.sceneLabel, 450, 531, 22, '#c5b7eb');

  ctx.drawImage(images.planet, 0, 630, WIDTH, 300);
  if (QR_IMAGE && images.qr) {
    ctx.fillStyle = '#ffffff';
    roundRect(ctx, QR_RECT.x, QR_RECT.y, QR_RECT.size, QR_RECT.size, 16);
    ctx.fill();
    ctx.drawImage(images.qr, QR_RECT.x + 8, QR_RECT.y + 8, QR_RECT.size - 16, QR_RECT.size - 16);
    text(ctx, '长按识别 · 测测你们的相性', QR_RECT.x + QR_RECT.size / 2, QR_RECT.y + QR_RECT.size + 30, 16, '#b7aad5', 'center');
  }
  text(ctx, model.keyword, 450, 1038, 48, '#fff0d3', 'center', 710);
  text(ctx, model.level, 450, 1080, 24, '#d2bfea');
  ctx.font = '25px "HYDaSongJ-2", "Microsoft YaHei", serif';
  const lines = wrappedLines(ctx, model.summary, 690, 3);
  lines.forEach((line, index) => text(ctx, line, 450, 1140 + index * 36, 25, '#dfd7ef'));
  ctx.beginPath();
  ctx.moveTo(180, 1224);
  ctx.lineTo(720, 1224);
  ctx.strokeStyle = 'rgba(203, 177, 255, 0.5)';
  ctx.lineWidth = 1;
  ctx.stroke();
  text(ctx, 'MBTI × ZODIAC', 450, 1288, 20, '#b7aad5');
}

function drawThumbnail(ctx, model, images) {
  background(ctx, images.background, THUMB_WIDTH, THUMB_HEIGHT);
  text(ctx, 'MBTI星座 · 相性测试', 250, 52, 29);
  text(ctx, `${model.typeA} · ${model.zodiacA}  ×  ${model.typeB} · ${model.zodiacB}`,
    250, 93, 19, '#ded2ed', 'center', 450);
  ring(ctx, 250, 224, 85, model.score, 14);
  text(ctx, `${model.score}%`, 250, 235, 48);
  text(ctx, model.sceneLabel, 250, 269, 19, '#d4c8ed');
  text(ctx, model.keyword, 250, 354, 28, '#fff0d3', 'center', 450);
}

function posterError(error, stage, source = '') {
  const message = error && (error.errMsg || error.message) || String(error || 'unknown error');
  return Object.assign(new Error(message), { stage, source });
}

function loadImage(canvas, source) {
  return new Promise((resolve, reject) => {
    let timer;
    const fail = error => {
      clearTimeout(timer);
      reject(posterError(error, 'image-load', source));
    };
    try {
      const image = canvas.createImage();
      image.onload = () => {
        clearTimeout(timer);
        resolve(image);
      };
      image.onerror = fail;
      timer = setTimeout(() => fail(new Error('image load timed out')), 12000);
      image.src = source;
    } catch (error) {
      fail(error);
    }
  });
}

async function writePng(canvas, path) {
  let png;
  try {
    const pixels = canvas.getContext('2d').getImageData(0, 0, canvas.width, canvas.height).data;
    const buffer = pixels.buffer.slice(pixels.byteOffset, pixels.byteOffset + pixels.byteLength);
    png = require('./vendor/upng').encode([buffer], canvas.width, canvas.height, 0);
  } catch (error) {
    throw posterError(error, 'png-encode', path);
  }
  try {
    await new Promise((resolve, reject) => {
      wx.getFileSystemManager().writeFile({ filePath: path, data: png, success: resolve, fail: reject });
    });
  } catch (error) {
    throw posterError(error, 'file-write', path);
  }
  return path;
}

function removePoster(poster) {
  if (!poster) return;
  [poster.posterPath, poster.thumbnailPath].filter(Boolean).forEach(filePath => {
    wx.getFileSystemManager().unlink({ filePath, fail() {} });
  });
}

let sequence = 0;
async function createPoster(model) {
  const files = {
    key: model.key,
    posterPath: `${wx.env.USER_DATA_PATH}/mbti-poster-${Date.now()}-${++sequence}.png`,
    thumbnailPath: `${wx.env.USER_DATA_PATH}/mbti-thumb-${Date.now()}-${sequence}.png`
  };
  let stage = 'canvas-init';
  try {
    const canvas = wx.createOffscreenCanvas({ type: '2d', width: WIDTH, height: HEIGHT });
    stage = 'poster-assets-load';
    const loads = [loadImage(canvas, BACKGROUND), loadImage(canvas, PLANET_OVERLAY)];
    if (QR_IMAGE) loads.push(loadImage(canvas, QR_IMAGE));
    const [bg, planet, qr] = await Promise.all(loads);
    const images = { background: bg, planet, qr };
    stage = 'poster-draw';
    drawPoster(canvas.getContext('2d'), model, images);
    await writePng(canvas, files.posterPath);
    stage = 'thumbnail-canvas-init';
    const thumb = wx.createOffscreenCanvas({ type: '2d', width: THUMB_WIDTH, height: THUMB_HEIGHT });
    const thumbBg = await loadImage(thumb, BACKGROUND);
    stage = 'thumbnail-draw';
    drawThumbnail(thumb.getContext('2d'), model, { background: thumbBg });
    await writePng(thumb, files.thumbnailPath);
    return files;
  } catch (error) {
    removePoster(files);
    throw error && error.stage ? error : posterError(error, stage);
  }
}

module.exports = { cardModel, createPoster, removePoster, drawPoster, drawThumbnail, wrappedLines, WIDTH, HEIGHT };
