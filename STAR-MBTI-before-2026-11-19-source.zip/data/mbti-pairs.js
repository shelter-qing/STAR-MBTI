// Auto-generated from mbti-pairs.json — DO NOT EDIT
module.exports = {
  "INTJ_x_INTJ": {
    "a": "INTJ",
    "b": "INTJ",
    "key": "INTJ_x_INTJ",
    "display": "INTJ×INTJ",
    "name": "镜像双生",
    "base": 73,
    "fit": [
      "双方都擅长洞察力，沟通成本极低",
      "对独立和完美主义有天然默契",
      "能理解对方对长远规划的坚持"
    ],
    "block": [
      "两个人都容易情感疏离，问题出现时容易一起卡住",
      "相同视角可能放大盲区，缺少互补"
    ],
    "summary": "两个建筑师相遇，是知己也是镜子。理解彼此很容易，但别让相似变成 stagnation，记得主动引入新鲜视角。"
  },
  "INTJ_x_INTP": {
    "a": "INTJ",
    "b": "INTP",
    "key": "INTJ_x_INTP",
    "display": "INTJ×INTP",
    "name": "互相成就的搭档",
    "base": 60,
    "fit": [
      "INTJ的洞察力与INTP的逻辑力形成互补",
      "INTJ擅长战略，INTP擅长思辨，配合起来更全面",
      "INTJ的理性能稳住INTP的抽离，互相平衡"
    ],
    "block": [
      "INTJ的情感疏离可能让INTP感到疏离或受挫",
      "INTP的拖延逃避有时会让INTJ摸不着头脑"
    ],
    "summary": "INTJ和INTP有吸引力也有张力，一个像长远规划，一个像分析，磨合好了是成长型关系。"
  },
  "ENTJ_x_INTJ": {
    "a": "INTJ",
    "b": "ENTJ",
    "key": "ENTJ_x_INTJ",
    "display": "INTJ×ENTJ",
    "name": "理性与感性的平衡",
    "base": 73,
    "fit": [
      "INTJ的洞察力与ENTJ的执行力形成互补",
      "INTJ擅长战略，ENTJ擅长果断，配合起来更全面",
      "INTJ的理性能稳住ENTJ的效率，互相平衡"
    ],
    "block": [
      "INTJ的情感疏离可能让ENTJ感到疏离或受挫",
      "ENTJ的缺乏耐心有时会让INTJ摸不着头脑"
    ],
    "summary": "INTJ与ENTJ是少见的互补型组合，分析家与分析家的碰撞既能互相激发，又能互相兜底。"
  },
  "ENTP_x_INTJ": {
    "a": "INTJ",
    "b": "ENTP",
    "key": "ENTP_x_INTJ",
    "display": "INTJ×ENTP",
    "name": "理性与感性的平衡",
    "base": 80,
    "fit": [
      "INTJ的洞察力与ENTP的创造力形成互补",
      "INTJ擅长战略，ENTP擅长创意，配合起来更全面",
      "INTJ的理性能稳住ENTP的挑战，互相平衡"
    ],
    "block": [
      "INTJ的情感疏离可能让ENTP感到疏离或受挫",
      "ENTP的不够专注有时会让INTJ摸不着头脑"
    ],
    "summary": "INTJ与ENTP是少见的互补型组合，分析家与分析家的碰撞既能互相激发，又能互相兜底。"
  },
  "INFJ_x_INTJ": {
    "a": "INTJ",
    "b": "INFJ",
    "key": "INFJ_x_INTJ",
    "display": "INTJ×INFJ",
    "name": "互相成就的搭档",
    "base": 62,
    "fit": [
      "INTJ的洞察力与INFJ的理解力形成互补",
      "INTJ擅长战略，INFJ擅长洞察，配合起来更全面",
      "INTJ的理性能稳住INFJ的深度，互相平衡"
    ],
    "block": [
      "INTJ的情感疏离可能让INFJ感到疏离或受挫",
      "INFJ的过度内耗有时会让INTJ摸不着头脑"
    ],
    "summary": "INTJ和INFJ有吸引力也有张力，一个像长远规划，一个像神秘，磨合好了是成长型关系。"
  },
  "INFP_x_INTJ": {
    "a": "INTJ",
    "b": "INFP",
    "key": "INFP_x_INTJ",
    "display": "INTJ×INFP",
    "name": "互相成就的搭档",
    "base": 84,
    "fit": [
      "INTJ的洞察力与INFP的共情力形成互补",
      "INTJ擅长战略，INFP擅长诗意，配合起来更全面",
      "INTJ的理性能稳住INFP的价值，互相平衡"
    ],
    "block": [
      "INTJ的情感疏离可能让INFP感到疏离或受挫",
      "INFP的容易受伤有时会让INTJ摸不着头脑"
    ],
    "summary": "INTJ和INFP有吸引力也有张力，一个像长远规划，一个像内省，磨合好了是成长型关系。"
  },
  "ENFJ_x_INTJ": {
    "a": "INTJ",
    "b": "ENFJ",
    "key": "ENFJ_x_INTJ",
    "display": "INTJ×ENFJ",
    "name": "理性与感性的平衡",
    "base": 79,
    "fit": [
      "INTJ的洞察力与ENFJ的凝聚力形成互补",
      "INTJ擅长战略，ENFJ擅长感染力，配合起来更全面",
      "INTJ的理性能稳住ENFJ的温暖，互相平衡"
    ],
    "block": [
      "INTJ的情感疏离可能让ENFJ感到疏离或受挫",
      "ENFJ的过度付出有时会让INTJ摸不着头脑"
    ],
    "summary": "INTJ与ENFJ是少见的互补型组合，分析家与外交官的碰撞既能互相激发，又能互相兜底。"
  },
  "ENFP_x_INTJ": {
    "a": "INTJ",
    "b": "ENFP",
    "key": "ENFP_x_INTJ",
    "display": "INTJ×ENFP",
    "name": "智性恋天花板",
    "base": 82,
    "fit": [
      "INTJ的洞察力与ENFP的感染力形成互补",
      "INTJ擅长战略，ENFP擅长热情，配合起来更全面",
      "INTJ的理性能稳住ENFP的自由，互相平衡"
    ],
    "block": [
      "INTJ的情感疏离可能让ENFP感到疏离或受挫",
      "ENFP的情绪起伏有时会让INTJ摸不着头脑"
    ],
    "summary": "INTJ与ENFP是少见的互补型组合，分析家与外交官的碰撞既能互相激发，又能互相兜底。"
  },
  "INTJ_x_ISTJ": {
    "a": "INTJ",
    "b": "ISTJ",
    "key": "INTJ_x_ISTJ",
    "display": "INTJ×ISTJ",
    "name": "需要磨合的潜力股",
    "base": 51,
    "fit": [
      "INTJ的洞察力与ISTJ的可靠性形成互补",
      "INTJ擅长战略，ISTJ擅长可靠，配合起来更全面",
      "INTJ的理性能稳住ISTJ的规则，互相平衡"
    ],
    "block": [
      "INTJ的情感疏离可能让ISTJ感到疏离或受挫",
      "ISTJ的缺乏变通有时会让INTJ摸不着头脑"
    ],
    "summary": "INTJ和ISTJ有吸引力也有张力，一个像长远规划，一个像责任，磨合好了是成长型关系。"
  },
  "INTJ_x_ISFJ": {
    "a": "INTJ",
    "b": "ISFJ",
    "key": "INTJ_x_ISFJ",
    "display": "INTJ×ISFJ",
    "name": "互相成就的搭档",
    "base": 57,
    "fit": [
      "INTJ的洞察力与ISFJ的体贴度形成互补",
      "INTJ擅长战略，ISFJ擅长温柔，配合起来更全面",
      "INTJ的理性能稳住ISFJ的稳定，互相平衡"
    ],
    "block": [
      "INTJ的情感疏离可能让ISFJ感到疏离或受挫",
      "ISFJ的不善拒绝有时会让INTJ摸不着头脑"
    ],
    "summary": "INTJ和ISFJ有吸引力也有张力，一个像长远规划，一个像奉献，磨合好了是成长型关系。"
  },
  "ESTJ_x_INTJ": {
    "a": "INTJ",
    "b": "ESTJ",
    "key": "ESTJ_x_INTJ",
    "display": "INTJ×ESTJ",
    "name": "互相成就的搭档",
    "base": 62,
    "fit": [
      "INTJ的洞察力与ESTJ的统筹力形成互补",
      "INTJ擅长战略，ESTJ擅长组织，配合起来更全面",
      "INTJ的理性能稳住ESTJ的直接，互相平衡"
    ],
    "block": [
      "INTJ的情感疏离可能让ESTJ感到疏离或受挫",
      "ESTJ的过于武断有时会让INTJ摸不着头脑"
    ],
    "summary": "INTJ和ESTJ有吸引力也有张力，一个像长远规划，一个像结果，磨合好了是成长型关系。"
  },
  "ESFJ_x_INTJ": {
    "a": "INTJ",
    "b": "ESFJ",
    "key": "ESFJ_x_INTJ",
    "display": "INTJ×ESFJ",
    "name": "互相成就的搭档",
    "base": 66,
    "fit": [
      "INTJ的洞察力与ESFJ的亲和力形成互补",
      "INTJ擅长战略，ESFJ擅长合群，配合起来更全面",
      "INTJ的理性能稳住ESFJ的社交，互相平衡"
    ],
    "block": [
      "INTJ的情感疏离可能让ESFJ感到疏离或受挫",
      "ESFJ的在意评价有时会让INTJ摸不着头脑"
    ],
    "summary": "INTJ和ESFJ有吸引力也有张力，一个像长远规划，一个像热心，磨合好了是成长型关系。"
  },
  "INTJ_x_ISTP": {
    "a": "INTJ",
    "b": "ISTP",
    "key": "INTJ_x_ISTP",
    "display": "INTJ×ISTP",
    "name": "需要磨合的潜力股",
    "base": 48,
    "fit": [
      "INTJ的洞察力与ISTP的应变力形成互补",
      "INTJ擅长战略，ISTP擅长冷静，配合起来更全面",
      "INTJ的理性能稳住ISTP的独立，互相平衡"
    ],
    "block": [
      "INTJ的情感疏离可能让ISTP感到疏离或受挫",
      "ISTP的情感冷淡有时会让INTJ摸不着头脑"
    ],
    "summary": "INTJ和ISTP有吸引力也有张力，一个像长远规划，一个像随性，磨合好了是成长型关系。"
  },
  "INTJ_x_ISFP": {
    "a": "INTJ",
    "b": "ISFP",
    "key": "INTJ_x_ISFP",
    "display": "INTJ×ISFP",
    "name": "互相成就的搭档",
    "base": 53,
    "fit": [
      "INTJ的洞察力与ISFP的审美力形成互补",
      "INTJ擅长战略，ISFP擅长艺术，配合起来更全面",
      "INTJ的理性能稳住ISFP的温和，互相平衡"
    ],
    "block": [
      "INTJ的情感疏离可能让ISFP感到疏离或受挫",
      "ISFP的回避冲突有时会让INTJ摸不着头脑"
    ],
    "summary": "INTJ和ISFP有吸引力也有张力，一个像长远规划，一个像自由，磨合好了是成长型关系。"
  },
  "ESTP_x_INTJ": {
    "a": "INTJ",
    "b": "ESTP",
    "key": "ESTP_x_INTJ",
    "display": "INTJ×ESTP",
    "name": "互相成就的搭档",
    "base": 57,
    "fit": [
      "INTJ的洞察力与ESTP的行动力形成互补",
      "INTJ擅长战略，ESTP擅长行动，配合起来更全面",
      "INTJ的理性能稳住ESTP的现实，互相平衡"
    ],
    "block": [
      "INTJ的情感疏离可能让ESTP感到疏离或受挫",
      "ESTP的冲动短视有时会让INTJ摸不着头脑"
    ],
    "summary": "INTJ和ESTP有吸引力也有张力，一个像长远规划，一个像应变，磨合好了是成长型关系。"
  },
  "ESFP_x_INTJ": {
    "a": "INTJ",
    "b": "ESFP",
    "key": "ESFP_x_INTJ",
    "display": "INTJ×ESFP",
    "name": "需要磨合的潜力股",
    "base": 46,
    "fit": [
      "INTJ的洞察力与ESFP的表现力形成互补",
      "INTJ擅长战略，ESFP擅长活泼，配合起来更全面",
      "INTJ的理性能稳住ESFP的社交，互相平衡"
    ],
    "block": [
      "INTJ的情感疏离可能让ESFP感到疏离或受挫",
      "ESFP的逃避责任有时会让INTJ摸不着头脑"
    ],
    "summary": "INTJ与ESFP像是两种运行系统，一个讲理性，一个讲社交，要走到一起需要大量翻译和耐心。"
  },
  "INTP_x_INTP": {
    "a": "INTP",
    "b": "INTP",
    "key": "INTP_x_INTP",
    "display": "INTP×INTP",
    "name": "镜像双生",
    "base": 73,
    "fit": [
      "双方都擅长逻辑力，沟通成本极低",
      "对好奇和理论有天然默契",
      "能理解对方对分析的坚持"
    ],
    "block": [
      "两个人都容易拖延逃避，问题出现时容易一起卡住",
      "相同视角可能放大盲区，缺少互补"
    ],
    "summary": "两个逻辑学家相遇，是知己也是镜子。理解彼此很容易，但别让相似变成 stagnation，记得主动引入新鲜视角。"
  },
  "ENTJ_x_INTP": {
    "a": "INTP",
    "b": "ENTJ",
    "key": "ENTJ_x_INTP",
    "display": "INTP×ENTJ",
    "name": "理性与感性的平衡",
    "base": 76,
    "fit": [
      "INTP的逻辑力与ENTJ的执行力形成互补",
      "INTP擅长思辨，ENTJ擅长果断，配合起来更全面",
      "INTP的抽离能稳住ENTJ的效率，互相平衡"
    ],
    "block": [
      "INTP的拖延逃避可能让ENTJ感到疏离或受挫",
      "ENTJ的缺乏耐心有时会让INTP摸不着头脑"
    ],
    "summary": "INTP与ENTJ是少见的互补型组合，分析家与分析家的碰撞既能互相激发，又能互相兜底。"
  },
  "ENTP_x_INTP": {
    "a": "INTP",
    "b": "ENTP",
    "key": "ENTP_x_INTP",
    "display": "INTP×ENTP",
    "name": "理性与感性的平衡",
    "base": 73,
    "fit": [
      "INTP的逻辑力与ENTP的创造力形成互补",
      "INTP擅长思辨，ENTP擅长创意，配合起来更全面",
      "INTP的抽离能稳住ENTP的挑战，互相平衡"
    ],
    "block": [
      "INTP的拖延逃避可能让ENTP感到疏离或受挫",
      "ENTP的不够专注有时会让INTP摸不着头脑"
    ],
    "summary": "INTP与ENTP是少见的互补型组合，分析家与分析家的碰撞既能互相激发，又能互相兜底。"
  },
  "INFJ_x_INTP": {
    "a": "INTP",
    "b": "INFJ",
    "key": "INFJ_x_INTP",
    "display": "INTP×INFJ",
    "name": "互相成就的搭档",
    "base": 57,
    "fit": [
      "INTP的逻辑力与INFJ的理解力形成互补",
      "INTP擅长思辨，INFJ擅长洞察，配合起来更全面",
      "INTP的抽离能稳住INFJ的深度，互相平衡"
    ],
    "block": [
      "INTP的拖延逃避可能让INFJ感到疏离或受挫",
      "INFJ的过度内耗有时会让INTP摸不着头脑"
    ],
    "summary": "INTP和INFJ有吸引力也有张力，一个像分析，一个像神秘，磨合好了是成长型关系。"
  },
  "INFP_x_INTP": {
    "a": "INTP",
    "b": "INFP",
    "key": "INFP_x_INTP",
    "display": "INTP×INFP",
    "name": "互相成就的搭档",
    "base": 62,
    "fit": [
      "INTP的逻辑力与INFP的共情力形成互补",
      "INTP擅长思辨，INFP擅长诗意，配合起来更全面",
      "INTP的抽离能稳住INFP的价值，互相平衡"
    ],
    "block": [
      "INTP的拖延逃避可能让INFP感到疏离或受挫",
      "INFP的容易受伤有时会让INTP摸不着头脑"
    ],
    "summary": "INTP和INFP有吸引力也有张力，一个像分析，一个像内省，磨合好了是成长型关系。"
  },
  "ENFJ_x_INTP": {
    "a": "INTP",
    "b": "ENFJ",
    "key": "ENFJ_x_INTP",
    "display": "INTP×ENFJ",
    "name": "智性恋天花板",
    "base": 78,
    "fit": [
      "INTP的逻辑力与ENFJ的凝聚力形成互补",
      "INTP擅长思辨，ENFJ擅长感染力，配合起来更全面",
      "INTP的抽离能稳住ENFJ的温暖，互相平衡"
    ],
    "block": [
      "INTP的拖延逃避可能让ENFJ感到疏离或受挫",
      "ENFJ的过度付出有时会让INTP摸不着头脑"
    ],
    "summary": "INTP与ENFJ是少见的互补型组合，分析家与外交官的碰撞既能互相激发，又能互相兜底。"
  },
  "ENFP_x_INTP": {
    "a": "INTP",
    "b": "ENFP",
    "key": "ENFP_x_INTP",
    "display": "INTP×ENFP",
    "name": "理性与感性的平衡",
    "base": 83,
    "fit": [
      "INTP的逻辑力与ENFP的感染力形成互补",
      "INTP擅长思辨，ENFP擅长热情，配合起来更全面",
      "INTP的抽离能稳住ENFP的自由，互相平衡"
    ],
    "block": [
      "INTP的拖延逃避可能让ENFP感到疏离或受挫",
      "ENFP的情绪起伏有时会让INTP摸不着头脑"
    ],
    "summary": "INTP与ENFP是少见的互补型组合，分析家与外交官的碰撞既能互相激发，又能互相兜底。"
  },
  "INTP_x_ISTJ": {
    "a": "INTP",
    "b": "ISTJ",
    "key": "INTP_x_ISTJ",
    "display": "INTP×ISTJ",
    "name": "需要磨合的潜力股",
    "base": 48,
    "fit": [
      "INTP的逻辑力与ISTJ的可靠性形成互补",
      "INTP擅长思辨，ISTJ擅长可靠，配合起来更全面",
      "INTP的抽离能稳住ISTJ的规则，互相平衡"
    ],
    "block": [
      "INTP的拖延逃避可能让ISTJ感到疏离或受挫",
      "ISTJ的缺乏变通有时会让INTP摸不着头脑"
    ],
    "summary": "INTP和ISTJ有吸引力也有张力，一个像分析，一个像责任，磨合好了是成长型关系。"
  },
  "INTP_x_ISFJ": {
    "a": "INTP",
    "b": "ISFJ",
    "key": "INTP_x_ISFJ",
    "display": "INTP×ISFJ",
    "name": "互相成就的搭档",
    "base": 53,
    "fit": [
      "INTP的逻辑力与ISFJ的体贴度形成互补",
      "INTP擅长思辨，ISFJ擅长温柔，配合起来更全面",
      "INTP的抽离能稳住ISFJ的稳定，互相平衡"
    ],
    "block": [
      "INTP的拖延逃避可能让ISFJ感到疏离或受挫",
      "ISFJ的不善拒绝有时会让INTP摸不着头脑"
    ],
    "summary": "INTP和ISFJ有吸引力也有张力，一个像分析，一个像奉献，磨合好了是成长型关系。"
  },
  "ESTJ_x_INTP": {
    "a": "INTP",
    "b": "ESTJ",
    "key": "ESTJ_x_INTP",
    "display": "INTP×ESTJ",
    "name": "互相成就的搭档",
    "base": 57,
    "fit": [
      "INTP的逻辑力与ESTJ的统筹力形成互补",
      "INTP擅长思辨，ESTJ擅长组织，配合起来更全面",
      "INTP的抽离能稳住ESTJ的直接，互相平衡"
    ],
    "block": [
      "INTP的拖延逃避可能让ESTJ感到疏离或受挫",
      "ESTJ的过于武断有时会让INTP摸不着头脑"
    ],
    "summary": "INTP和ESTJ有吸引力也有张力，一个像分析，一个像结果，磨合好了是成长型关系。"
  },
  "ESFJ_x_INTP": {
    "a": "INTP",
    "b": "ESFJ",
    "key": "ESFJ_x_INTP",
    "display": "INTP×ESFJ",
    "name": "需要磨合的潜力股",
    "base": 46,
    "fit": [
      "INTP的逻辑力与ESFJ的亲和力形成互补",
      "INTP擅长思辨，ESFJ擅长合群，配合起来更全面",
      "INTP的抽离能稳住ESFJ的社交，互相平衡"
    ],
    "block": [
      "INTP的拖延逃避可能让ESFJ感到疏离或受挫",
      "ESFJ的在意评价有时会让INTP摸不着头脑"
    ],
    "summary": "INTP与ESFJ像是两种运行系统，一个讲抽离，一个讲社交，要走到一起需要大量翻译和耐心。"
  },
  "INTP_x_ISTP": {
    "a": "INTP",
    "b": "ISTP",
    "key": "INTP_x_ISTP",
    "display": "INTP×ISTP",
    "name": "需要磨合的潜力股",
    "base": 51,
    "fit": [
      "INTP的逻辑力与ISTP的应变力形成互补",
      "INTP擅长思辨，ISTP擅长冷静，配合起来更全面",
      "INTP的抽离能稳住ISTP的独立，互相平衡"
    ],
    "block": [
      "INTP的拖延逃避可能让ISTP感到疏离或受挫",
      "ISTP的情感冷淡有时会让INTP摸不着头脑"
    ],
    "summary": "INTP和ISTP有吸引力也有张力，一个像分析，一个像随性，磨合好了是成长型关系。"
  },
  "INTP_x_ISFP": {
    "a": "INTP",
    "b": "ISFP",
    "key": "INTP_x_ISFP",
    "display": "INTP×ISFP",
    "name": "互相成就的搭档",
    "base": 57,
    "fit": [
      "INTP的逻辑力与ISFP的审美力形成互补",
      "INTP擅长思辨，ISFP擅长艺术，配合起来更全面",
      "INTP的抽离能稳住ISFP的温和，互相平衡"
    ],
    "block": [
      "INTP的拖延逃避可能让ISFP感到疏离或受挫",
      "ISFP的回避冲突有时会让INTP摸不着头脑"
    ],
    "summary": "INTP和ISFP有吸引力也有张力，一个像分析，一个像自由，磨合好了是成长型关系。"
  },
  "ESTP_x_INTP": {
    "a": "INTP",
    "b": "ESTP",
    "key": "ESTP_x_INTP",
    "display": "INTP×ESTP",
    "name": "互相成就的搭档",
    "base": 62,
    "fit": [
      "INTP的逻辑力与ESTP的行动力形成互补",
      "INTP擅长思辨，ESTP擅长行动，配合起来更全面",
      "INTP的抽离能稳住ESTP的现实，互相平衡"
    ],
    "block": [
      "INTP的拖延逃避可能让ESTP感到疏离或受挫",
      "ESTP的冲动短视有时会让INTP摸不着头脑"
    ],
    "summary": "INTP和ESTP有吸引力也有张力，一个像分析，一个像应变，磨合好了是成长型关系。"
  },
  "ESFP_x_INTP": {
    "a": "INTP",
    "b": "ESFP",
    "key": "ESFP_x_INTP",
    "display": "INTP×ESFP",
    "name": "互相成就的搭档",
    "base": 66,
    "fit": [
      "INTP的逻辑力与ESFP的表现力形成互补",
      "INTP擅长思辨，ESFP擅长活泼，配合起来更全面",
      "INTP的抽离能稳住ESFP的社交，互相平衡"
    ],
    "block": [
      "INTP的拖延逃避可能让ESFP感到疏离或受挫",
      "ESFP的逃避责任有时会让INTP摸不着头脑"
    ],
    "summary": "INTP和ESFP有吸引力也有张力，一个像分析，一个像即兴，磨合好了是成长型关系。"
  },
  "ENTJ_x_ENTJ": {
    "a": "ENTJ",
    "b": "ENTJ",
    "key": "ENTJ_x_ENTJ",
    "display": "ENTJ×ENTJ",
    "name": "镜像双生",
    "base": 73,
    "fit": [
      "双方都擅长执行力，沟通成本极低",
      "对领导力和目标导向有天然默契",
      "能理解对方对强势的坚持"
    ],
    "block": [
      "两个人都容易缺乏耐心，问题出现时容易一起卡住",
      "相同视角可能放大盲区，缺少互补"
    ],
    "summary": "两个指挥官相遇，是知己也是镜子。理解彼此很容易，但别让相似变成 stagnation，记得主动引入新鲜视角。"
  },
  "ENTJ_x_ENTP": {
    "a": "ENTJ",
    "b": "ENTP",
    "key": "ENTJ_x_ENTP",
    "display": "ENTJ×ENTP",
    "name": "互相成就的搭档",
    "base": 60,
    "fit": [
      "ENTJ的执行力与ENTP的创造力形成互补",
      "ENTJ擅长果断，ENTP擅长创意，配合起来更全面",
      "ENTJ的效率能稳住ENTP的挑战，互相平衡"
    ],
    "block": [
      "ENTJ的缺乏耐心可能让ENTP感到疏离或受挫",
      "ENTP的不够专注有时会让ENTJ摸不着头脑"
    ],
    "summary": "ENTJ和ENTP有吸引力也有张力，一个像强势，一个像玩心，磨合好了是成长型关系。"
  },
  "ENTJ_x_INFJ": {
    "a": "ENTJ",
    "b": "INFJ",
    "key": "ENTJ_x_INFJ",
    "display": "ENTJ×INFJ",
    "name": "理性与感性的平衡",
    "base": 69,
    "fit": [
      "ENTJ的执行力与INFJ的理解力形成互补",
      "ENTJ擅长果断，INFJ擅长洞察，配合起来更全面",
      "ENTJ的效率能稳住INFJ的深度，互相平衡"
    ],
    "block": [
      "ENTJ的缺乏耐心可能让INFJ感到疏离或受挫",
      "INFJ的过度内耗有时会让ENTJ摸不着头脑"
    ],
    "summary": "ENTJ与INFJ是少见的互补型组合，分析家与外交官的碰撞既能互相激发，又能互相兜底。"
  },
  "ENTJ_x_INFP": {
    "a": "ENTJ",
    "b": "INFP",
    "key": "ENTJ_x_INFP",
    "display": "ENTJ×INFP",
    "name": "智性恋天花板",
    "base": 75,
    "fit": [
      "ENTJ的执行力与INFP的共情力形成互补",
      "ENTJ擅长果断，INFP擅长诗意，配合起来更全面",
      "ENTJ的效率能稳住INFP的价值，互相平衡"
    ],
    "block": [
      "ENTJ的缺乏耐心可能让INFP感到疏离或受挫",
      "INFP的容易受伤有时会让ENTJ摸不着头脑"
    ],
    "summary": "ENTJ与INFP是少见的互补型组合，分析家与外交官的碰撞既能互相激发，又能互相兜底。"
  },
  "ENFJ_x_ENTJ": {
    "a": "ENTJ",
    "b": "ENFJ",
    "key": "ENFJ_x_ENTJ",
    "display": "ENTJ×ENFJ",
    "name": "互相成就的搭档",
    "base": 62,
    "fit": [
      "ENTJ的执行力与ENFJ的凝聚力形成互补",
      "ENTJ擅长果断，ENFJ擅长感染力，配合起来更全面",
      "ENTJ的效率能稳住ENFJ的温暖，互相平衡"
    ],
    "block": [
      "ENTJ的缺乏耐心可能让ENFJ感到疏离或受挫",
      "ENFJ的过度付出有时会让ENTJ摸不着头脑"
    ],
    "summary": "ENTJ和ENFJ有吸引力也有张力，一个像强势，一个像热情，磨合好了是成长型关系。"
  },
  "ENFP_x_ENTJ": {
    "a": "ENTJ",
    "b": "ENFP",
    "key": "ENFP_x_ENTJ",
    "display": "ENTJ×ENFP",
    "name": "互相成就的搭档",
    "base": 57,
    "fit": [
      "ENTJ的执行力与ENFP的感染力形成互补",
      "ENTJ擅长果断，ENFP擅长热情，配合起来更全面",
      "ENTJ的效率能稳住ENFP的自由，互相平衡"
    ],
    "block": [
      "ENTJ的缺乏耐心可能让ENFP感到疏离或受挫",
      "ENFP的情绪起伏有时会让ENTJ摸不着头脑"
    ],
    "summary": "ENTJ和ENFP有吸引力也有张力，一个像强势，一个像乐观，磨合好了是成长型关系。"
  },
  "ENTJ_x_ISTJ": {
    "a": "ENTJ",
    "b": "ISTJ",
    "key": "ENTJ_x_ISTJ",
    "display": "ENTJ×ISTJ",
    "name": "互相成就的搭档",
    "base": 62,
    "fit": [
      "ENTJ的执行力与ISTJ的可靠性形成互补",
      "ENTJ擅长果断，ISTJ擅长可靠，配合起来更全面",
      "ENTJ的效率能稳住ISTJ的规则，互相平衡"
    ],
    "block": [
      "ENTJ的缺乏耐心可能让ISTJ感到疏离或受挫",
      "ISTJ的缺乏变通有时会让ENTJ摸不着头脑"
    ],
    "summary": "ENTJ和ISTJ有吸引力也有张力，一个像强势，一个像责任，磨合好了是成长型关系。"
  },
  "ENTJ_x_ISFJ": {
    "a": "ENTJ",
    "b": "ISFJ",
    "key": "ENTJ_x_ISFJ",
    "display": "ENTJ×ISFJ",
    "name": "互相成就的搭档",
    "base": 66,
    "fit": [
      "ENTJ的执行力与ISFJ的体贴度形成互补",
      "ENTJ擅长果断，ISFJ擅长温柔，配合起来更全面",
      "ENTJ的效率能稳住ISFJ的稳定，互相平衡"
    ],
    "block": [
      "ENTJ的缺乏耐心可能让ISFJ感到疏离或受挫",
      "ISFJ的不善拒绝有时会让ENTJ摸不着头脑"
    ],
    "summary": "ENTJ和ISFJ有吸引力也有张力，一个像强势，一个像奉献，磨合好了是成长型关系。"
  },
  "ENTJ_x_ESTJ": {
    "a": "ENTJ",
    "b": "ESTJ",
    "key": "ENTJ_x_ESTJ",
    "display": "ENTJ×ESTJ",
    "name": "需要磨合的潜力股",
    "base": 51,
    "fit": [
      "ENTJ的执行力与ESTJ的统筹力形成互补",
      "ENTJ擅长果断，ESTJ擅长组织，配合起来更全面",
      "ENTJ的效率能稳住ESTJ的直接，互相平衡"
    ],
    "block": [
      "ENTJ的缺乏耐心可能让ESTJ感到疏离或受挫",
      "ESTJ的过于武断有时会让ENTJ摸不着头脑"
    ],
    "summary": "ENTJ和ESTJ有吸引力也有张力，一个像强势，一个像结果，磨合好了是成长型关系。"
  },
  "ENTJ_x_ESFJ": {
    "a": "ENTJ",
    "b": "ESFJ",
    "key": "ENTJ_x_ESFJ",
    "display": "ENTJ×ESFJ",
    "name": "互相成就的搭档",
    "base": 57,
    "fit": [
      "ENTJ的执行力与ESFJ的亲和力形成互补",
      "ENTJ擅长果断，ESFJ擅长合群，配合起来更全面",
      "ENTJ的效率能稳住ESFJ的社交，互相平衡"
    ],
    "block": [
      "ENTJ的缺乏耐心可能让ESFJ感到疏离或受挫",
      "ESFJ的在意评价有时会让ENTJ摸不着头脑"
    ],
    "summary": "ENTJ和ESFJ有吸引力也有张力，一个像强势，一个像热心，磨合好了是成长型关系。"
  },
  "ENTJ_x_ISTP": {
    "a": "ENTJ",
    "b": "ISTP",
    "key": "ENTJ_x_ISTP",
    "display": "ENTJ×ISTP",
    "name": "互相成就的搭档",
    "base": 57,
    "fit": [
      "ENTJ的执行力与ISTP的应变力形成互补",
      "ENTJ擅长果断，ISTP擅长冷静，配合起来更全面",
      "ENTJ的效率能稳住ISTP的独立，互相平衡"
    ],
    "block": [
      "ENTJ的缺乏耐心可能让ISTP感到疏离或受挫",
      "ISTP的情感冷淡有时会让ENTJ摸不着头脑"
    ],
    "summary": "ENTJ和ISTP有吸引力也有张力，一个像强势，一个像随性，磨合好了是成长型关系。"
  },
  "ENTJ_x_ISFP": {
    "a": "ENTJ",
    "b": "ISFP",
    "key": "ENTJ_x_ISFP",
    "display": "ENTJ×ISFP",
    "name": "需要磨合的潜力股",
    "base": 46,
    "fit": [
      "ENTJ的执行力与ISFP的审美力形成互补",
      "ENTJ擅长果断，ISFP擅长艺术，配合起来更全面",
      "ENTJ的效率能稳住ISFP的温和，互相平衡"
    ],
    "block": [
      "ENTJ的缺乏耐心可能让ISFP感到疏离或受挫",
      "ISFP的回避冲突有时会让ENTJ摸不着头脑"
    ],
    "summary": "ENTJ与ISFP像是两种运行系统，一个讲效率，一个讲温和，要走到一起需要大量翻译和耐心。"
  },
  "ENTJ_x_ESTP": {
    "a": "ENTJ",
    "b": "ESTP",
    "key": "ENTJ_x_ESTP",
    "display": "ENTJ×ESTP",
    "name": "需要磨合的潜力股",
    "base": 48,
    "fit": [
      "ENTJ的执行力与ESTP的行动力形成互补",
      "ENTJ擅长果断，ESTP擅长行动，配合起来更全面",
      "ENTJ的效率能稳住ESTP的现实，互相平衡"
    ],
    "block": [
      "ENTJ的缺乏耐心可能让ESTP感到疏离或受挫",
      "ESTP的冲动短视有时会让ENTJ摸不着头脑"
    ],
    "summary": "ENTJ和ESTP有吸引力也有张力，一个像强势，一个像应变，磨合好了是成长型关系。"
  },
  "ENTJ_x_ESFP": {
    "a": "ENTJ",
    "b": "ESFP",
    "key": "ENTJ_x_ESFP",
    "display": "ENTJ×ESFP",
    "name": "互相成就的搭档",
    "base": 53,
    "fit": [
      "ENTJ的执行力与ESFP的表现力形成互补",
      "ENTJ擅长果断，ESFP擅长活泼，配合起来更全面",
      "ENTJ的效率能稳住ESFP的社交，互相平衡"
    ],
    "block": [
      "ENTJ的缺乏耐心可能让ESFP感到疏离或受挫",
      "ESFP的逃避责任有时会让ENTJ摸不着头脑"
    ],
    "summary": "ENTJ和ESFP有吸引力也有张力，一个像强势，一个像即兴，磨合好了是成长型关系。"
  },
  "ENTP_x_ENTP": {
    "a": "ENTP",
    "b": "ENTP",
    "key": "ENTP_x_ENTP",
    "display": "ENTP×ENTP",
    "name": "镜像双生",
    "base": 73,
    "fit": [
      "双方都擅长创造力，沟通成本极低",
      "对机变和发散有天然默契",
      "能理解对方对玩心的坚持"
    ],
    "block": [
      "两个人都容易不够专注，问题出现时容易一起卡住",
      "相同视角可能放大盲区，缺少互补"
    ],
    "summary": "两个辩论家相遇，是知己也是镜子。理解彼此很容易，但别让相似变成 stagnation，记得主动引入新鲜视角。"
  },
  "ENTP_x_INFJ": {
    "a": "ENTP",
    "b": "INFJ",
    "key": "ENTP_x_INFJ",
    "display": "ENTP×INFJ",
    "name": "智性恋天花板",
    "base": 81,
    "fit": [
      "ENTP的创造力与INFJ的理解力形成互补",
      "ENTP擅长创意，INFJ擅长洞察，配合起来更全面",
      "ENTP的挑战能稳住INFJ的深度，互相平衡"
    ],
    "block": [
      "ENTP的不够专注可能让INFJ感到疏离或受挫",
      "INFJ的过度内耗有时会让ENTP摸不着头脑"
    ],
    "summary": "ENTP与INFJ是少见的互补型组合，分析家与外交官的碰撞既能互相激发，又能互相兜底。"
  },
  "ENTP_x_INFP": {
    "a": "ENTP",
    "b": "INFP",
    "key": "ENTP_x_INFP",
    "display": "ENTP×INFP",
    "name": "理性与感性的平衡",
    "base": 69,
    "fit": [
      "ENTP的创造力与INFP的共情力形成互补",
      "ENTP擅长创意，INFP擅长诗意，配合起来更全面",
      "ENTP的挑战能稳住INFP的价值，互相平衡"
    ],
    "block": [
      "ENTP的不够专注可能让INFP感到疏离或受挫",
      "INFP的容易受伤有时会让ENTP摸不着头脑"
    ],
    "summary": "ENTP与INFP是少见的互补型组合，分析家与外交官的碰撞既能互相激发，又能互相兜底。"
  },
  "ENFJ_x_ENTP": {
    "a": "ENTP",
    "b": "ENFJ",
    "key": "ENFJ_x_ENTP",
    "display": "ENTP×ENFJ",
    "name": "互相成就的搭档",
    "base": 57,
    "fit": [
      "ENTP的创造力与ENFJ的凝聚力形成互补",
      "ENTP擅长创意，ENFJ擅长感染力，配合起来更全面",
      "ENTP的挑战能稳住ENFJ的温暖，互相平衡"
    ],
    "block": [
      "ENTP的不够专注可能让ENFJ感到疏离或受挫",
      "ENFJ的过度付出有时会让ENTP摸不着头脑"
    ],
    "summary": "ENTP和ENFJ有吸引力也有张力，一个像玩心，一个像热情，磨合好了是成长型关系。"
  },
  "ENFP_x_ENTP": {
    "a": "ENTP",
    "b": "ENFP",
    "key": "ENFP_x_ENTP",
    "display": "ENTP×ENFP",
    "name": "互相成就的搭档",
    "base": 62,
    "fit": [
      "ENTP的创造力与ENFP的感染力形成互补",
      "ENTP擅长创意，ENFP擅长热情，配合起来更全面",
      "ENTP的挑战能稳住ENFP的自由，互相平衡"
    ],
    "block": [
      "ENTP的不够专注可能让ENFP感到疏离或受挫",
      "ENFP的情绪起伏有时会让ENTP摸不着头脑"
    ],
    "summary": "ENTP和ENFP有吸引力也有张力，一个像玩心，一个像乐观，磨合好了是成长型关系。"
  },
  "ENTP_x_ISTJ": {
    "a": "ENTP",
    "b": "ISTJ",
    "key": "ENTP_x_ISTJ",
    "display": "ENTP×ISTJ",
    "name": "互相成就的搭档",
    "base": 57,
    "fit": [
      "ENTP的创造力与ISTJ的可靠性形成互补",
      "ENTP擅长创意，ISTJ擅长可靠，配合起来更全面",
      "ENTP的挑战能稳住ISTJ的规则，互相平衡"
    ],
    "block": [
      "ENTP的不够专注可能让ISTJ感到疏离或受挫",
      "ISTJ的缺乏变通有时会让ENTP摸不着头脑"
    ],
    "summary": "ENTP和ISTJ有吸引力也有张力，一个像玩心，一个像责任，磨合好了是成长型关系。"
  },
  "ENTP_x_ISFJ": {
    "a": "ENTP",
    "b": "ISFJ",
    "key": "ENTP_x_ISFJ",
    "display": "ENTP×ISFJ",
    "name": "需要磨合的潜力股",
    "base": 46,
    "fit": [
      "ENTP的创造力与ISFJ的体贴度形成互补",
      "ENTP擅长创意，ISFJ擅长温柔，配合起来更全面",
      "ENTP的挑战能稳住ISFJ的稳定，互相平衡"
    ],
    "block": [
      "ENTP的不够专注可能让ISFJ感到疏离或受挫",
      "ISFJ的不善拒绝有时会让ENTP摸不着头脑"
    ],
    "summary": "ENTP与ISFJ像是两种运行系统，一个讲挑战，一个讲稳定，要走到一起需要大量翻译和耐心。"
  },
  "ENTP_x_ESTJ": {
    "a": "ENTP",
    "b": "ESTJ",
    "key": "ENTP_x_ESTJ",
    "display": "ENTP×ESTJ",
    "name": "需要磨合的潜力股",
    "base": 48,
    "fit": [
      "ENTP的创造力与ESTJ的统筹力形成互补",
      "ENTP擅长创意，ESTJ擅长组织，配合起来更全面",
      "ENTP的挑战能稳住ESTJ的直接，互相平衡"
    ],
    "block": [
      "ENTP的不够专注可能让ESTJ感到疏离或受挫",
      "ESTJ的过于武断有时会让ENTP摸不着头脑"
    ],
    "summary": "ENTP和ESTJ有吸引力也有张力，一个像玩心，一个像结果，磨合好了是成长型关系。"
  },
  "ENTP_x_ESFJ": {
    "a": "ENTP",
    "b": "ESFJ",
    "key": "ENTP_x_ESFJ",
    "display": "ENTP×ESFJ",
    "name": "互相成就的搭档",
    "base": 53,
    "fit": [
      "ENTP的创造力与ESFJ的亲和力形成互补",
      "ENTP擅长创意，ESFJ擅长合群，配合起来更全面",
      "ENTP的挑战能稳住ESFJ的社交，互相平衡"
    ],
    "block": [
      "ENTP的不够专注可能让ESFJ感到疏离或受挫",
      "ESFJ的在意评价有时会让ENTP摸不着头脑"
    ],
    "summary": "ENTP和ESFJ有吸引力也有张力，一个像玩心，一个像热心，磨合好了是成长型关系。"
  },
  "ENTP_x_ISTP": {
    "a": "ENTP",
    "b": "ISTP",
    "key": "ENTP_x_ISTP",
    "display": "ENTP×ISTP",
    "name": "互相成就的搭档",
    "base": 62,
    "fit": [
      "ENTP的创造力与ISTP的应变力形成互补",
      "ENTP擅长创意，ISTP擅长冷静，配合起来更全面",
      "ENTP的挑战能稳住ISTP的独立，互相平衡"
    ],
    "block": [
      "ENTP的不够专注可能让ISTP感到疏离或受挫",
      "ISTP的情感冷淡有时会让ENTP摸不着头脑"
    ],
    "summary": "ENTP和ISTP有吸引力也有张力，一个像玩心，一个像随性，磨合好了是成长型关系。"
  },
  "ENTP_x_ISFP": {
    "a": "ENTP",
    "b": "ISFP",
    "key": "ENTP_x_ISFP",
    "display": "ENTP×ISFP",
    "name": "互相成就的搭档",
    "base": 66,
    "fit": [
      "ENTP的创造力与ISFP的审美力形成互补",
      "ENTP擅长创意，ISFP擅长艺术，配合起来更全面",
      "ENTP的挑战能稳住ISFP的温和，互相平衡"
    ],
    "block": [
      "ENTP的不够专注可能让ISFP感到疏离或受挫",
      "ISFP的回避冲突有时会让ENTP摸不着头脑"
    ],
    "summary": "ENTP和ISFP有吸引力也有张力，一个像玩心，一个像自由，磨合好了是成长型关系。"
  },
  "ENTP_x_ESTP": {
    "a": "ENTP",
    "b": "ESTP",
    "key": "ENTP_x_ESTP",
    "display": "ENTP×ESTP",
    "name": "需要磨合的潜力股",
    "base": 51,
    "fit": [
      "ENTP的创造力与ESTP的行动力形成互补",
      "ENTP擅长创意，ESTP擅长行动，配合起来更全面",
      "ENTP的挑战能稳住ESTP的现实，互相平衡"
    ],
    "block": [
      "ENTP的不够专注可能让ESTP感到疏离或受挫",
      "ESTP的冲动短视有时会让ENTP摸不着头脑"
    ],
    "summary": "ENTP和ESTP有吸引力也有张力，一个像玩心，一个像应变，磨合好了是成长型关系。"
  },
  "ENTP_x_ESFP": {
    "a": "ENTP",
    "b": "ESFP",
    "key": "ENTP_x_ESFP",
    "display": "ENTP×ESFP",
    "name": "互相成就的搭档",
    "base": 57,
    "fit": [
      "ENTP的创造力与ESFP的表现力形成互补",
      "ENTP擅长创意，ESFP擅长活泼，配合起来更全面",
      "ENTP的挑战能稳住ESFP的社交，互相平衡"
    ],
    "block": [
      "ENTP的不够专注可能让ESFP感到疏离或受挫",
      "ESFP的逃避责任有时会让ENTP摸不着头脑"
    ],
    "summary": "ENTP和ESFP有吸引力也有张力，一个像玩心，一个像即兴，磨合好了是成长型关系。"
  },
  "INFJ_x_INFJ": {
    "a": "INFJ",
    "b": "INFJ",
    "key": "INFJ_x_INFJ",
    "display": "INFJ×INFJ",
    "name": "镜像双生",
    "base": 73,
    "fit": [
      "双方都擅长理解力，沟通成本极低",
      "对理想和共情有天然默契",
      "能理解对方对神秘的坚持"
    ],
    "block": [
      "两个人都容易过度内耗，问题出现时容易一起卡住",
      "相同视角可能放大盲区，缺少互补"
    ],
    "summary": "两个提倡者相遇，是知己也是镜子。理解彼此很容易，但别让相似变成 stagnation，记得主动引入新鲜视角。"
  },
  "INFJ_x_INFP": {
    "a": "INFJ",
    "b": "INFP",
    "key": "INFJ_x_INFP",
    "display": "INFJ×INFP",
    "name": "互相成就的搭档",
    "base": 60,
    "fit": [
      "INFJ的理解力与INFP的共情力形成互补",
      "INFJ擅长洞察，INFP擅长诗意，配合起来更全面",
      "INFJ的深度能稳住INFP的价值，互相平衡"
    ],
    "block": [
      "INFJ的过度内耗可能让INFP感到疏离或受挫",
      "INFP的容易受伤有时会让INFJ摸不着头脑"
    ],
    "summary": "INFJ和INFP有吸引力也有张力，一个像神秘，一个像内省，磨合好了是成长型关系。"
  },
  "ENFJ_x_INFJ": {
    "a": "INFJ",
    "b": "ENFJ",
    "key": "ENFJ_x_INFJ",
    "display": "INFJ×ENFJ",
    "name": "理性与感性的平衡",
    "base": 73,
    "fit": [
      "INFJ的理解力与ENFJ的凝聚力形成互补",
      "INFJ擅长洞察，ENFJ擅长感染力，配合起来更全面",
      "INFJ的深度能稳住ENFJ的温暖，互相平衡"
    ],
    "block": [
      "INFJ的过度内耗可能让ENFJ感到疏离或受挫",
      "ENFJ的过度付出有时会让INFJ摸不着头脑"
    ],
    "summary": "INFJ与ENFJ是少见的互补型组合，外交官与外交官的碰撞既能互相激发，又能互相兜底。"
  },
  "ENFP_x_INFJ": {
    "a": "INFJ",
    "b": "ENFP",
    "key": "ENFP_x_INFJ",
    "display": "INFJ×ENFP",
    "name": "理性与感性的平衡",
    "base": 85,
    "fit": [
      "INFJ的理解力与ENFP的感染力形成互补",
      "INFJ擅长洞察，ENFP擅长热情，配合起来更全面",
      "INFJ的深度能稳住ENFP的自由，互相平衡"
    ],
    "block": [
      "INFJ的过度内耗可能让ENFP感到疏离或受挫",
      "ENFP的情绪起伏有时会让INFJ摸不着头脑"
    ],
    "summary": "INFJ与ENFP是少见的互补型组合，外交官与外交官的碰撞既能互相激发，又能互相兜底。"
  },
  "INFJ_x_ISTJ": {
    "a": "INFJ",
    "b": "ISTJ",
    "key": "INFJ_x_ISTJ",
    "display": "INFJ×ISTJ",
    "name": "互相成就的搭档",
    "base": 57,
    "fit": [
      "INFJ的理解力与ISTJ的可靠性形成互补",
      "INFJ擅长洞察，ISTJ擅长可靠，配合起来更全面",
      "INFJ的深度能稳住ISTJ的规则，互相平衡"
    ],
    "block": [
      "INFJ的过度内耗可能让ISTJ感到疏离或受挫",
      "ISTJ的缺乏变通有时会让INFJ摸不着头脑"
    ],
    "summary": "INFJ和ISTJ有吸引力也有张力，一个像神秘，一个像责任，磨合好了是成长型关系。"
  },
  "INFJ_x_ISFJ": {
    "a": "INFJ",
    "b": "ISFJ",
    "key": "INFJ_x_ISFJ",
    "display": "INFJ×ISFJ",
    "name": "需要磨合的潜力股",
    "base": 51,
    "fit": [
      "INFJ的理解力与ISFJ的体贴度形成互补",
      "INFJ擅长洞察，ISFJ擅长温柔，配合起来更全面",
      "INFJ的深度能稳住ISFJ的稳定，互相平衡"
    ],
    "block": [
      "INFJ的过度内耗可能让ISFJ感到疏离或受挫",
      "ISFJ的不善拒绝有时会让INFJ摸不着头脑"
    ],
    "summary": "INFJ和ISFJ有吸引力也有张力，一个像神秘，一个像奉献，磨合好了是成长型关系。"
  },
  "ESTJ_x_INFJ": {
    "a": "INFJ",
    "b": "ESTJ",
    "key": "ESTJ_x_INFJ",
    "display": "INFJ×ESTJ",
    "name": "互相成就的搭档",
    "base": 66,
    "fit": [
      "INFJ的理解力与ESTJ的统筹力形成互补",
      "INFJ擅长洞察，ESTJ擅长组织，配合起来更全面",
      "INFJ的深度能稳住ESTJ的直接，互相平衡"
    ],
    "block": [
      "INFJ的过度内耗可能让ESTJ感到疏离或受挫",
      "ESTJ的过于武断有时会让INFJ摸不着头脑"
    ],
    "summary": "INFJ和ESTJ有吸引力也有张力，一个像神秘，一个像结果，磨合好了是成长型关系。"
  },
  "ESFJ_x_INFJ": {
    "a": "INFJ",
    "b": "ESFJ",
    "key": "ESFJ_x_INFJ",
    "display": "INFJ×ESFJ",
    "name": "互相成就的搭档",
    "base": 62,
    "fit": [
      "INFJ的理解力与ESFJ的亲和力形成互补",
      "INFJ擅长洞察，ESFJ擅长合群，配合起来更全面",
      "INFJ的深度能稳住ESFJ的社交，互相平衡"
    ],
    "block": [
      "INFJ的过度内耗可能让ESFJ感到疏离或受挫",
      "ESFJ的在意评价有时会让INFJ摸不着头脑"
    ],
    "summary": "INFJ和ESFJ有吸引力也有张力，一个像神秘，一个像热心，磨合好了是成长型关系。"
  },
  "INFJ_x_ISTP": {
    "a": "INFJ",
    "b": "ISTP",
    "key": "INFJ_x_ISTP",
    "display": "INFJ×ISTP",
    "name": "互相成就的搭档",
    "base": 53,
    "fit": [
      "INFJ的理解力与ISTP的应变力形成互补",
      "INFJ擅长洞察，ISTP擅长冷静，配合起来更全面",
      "INFJ的深度能稳住ISTP的独立，互相平衡"
    ],
    "block": [
      "INFJ的过度内耗可能让ISTP感到疏离或受挫",
      "ISTP的情感冷淡有时会让INFJ摸不着头脑"
    ],
    "summary": "INFJ和ISTP有吸引力也有张力，一个像神秘，一个像随性，磨合好了是成长型关系。"
  },
  "INFJ_x_ISFP": {
    "a": "INFJ",
    "b": "ISFP",
    "key": "INFJ_x_ISFP",
    "display": "INFJ×ISFP",
    "name": "需要磨合的潜力股",
    "base": 48,
    "fit": [
      "INFJ的理解力与ISFP的审美力形成互补",
      "INFJ擅长洞察，ISFP擅长艺术，配合起来更全面",
      "INFJ的深度能稳住ISFP的温和，互相平衡"
    ],
    "block": [
      "INFJ的过度内耗可能让ISFP感到疏离或受挫",
      "ISFP的回避冲突有时会让INFJ摸不着头脑"
    ],
    "summary": "INFJ和ISFP有吸引力也有张力，一个像神秘，一个像自由，磨合好了是成长型关系。"
  },
  "ESTP_x_INFJ": {
    "a": "INFJ",
    "b": "ESTP",
    "key": "ESTP_x_INFJ",
    "display": "INFJ×ESTP",
    "name": "互相成就的搭档",
    "base": 64,
    "fit": [
      "INFJ的理解力与ESTP的行动力形成互补",
      "INFJ擅长洞察，ESTP擅长行动，配合起来更全面",
      "INFJ的深度能稳住ESTP的现实，互相平衡"
    ],
    "block": [
      "INFJ的过度内耗可能让ESTP感到疏离或受挫",
      "ESTP的冲动短视有时会让INFJ摸不着头脑"
    ],
    "summary": "INFJ和ESTP有吸引力也有张力，一个像神秘，一个像应变，磨合好了是成长型关系。"
  },
  "ESFP_x_INFJ": {
    "a": "INFJ",
    "b": "ESFP",
    "key": "ESFP_x_INFJ",
    "display": "INFJ×ESFP",
    "name": "互相成就的搭档",
    "base": 57,
    "fit": [
      "INFJ的理解力与ESFP的表现力形成互补",
      "INFJ擅长洞察，ESFP擅长活泼，配合起来更全面",
      "INFJ的深度能稳住ESFP的社交，互相平衡"
    ],
    "block": [
      "INFJ的过度内耗可能让ESFP感到疏离或受挫",
      "ESFP的逃避责任有时会让INFJ摸不着头脑"
    ],
    "summary": "INFJ和ESFP有吸引力也有张力，一个像神秘，一个像即兴，磨合好了是成长型关系。"
  },
  "INFP_x_INFP": {
    "a": "INFP",
    "b": "INFP",
    "key": "INFP_x_INFP",
    "display": "INFP×INFP",
    "name": "镜像双生",
    "base": 73,
    "fit": [
      "双方都擅长共情力，沟通成本极低",
      "对敏感和真诚有天然默契",
      "能理解对方对内省的坚持"
    ],
    "block": [
      "两个人都容易容易受伤，问题出现时容易一起卡住",
      "相同视角可能放大盲区，缺少互补"
    ],
    "summary": "两个调停者相遇，是知己也是镜子。理解彼此很容易，但别让相似变成 stagnation，记得主动引入新鲜视角。"
  },
  "ENFJ_x_INFP": {
    "a": "INFP",
    "b": "ENFJ",
    "key": "ENFJ_x_INFP",
    "display": "INFP×ENFJ",
    "name": "理性与感性的平衡",
    "base": 88,
    "fit": [
      "INFP的共情力与ENFJ的凝聚力形成互补",
      "INFP擅长诗意，ENFJ擅长感染力，配合起来更全面",
      "INFP的价值能稳住ENFJ的温暖，互相平衡"
    ],
    "block": [
      "INFP的容易受伤可能让ENFJ感到疏离或受挫",
      "ENFJ的过度付出有时会让INFP摸不着头脑"
    ],
    "summary": "INFP与ENFJ是少见的互补型组合，外交官与外交官的碰撞既能互相激发，又能互相兜底。"
  },
  "ENFP_x_INFP": {
    "a": "INFP",
    "b": "ENFP",
    "key": "ENFP_x_INFP",
    "display": "INFP×ENFP",
    "name": "理性与感性的平衡",
    "base": 73,
    "fit": [
      "INFP的共情力与ENFP的感染力形成互补",
      "INFP擅长诗意，ENFP擅长热情，配合起来更全面",
      "INFP的价值能稳住ENFP的自由，互相平衡"
    ],
    "block": [
      "INFP的容易受伤可能让ENFP感到疏离或受挫",
      "ENFP的情绪起伏有时会让INFP摸不着头脑"
    ],
    "summary": "INFP与ENFP是少见的互补型组合，外交官与外交官的碰撞既能互相激发，又能互相兜底。"
  },
  "INFP_x_ISTJ": {
    "a": "INFP",
    "b": "ISTJ",
    "key": "INFP_x_ISTJ",
    "display": "INFP×ISTJ",
    "name": "互相成就的搭档",
    "base": 53,
    "fit": [
      "INFP的共情力与ISTJ的可靠性形成互补",
      "INFP擅长诗意，ISTJ擅长可靠，配合起来更全面",
      "INFP的价值能稳住ISTJ的规则，互相平衡"
    ],
    "block": [
      "INFP的容易受伤可能让ISTJ感到疏离或受挫",
      "ISTJ的缺乏变通有时会让INFP摸不着头脑"
    ],
    "summary": "INFP和ISTJ有吸引力也有张力，一个像内省，一个像责任，磨合好了是成长型关系。"
  },
  "INFP_x_ISFJ": {
    "a": "INFP",
    "b": "ISFJ",
    "key": "INFP_x_ISFJ",
    "display": "INFP×ISFJ",
    "name": "需要磨合的潜力股",
    "base": 48,
    "fit": [
      "INFP的共情力与ISFJ的体贴度形成互补",
      "INFP擅长诗意，ISFJ擅长温柔，配合起来更全面",
      "INFP的价值能稳住ISFJ的稳定，互相平衡"
    ],
    "block": [
      "INFP的容易受伤可能让ISFJ感到疏离或受挫",
      "ISFJ的不善拒绝有时会让INFP摸不着头脑"
    ],
    "summary": "INFP和ISFJ有吸引力也有张力，一个像内省，一个像奉献，磨合好了是成长型关系。"
  },
  "ESTJ_x_INFP": {
    "a": "INFP",
    "b": "ESTJ",
    "key": "ESTJ_x_INFP",
    "display": "INFP×ESTJ",
    "name": "互相成就的搭档",
    "base": 64,
    "fit": [
      "INFP的共情力与ESTJ的统筹力形成互补",
      "INFP擅长诗意，ESTJ擅长组织，配合起来更全面",
      "INFP的价值能稳住ESTJ的直接，互相平衡"
    ],
    "block": [
      "INFP的容易受伤可能让ESTJ感到疏离或受挫",
      "ESTJ的过于武断有时会让INFP摸不着头脑"
    ],
    "summary": "INFP和ESTJ有吸引力也有张力，一个像内省，一个像结果，磨合好了是成长型关系。"
  },
  "ESFJ_x_INFP": {
    "a": "INFP",
    "b": "ESFJ",
    "key": "ESFJ_x_INFP",
    "display": "INFP×ESFJ",
    "name": "互相成就的搭档",
    "base": 57,
    "fit": [
      "INFP的共情力与ESFJ的亲和力形成互补",
      "INFP擅长诗意，ESFJ擅长合群，配合起来更全面",
      "INFP的价值能稳住ESFJ的社交，互相平衡"
    ],
    "block": [
      "INFP的容易受伤可能让ESFJ感到疏离或受挫",
      "ESFJ的在意评价有时会让INFP摸不着头脑"
    ],
    "summary": "INFP和ESFJ有吸引力也有张力，一个像内省，一个像热心，磨合好了是成长型关系。"
  },
  "INFP_x_ISTP": {
    "a": "INFP",
    "b": "ISTP",
    "key": "INFP_x_ISTP",
    "display": "INFP×ISTP",
    "name": "互相成就的搭档",
    "base": 57,
    "fit": [
      "INFP的共情力与ISTP的应变力形成互补",
      "INFP擅长诗意，ISTP擅长冷静，配合起来更全面",
      "INFP的价值能稳住ISTP的独立，互相平衡"
    ],
    "block": [
      "INFP的容易受伤可能让ISTP感到疏离或受挫",
      "ISTP的情感冷淡有时会让INFP摸不着头脑"
    ],
    "summary": "INFP和ISTP有吸引力也有张力，一个像内省，一个像随性，磨合好了是成长型关系。"
  },
  "INFP_x_ISFP": {
    "a": "INFP",
    "b": "ISFP",
    "key": "INFP_x_ISFP",
    "display": "INFP×ISFP",
    "name": "需要磨合的潜力股",
    "base": 51,
    "fit": [
      "INFP的共情力与ISFP的审美力形成互补",
      "INFP擅长诗意，ISFP擅长艺术，配合起来更全面",
      "INFP的价值能稳住ISFP的温和，互相平衡"
    ],
    "block": [
      "INFP的容易受伤可能让ISFP感到疏离或受挫",
      "ISFP的回避冲突有时会让INFP摸不着头脑"
    ],
    "summary": "INFP和ISFP有吸引力也有张力，一个像内省，一个像自由，磨合好了是成长型关系。"
  },
  "ESTP_x_INFP": {
    "a": "INFP",
    "b": "ESTP",
    "key": "ESTP_x_INFP",
    "display": "INFP×ESTP",
    "name": "互相成就的搭档",
    "base": 66,
    "fit": [
      "INFP的共情力与ESTP的行动力形成互补",
      "INFP擅长诗意，ESTP擅长行动，配合起来更全面",
      "INFP的价值能稳住ESTP的现实，互相平衡"
    ],
    "block": [
      "INFP的容易受伤可能让ESTP感到疏离或受挫",
      "ESTP的冲动短视有时会让INFP摸不着头脑"
    ],
    "summary": "INFP和ESTP有吸引力也有张力，一个像内省，一个像应变，磨合好了是成长型关系。"
  },
  "ESFP_x_INFP": {
    "a": "INFP",
    "b": "ESFP",
    "key": "ESFP_x_INFP",
    "display": "INFP×ESFP",
    "name": "互相成就的搭档",
    "base": 62,
    "fit": [
      "INFP的共情力与ESFP的表现力形成互补",
      "INFP擅长诗意，ESFP擅长活泼，配合起来更全面",
      "INFP的价值能稳住ESFP的社交，互相平衡"
    ],
    "block": [
      "INFP的容易受伤可能让ESFP感到疏离或受挫",
      "ESFP的逃避责任有时会让INFP摸不着头脑"
    ],
    "summary": "INFP和ESFP有吸引力也有张力，一个像内省，一个像即兴，磨合好了是成长型关系。"
  },
  "ENFJ_x_ENFJ": {
    "a": "ENFJ",
    "b": "ENFJ",
    "key": "ENFJ_x_ENFJ",
    "display": "ENFJ×ENFJ",
    "name": "镜像双生",
    "base": 73,
    "fit": [
      "双方都擅长凝聚力，沟通成本极低",
      "对凝聚和导师有天然默契",
      "能理解对方对热情的坚持"
    ],
    "block": [
      "两个人都容易过度付出，问题出现时容易一起卡住",
      "相同视角可能放大盲区，缺少互补"
    ],
    "summary": "两个主人公相遇，是知己也是镜子。理解彼此很容易，但别让相似变成 stagnation，记得主动引入新鲜视角。"
  },
  "ENFJ_x_ENFP": {
    "a": "ENFJ",
    "b": "ENFP",
    "key": "ENFJ_x_ENFP",
    "display": "ENFJ×ENFP",
    "name": "互相成就的搭档",
    "base": 60,
    "fit": [
      "ENFJ的凝聚力与ENFP的感染力形成互补",
      "ENFJ擅长感染力，ENFP擅长热情，配合起来更全面",
      "ENFJ的温暖能稳住ENFP的自由，互相平衡"
    ],
    "block": [
      "ENFJ的过度付出可能让ENFP感到疏离或受挫",
      "ENFP的情绪起伏有时会让ENFJ摸不着头脑"
    ],
    "summary": "ENFJ和ENFP有吸引力也有张力，一个像热情，一个像乐观，磨合好了是成长型关系。"
  },
  "ENFJ_x_ISTJ": {
    "a": "ENFJ",
    "b": "ISTJ",
    "key": "ENFJ_x_ISTJ",
    "display": "ENFJ×ISTJ",
    "name": "互相成就的搭档",
    "base": 66,
    "fit": [
      "ENFJ的凝聚力与ISTJ的可靠性形成互补",
      "ENFJ擅长感染力，ISTJ擅长可靠，配合起来更全面",
      "ENFJ的温暖能稳住ISTJ的规则，互相平衡"
    ],
    "block": [
      "ENFJ的过度付出可能让ISTJ感到疏离或受挫",
      "ISTJ的缺乏变通有时会让ENFJ摸不着头脑"
    ],
    "summary": "ENFJ和ISTJ有吸引力也有张力，一个像热情，一个像责任，磨合好了是成长型关系。"
  },
  "ENFJ_x_ISFJ": {
    "a": "ENFJ",
    "b": "ISFJ",
    "key": "ENFJ_x_ISFJ",
    "display": "ENFJ×ISFJ",
    "name": "互相成就的搭档",
    "base": 62,
    "fit": [
      "ENFJ的凝聚力与ISFJ的体贴度形成互补",
      "ENFJ擅长感染力，ISFJ擅长温柔，配合起来更全面",
      "ENFJ的温暖能稳住ISFJ的稳定，互相平衡"
    ],
    "block": [
      "ENFJ的过度付出可能让ISFJ感到疏离或受挫",
      "ISFJ的不善拒绝有时会让ENFJ摸不着头脑"
    ],
    "summary": "ENFJ和ISFJ有吸引力也有张力，一个像热情，一个像奉献，磨合好了是成长型关系。"
  },
  "ENFJ_x_ESTJ": {
    "a": "ENFJ",
    "b": "ESTJ",
    "key": "ENFJ_x_ESTJ",
    "display": "ENFJ×ESTJ",
    "name": "互相成就的搭档",
    "base": 57,
    "fit": [
      "ENFJ的凝聚力与ESTJ的统筹力形成互补",
      "ENFJ擅长感染力，ESTJ擅长组织，配合起来更全面",
      "ENFJ的温暖能稳住ESTJ的直接，互相平衡"
    ],
    "block": [
      "ENFJ的过度付出可能让ESTJ感到疏离或受挫",
      "ESTJ的过于武断有时会让ENFJ摸不着头脑"
    ],
    "summary": "ENFJ和ESTJ有吸引力也有张力，一个像热情，一个像结果，磨合好了是成长型关系。"
  },
  "ENFJ_x_ESFJ": {
    "a": "ENFJ",
    "b": "ESFJ",
    "key": "ENFJ_x_ESFJ",
    "display": "ENFJ×ESFJ",
    "name": "需要磨合的潜力股",
    "base": 51,
    "fit": [
      "ENFJ的凝聚力与ESFJ的亲和力形成互补",
      "ENFJ擅长感染力，ESFJ擅长合群，配合起来更全面",
      "ENFJ的温暖能稳住ESFJ的社交，互相平衡"
    ],
    "block": [
      "ENFJ的过度付出可能让ESFJ感到疏离或受挫",
      "ESFJ的在意评价有时会让ENFJ摸不着头脑"
    ],
    "summary": "ENFJ和ESFJ有吸引力也有张力，一个像热情，一个像热心，磨合好了是成长型关系。"
  },
  "ENFJ_x_ISTP": {
    "a": "ENFJ",
    "b": "ISTP",
    "key": "ENFJ_x_ISTP",
    "display": "ENFJ×ISTP",
    "name": "互相成就的搭档",
    "base": 64,
    "fit": [
      "ENFJ的凝聚力与ISTP的应变力形成互补",
      "ENFJ擅长感染力，ISTP擅长冷静，配合起来更全面",
      "ENFJ的温暖能稳住ISTP的独立，互相平衡"
    ],
    "block": [
      "ENFJ的过度付出可能让ISTP感到疏离或受挫",
      "ISTP的情感冷淡有时会让ENFJ摸不着头脑"
    ],
    "summary": "ENFJ和ISTP有吸引力也有张力，一个像热情，一个像随性，磨合好了是成长型关系。"
  },
  "ENFJ_x_ISFP": {
    "a": "ENFJ",
    "b": "ISFP",
    "key": "ENFJ_x_ISFP",
    "display": "ENFJ×ISFP",
    "name": "互相成就的搭档",
    "base": 57,
    "fit": [
      "ENFJ的凝聚力与ISFP的审美力形成互补",
      "ENFJ擅长感染力，ISFP擅长艺术，配合起来更全面",
      "ENFJ的温暖能稳住ISFP的温和，互相平衡"
    ],
    "block": [
      "ENFJ的过度付出可能让ISFP感到疏离或受挫",
      "ISFP的回避冲突有时会让ENFJ摸不着头脑"
    ],
    "summary": "ENFJ和ISFP有吸引力也有张力，一个像热情，一个像自由，磨合好了是成长型关系。"
  },
  "ENFJ_x_ESTP": {
    "a": "ENFJ",
    "b": "ESTP",
    "key": "ENFJ_x_ESTP",
    "display": "ENFJ×ESTP",
    "name": "互相成就的搭档",
    "base": 53,
    "fit": [
      "ENFJ的凝聚力与ESTP的行动力形成互补",
      "ENFJ擅长感染力，ESTP擅长行动，配合起来更全面",
      "ENFJ的温暖能稳住ESTP的现实，互相平衡"
    ],
    "block": [
      "ENFJ的过度付出可能让ESTP感到疏离或受挫",
      "ESTP的冲动短视有时会让ENFJ摸不着头脑"
    ],
    "summary": "ENFJ和ESTP有吸引力也有张力，一个像热情，一个像应变，磨合好了是成长型关系。"
  },
  "ENFJ_x_ESFP": {
    "a": "ENFJ",
    "b": "ESFP",
    "key": "ENFJ_x_ESFP",
    "display": "ENFJ×ESFP",
    "name": "需要磨合的潜力股",
    "base": 48,
    "fit": [
      "ENFJ的凝聚力与ESFP的表现力形成互补",
      "ENFJ擅长感染力，ESFP擅长活泼，配合起来更全面",
      "ENFJ的温暖能稳住ESFP的社交，互相平衡"
    ],
    "block": [
      "ENFJ的过度付出可能让ESFP感到疏离或受挫",
      "ESFP的逃避责任有时会让ENFJ摸不着头脑"
    ],
    "summary": "ENFJ和ESFP有吸引力也有张力，一个像热情，一个像即兴，磨合好了是成长型关系。"
  },
  "ENFP_x_ENFP": {
    "a": "ENFP",
    "b": "ENFP",
    "key": "ENFP_x_ENFP",
    "display": "ENFP×ENFP",
    "name": "镜像双生",
    "base": 73,
    "fit": [
      "双方都擅长感染力，沟通成本极低",
      "对灵感和联结有天然默契",
      "能理解对方对乐观的坚持"
    ],
    "block": [
      "两个人都容易情绪起伏，问题出现时容易一起卡住",
      "相同视角可能放大盲区，缺少互补"
    ],
    "summary": "两个竞选者相遇，是知己也是镜子。理解彼此很容易，但别让相似变成 stagnation，记得主动引入新鲜视角。"
  },
  "ENFP_x_ISTJ": {
    "a": "ENFP",
    "b": "ISTJ",
    "key": "ENFP_x_ISTJ",
    "display": "ENFP×ISTJ",
    "name": "互相成就的搭档",
    "base": 64,
    "fit": [
      "ENFP的感染力与ISTJ的可靠性形成互补",
      "ENFP擅长热情，ISTJ擅长可靠，配合起来更全面",
      "ENFP的自由能稳住ISTJ的规则，互相平衡"
    ],
    "block": [
      "ENFP的情绪起伏可能让ISTJ感到疏离或受挫",
      "ISTJ的缺乏变通有时会让ENFP摸不着头脑"
    ],
    "summary": "ENFP和ISTJ有吸引力也有张力，一个像乐观，一个像责任，磨合好了是成长型关系。"
  },
  "ENFP_x_ISFJ": {
    "a": "ENFP",
    "b": "ISFJ",
    "key": "ENFP_x_ISFJ",
    "display": "ENFP×ISFJ",
    "name": "互相成就的搭档",
    "base": 57,
    "fit": [
      "ENFP的感染力与ISFJ的体贴度形成互补",
      "ENFP擅长热情，ISFJ擅长温柔，配合起来更全面",
      "ENFP的自由能稳住ISFJ的稳定，互相平衡"
    ],
    "block": [
      "ENFP的情绪起伏可能让ISFJ感到疏离或受挫",
      "ISFJ的不善拒绝有时会让ENFP摸不着头脑"
    ],
    "summary": "ENFP和ISFJ有吸引力也有张力，一个像乐观，一个像奉献，磨合好了是成长型关系。"
  },
  "ENFP_x_ESTJ": {
    "a": "ENFP",
    "b": "ESTJ",
    "key": "ENFP_x_ESTJ",
    "display": "ENFP×ESTJ",
    "name": "互相成就的搭档",
    "base": 53,
    "fit": [
      "ENFP的感染力与ESTJ的统筹力形成互补",
      "ENFP擅长热情，ESTJ擅长组织，配合起来更全面",
      "ENFP的自由能稳住ESTJ的直接，互相平衡"
    ],
    "block": [
      "ENFP的情绪起伏可能让ESTJ感到疏离或受挫",
      "ESTJ的过于武断有时会让ENFP摸不着头脑"
    ],
    "summary": "ENFP和ESTJ有吸引力也有张力，一个像乐观，一个像结果，磨合好了是成长型关系。"
  },
  "ENFP_x_ESFJ": {
    "a": "ENFP",
    "b": "ESFJ",
    "key": "ENFP_x_ESFJ",
    "display": "ENFP×ESFJ",
    "name": "需要磨合的潜力股",
    "base": 48,
    "fit": [
      "ENFP的感染力与ESFJ的亲和力形成互补",
      "ENFP擅长热情，ESFJ擅长合群，配合起来更全面",
      "ENFP的自由能稳住ESFJ的社交，互相平衡"
    ],
    "block": [
      "ENFP的情绪起伏可能让ESFJ感到疏离或受挫",
      "ESFJ的在意评价有时会让ENFP摸不着头脑"
    ],
    "summary": "ENFP和ESFJ有吸引力也有张力，一个像乐观，一个像热心，磨合好了是成长型关系。"
  },
  "ENFP_x_ISTP": {
    "a": "ENFP",
    "b": "ISTP",
    "key": "ENFP_x_ISTP",
    "display": "ENFP×ISTP",
    "name": "互相成就的搭档",
    "base": 74,
    "fit": [
      "ENFP的感染力与ISTP的应变力形成互补",
      "ENFP擅长热情，ISTP擅长冷静，配合起来更全面",
      "ENFP的自由能稳住ISTP的独立，互相平衡"
    ],
    "block": [
      "ENFP的情绪起伏可能让ISTP感到疏离或受挫",
      "ISTP的情感冷淡有时会让ENFP摸不着头脑"
    ],
    "summary": "ENFP和ISTP有吸引力也有张力，一个像乐观，一个像随性，磨合好了是成长型关系。"
  },
  "ENFP_x_ISFP": {
    "a": "ENFP",
    "b": "ISFP",
    "key": "ENFP_x_ISFP",
    "display": "ENFP×ISFP",
    "name": "互相成就的搭档",
    "base": 62,
    "fit": [
      "ENFP的感染力与ISFP的审美力形成互补",
      "ENFP擅长热情，ISFP擅长艺术，配合起来更全面",
      "ENFP的自由能稳住ISFP的温和，互相平衡"
    ],
    "block": [
      "ENFP的情绪起伏可能让ISFP感到疏离或受挫",
      "ISFP的回避冲突有时会让ENFP摸不着头脑"
    ],
    "summary": "ENFP和ISFP有吸引力也有张力，一个像乐观，一个像自由，磨合好了是成长型关系。"
  },
  "ENFP_x_ESTP": {
    "a": "ENFP",
    "b": "ESTP",
    "key": "ENFP_x_ESTP",
    "display": "ENFP×ESTP",
    "name": "互相成就的搭档",
    "base": 57,
    "fit": [
      "ENFP的感染力与ESTP的行动力形成互补",
      "ENFP擅长热情，ESTP擅长行动，配合起来更全面",
      "ENFP的自由能稳住ESTP的现实，互相平衡"
    ],
    "block": [
      "ENFP的情绪起伏可能让ESTP感到疏离或受挫",
      "ESTP的冲动短视有时会让ENFP摸不着头脑"
    ],
    "summary": "ENFP和ESTP有吸引力也有张力，一个像乐观，一个像应变，磨合好了是成长型关系。"
  },
  "ENFP_x_ESFP": {
    "a": "ENFP",
    "b": "ESFP",
    "key": "ENFP_x_ESFP",
    "display": "ENFP×ESFP",
    "name": "需要磨合的潜力股",
    "base": 51,
    "fit": [
      "ENFP的感染力与ESFP的表现力形成互补",
      "ENFP擅长热情，ESFP擅长活泼，配合起来更全面",
      "ENFP的自由能稳住ESFP的社交，互相平衡"
    ],
    "block": [
      "ENFP的情绪起伏可能让ESFP感到疏离或受挫",
      "ESFP的逃避责任有时会让ENFP摸不着头脑"
    ],
    "summary": "ENFP和ESFP有吸引力也有张力，一个像乐观，一个像即兴，磨合好了是成长型关系。"
  },
  "ISTJ_x_ISTJ": {
    "a": "ISTJ",
    "b": "ISTJ",
    "key": "ISTJ_x_ISTJ",
    "display": "ISTJ×ISTJ",
    "name": "镜像双生",
    "base": 73,
    "fit": [
      "双方都擅长可靠性，沟通成本极低",
      "对务实和细节有天然默契",
      "能理解对方对责任的坚持"
    ],
    "block": [
      "两个人都容易缺乏变通，问题出现时容易一起卡住",
      "相同视角可能放大盲区，缺少互补"
    ],
    "summary": "两个检查者相遇，是知己也是镜子。理解彼此很容易，但别让相似变成 stagnation，记得主动引入新鲜视角。"
  },
  "ISFJ_x_ISTJ": {
    "a": "ISTJ",
    "b": "ISFJ",
    "key": "ISFJ_x_ISTJ",
    "display": "ISTJ×ISFJ",
    "name": "理性与感性的平衡",
    "base": 68,
    "fit": [
      "ISTJ的可靠性与ISFJ的体贴度形成互补",
      "ISTJ擅长可靠，ISFJ擅长温柔，配合起来更全面",
      "ISTJ的规则能稳住ISFJ的稳定，互相平衡"
    ],
    "block": [
      "ISTJ的缺乏变通可能让ISFJ感到疏离或受挫",
      "ISFJ的不善拒绝有时会让ISTJ摸不着头脑"
    ],
    "summary": "ISTJ与ISFJ是少见的互补型组合，探险家与探险家的碰撞既能互相激发，又能互相兜底。"
  },
  "ESTJ_x_ISTJ": {
    "a": "ISTJ",
    "b": "ESTJ",
    "key": "ESTJ_x_ISTJ",
    "display": "ISTJ×ESTJ",
    "name": "理性与感性的平衡",
    "base": 73,
    "fit": [
      "ISTJ的可靠性与ESTJ的统筹力形成互补",
      "ISTJ擅长可靠，ESTJ擅长组织，配合起来更全面",
      "ISTJ的规则能稳住ESTJ的直接，互相平衡"
    ],
    "block": [
      "ISTJ的缺乏变通可能让ESTJ感到疏离或受挫",
      "ESTJ的过于武断有时会让ISTJ摸不着头脑"
    ],
    "summary": "ISTJ与ESTJ是少见的互补型组合，探险家与探险家的碰撞既能互相激发，又能互相兜底。"
  },
  "ESFJ_x_ISTJ": {
    "a": "ISTJ",
    "b": "ESFJ",
    "key": "ESFJ_x_ISTJ",
    "display": "ISTJ×ESFJ",
    "name": "理性与感性的平衡",
    "base": 77,
    "fit": [
      "ISTJ的可靠性与ESFJ的亲和力形成互补",
      "ISTJ擅长可靠，ESFJ擅长合群，配合起来更全面",
      "ISTJ的规则能稳住ESFJ的社交，互相平衡"
    ],
    "block": [
      "ISTJ的缺乏变通可能让ESFJ感到疏离或受挫",
      "ESFJ的在意评价有时会让ISTJ摸不着头脑"
    ],
    "summary": "ISTJ与ESFJ是少见的互补型组合，探险家与探险家的碰撞既能互相激发，又能互相兜底。"
  },
  "ISTJ_x_ISTP": {
    "a": "ISTJ",
    "b": "ISTP",
    "key": "ISTJ_x_ISTP",
    "display": "ISTJ×ISTP",
    "name": "互相成就的搭档",
    "base": 60,
    "fit": [
      "ISTJ的可靠性与ISTP的应变力形成互补",
      "ISTJ擅长可靠，ISTP擅长冷静，配合起来更全面",
      "ISTJ的规则能稳住ISTP的独立，互相平衡"
    ],
    "block": [
      "ISTJ的缺乏变通可能让ISTP感到疏离或受挫",
      "ISTP的情感冷淡有时会让ISTJ摸不着头脑"
    ],
    "summary": "ISTJ和ISTP有吸引力也有张力，一个像责任，一个像随性，磨合好了是成长型关系。"
  },
  "ISFP_x_ISTJ": {
    "a": "ISTJ",
    "b": "ISFP",
    "key": "ISFP_x_ISTJ",
    "display": "ISTJ×ISFP",
    "name": "互相成就的搭档",
    "base": 65,
    "fit": [
      "ISTJ的可靠性与ISFP的审美力形成互补",
      "ISTJ擅长可靠，ISFP擅长艺术，配合起来更全面",
      "ISTJ的规则能稳住ISFP的温和，互相平衡"
    ],
    "block": [
      "ISTJ的缺乏变通可能让ISFP感到疏离或受挫",
      "ISFP的回避冲突有时会让ISTJ摸不着头脑"
    ],
    "summary": "ISTJ和ISFP有吸引力也有张力，一个像责任，一个像自由，磨合好了是成长型关系。"
  },
  "ESTP_x_ISTJ": {
    "a": "ISTJ",
    "b": "ESTP",
    "key": "ESTP_x_ISTJ",
    "display": "ISTJ×ESTP",
    "name": "理性与感性的平衡",
    "base": 68,
    "fit": [
      "ISTJ的可靠性与ESTP的行动力形成互补",
      "ISTJ擅长可靠，ESTP擅长行动，配合起来更全面",
      "ISTJ的规则能稳住ESTP的现实，互相平衡"
    ],
    "block": [
      "ISTJ的缺乏变通可能让ESTP感到疏离或受挫",
      "ESTP的冲动短视有时会让ISTJ摸不着头脑"
    ],
    "summary": "ISTJ与ESTP是少见的互补型组合，探险家与探险家的碰撞既能互相激发，又能互相兜底。"
  },
  "ESFP_x_ISTJ": {
    "a": "ISTJ",
    "b": "ESFP",
    "key": "ESFP_x_ISTJ",
    "display": "ISTJ×ESFP",
    "name": "互补型绝配",
    "base": 70,
    "fit": [
      "ISTJ的可靠性与ESFP的表现力形成互补",
      "ISTJ擅长可靠，ESFP擅长活泼，配合起来更全面",
      "ISTJ的规则能稳住ESFP的社交，互相平衡"
    ],
    "block": [
      "ISTJ的缺乏变通可能让ESFP感到疏离或受挫",
      "ESFP的逃避责任有时会让ISTJ摸不着头脑"
    ],
    "summary": "ISTJ与ESFP是少见的互补型组合，探险家与探险家的碰撞既能互相激发，又能互相兜底。"
  },
  "ISFJ_x_ISFJ": {
    "a": "ISFJ",
    "b": "ISFJ",
    "key": "ISFJ_x_ISFJ",
    "display": "ISFJ×ISFJ",
    "name": "镜像双生",
    "base": 73,
    "fit": [
      "双方都擅长体贴度，沟通成本极低",
      "对体贴和传统有天然默契",
      "能理解对方对奉献的坚持"
    ],
    "block": [
      "两个人都容易不善拒绝，问题出现时容易一起卡住",
      "相同视角可能放大盲区，缺少互补"
    ],
    "summary": "两个守护者相遇，是知己也是镜子。理解彼此很容易，但别让相似变成 stagnation，记得主动引入新鲜视角。"
  },
  "ESTJ_x_ISFJ": {
    "a": "ISFJ",
    "b": "ESTJ",
    "key": "ESTJ_x_ISFJ",
    "display": "ISFJ×ESTJ",
    "name": "理性与感性的平衡",
    "base": 77,
    "fit": [
      "ISFJ的体贴度与ESTJ的统筹力形成互补",
      "ISFJ擅长温柔，ESTJ擅长组织，配合起来更全面",
      "ISFJ的稳定能稳住ESTJ的直接，互相平衡"
    ],
    "block": [
      "ISFJ的不善拒绝可能让ESTJ感到疏离或受挫",
      "ESTJ的过于武断有时会让ISFJ摸不着头脑"
    ],
    "summary": "ISFJ与ESTJ是少见的互补型组合，探险家与探险家的碰撞既能互相激发，又能互相兜底。"
  },
  "ESFJ_x_ISFJ": {
    "a": "ISFJ",
    "b": "ESFJ",
    "key": "ESFJ_x_ISFJ",
    "display": "ISFJ×ESFJ",
    "name": "理性与感性的平衡",
    "base": 73,
    "fit": [
      "ISFJ的体贴度与ESFJ的亲和力形成互补",
      "ISFJ擅长温柔，ESFJ擅长合群，配合起来更全面",
      "ISFJ的稳定能稳住ESFJ的社交，互相平衡"
    ],
    "block": [
      "ISFJ的不善拒绝可能让ESFJ感到疏离或受挫",
      "ESFJ的在意评价有时会让ISFJ摸不着头脑"
    ],
    "summary": "ISFJ与ESFJ是少见的互补型组合，探险家与探险家的碰撞既能互相激发，又能互相兜底。"
  },
  "ISFJ_x_ISTP": {
    "a": "ISFJ",
    "b": "ISTP",
    "key": "ISFJ_x_ISTP",
    "display": "ISFJ×ISTP",
    "name": "互相成就的搭档",
    "base": 65,
    "fit": [
      "ISFJ的体贴度与ISTP的应变力形成互补",
      "ISFJ擅长温柔，ISTP擅长冷静，配合起来更全面",
      "ISFJ的稳定能稳住ISTP的独立，互相平衡"
    ],
    "block": [
      "ISFJ的不善拒绝可能让ISTP感到疏离或受挫",
      "ISTP的情感冷淡有时会让ISFJ摸不着头脑"
    ],
    "summary": "ISFJ和ISTP有吸引力也有张力，一个像奉献，一个像随性，磨合好了是成长型关系。"
  },
  "ISFJ_x_ISFP": {
    "a": "ISFJ",
    "b": "ISFP",
    "key": "ISFJ_x_ISFP",
    "display": "ISFJ×ISFP",
    "name": "互相成就的搭档",
    "base": 60,
    "fit": [
      "ISFJ的体贴度与ISFP的审美力形成互补",
      "ISFJ擅长温柔，ISFP擅长艺术，配合起来更全面",
      "ISFJ的稳定能稳住ISFP的温和，互相平衡"
    ],
    "block": [
      "ISFJ的不善拒绝可能让ISFP感到疏离或受挫",
      "ISFP的回避冲突有时会让ISFJ摸不着头脑"
    ],
    "summary": "ISFJ和ISFP有吸引力也有张力，一个像奉献，一个像自由，磨合好了是成长型关系。"
  },
  "ESTP_x_ISFJ": {
    "a": "ISFJ",
    "b": "ESTP",
    "key": "ESTP_x_ISFJ",
    "display": "ISFJ×ESTP",
    "name": "互补型绝配",
    "base": 72,
    "fit": [
      "ISFJ的体贴度与ESTP的行动力形成互补",
      "ISFJ擅长温柔，ESTP擅长行动，配合起来更全面",
      "ISFJ的稳定能稳住ESTP的现实，互相平衡"
    ],
    "block": [
      "ISFJ的不善拒绝可能让ESTP感到疏离或受挫",
      "ESTP的冲动短视有时会让ISFJ摸不着头脑"
    ],
    "summary": "ISFJ与ESTP是少见的互补型组合，探险家与探险家的碰撞既能互相激发，又能互相兜底。"
  },
  "ESFP_x_ISFJ": {
    "a": "ISFJ",
    "b": "ESFP",
    "key": "ESFP_x_ISFJ",
    "display": "ISFJ×ESFP",
    "name": "理性与感性的平衡",
    "base": 68,
    "fit": [
      "ISFJ的体贴度与ESFP的表现力形成互补",
      "ISFJ擅长温柔，ESFP擅长活泼，配合起来更全面",
      "ISFJ的稳定能稳住ESFP的社交，互相平衡"
    ],
    "block": [
      "ISFJ的不善拒绝可能让ESFP感到疏离或受挫",
      "ESFP的逃避责任有时会让ISFJ摸不着头脑"
    ],
    "summary": "ISFJ与ESFP是少见的互补型组合，探险家与探险家的碰撞既能互相激发，又能互相兜底。"
  },
  "ESTJ_x_ESTJ": {
    "a": "ESTJ",
    "b": "ESTJ",
    "key": "ESTJ_x_ESTJ",
    "display": "ESTJ×ESTJ",
    "name": "镜像双生",
    "base": 73,
    "fit": [
      "双方都擅长统筹力，沟通成本极低",
      "对执行力和秩序有天然默契",
      "能理解对方对结果的坚持"
    ],
    "block": [
      "两个人都容易过于武断，问题出现时容易一起卡住",
      "相同视角可能放大盲区，缺少互补"
    ],
    "summary": "两个总经理相遇，是知己也是镜子。理解彼此很容易，但别让相似变成 stagnation，记得主动引入新鲜视角。"
  },
  "ESFJ_x_ESTJ": {
    "a": "ESTJ",
    "b": "ESFJ",
    "key": "ESFJ_x_ESTJ",
    "display": "ESTJ×ESFJ",
    "name": "理性与感性的平衡",
    "base": 68,
    "fit": [
      "ESTJ的统筹力与ESFJ的亲和力形成互补",
      "ESTJ擅长组织，ESFJ擅长合群，配合起来更全面",
      "ESTJ的直接能稳住ESFJ的社交，互相平衡"
    ],
    "block": [
      "ESTJ的过于武断可能让ESFJ感到疏离或受挫",
      "ESFJ的在意评价有时会让ESTJ摸不着头脑"
    ],
    "summary": "ESTJ与ESFJ是少见的互补型组合，探险家与探险家的碰撞既能互相激发，又能互相兜底。"
  },
  "ESTJ_x_ISTP": {
    "a": "ESTJ",
    "b": "ISTP",
    "key": "ESTJ_x_ISTP",
    "display": "ESTJ×ISTP",
    "name": "理性与感性的平衡",
    "base": 68,
    "fit": [
      "ESTJ的统筹力与ISTP的应变力形成互补",
      "ESTJ擅长组织，ISTP擅长冷静，配合起来更全面",
      "ESTJ的直接能稳住ISTP的独立，互相平衡"
    ],
    "block": [
      "ESTJ的过于武断可能让ISTP感到疏离或受挫",
      "ISTP的情感冷淡有时会让ESTJ摸不着头脑"
    ],
    "summary": "ESTJ与ISTP是少见的互补型组合，探险家与探险家的碰撞既能互相激发，又能互相兜底。"
  },
  "ESTJ_x_ISFP": {
    "a": "ESTJ",
    "b": "ISFP",
    "key": "ESTJ_x_ISFP",
    "display": "ESTJ×ISFP",
    "name": "互补型绝配",
    "base": 68,
    "fit": [
      "ESTJ的统筹力与ISFP的审美力形成互补",
      "ESTJ擅长组织，ISFP擅长艺术，配合起来更全面",
      "ESTJ的直接能稳住ISFP的温和，互相平衡"
    ],
    "block": [
      "ESTJ的过于武断可能让ISFP感到疏离或受挫",
      "ISFP的回避冲突有时会让ESTJ摸不着头脑"
    ],
    "summary": "ESTJ与ISFP是少见的互补型组合，探险家与探险家的碰撞既能互相激发，又能互相兜底。"
  },
  "ESTJ_x_ESTP": {
    "a": "ESTJ",
    "b": "ESTP",
    "key": "ESTJ_x_ESTP",
    "display": "ESTJ×ESTP",
    "name": "互相成就的搭档",
    "base": 60,
    "fit": [
      "ESTJ的统筹力与ESTP的行动力形成互补",
      "ESTJ擅长组织，ESTP擅长行动，配合起来更全面",
      "ESTJ的直接能稳住ESTP的现实，互相平衡"
    ],
    "block": [
      "ESTJ的过于武断可能让ESTP感到疏离或受挫",
      "ESTP的冲动短视有时会让ESTJ摸不着头脑"
    ],
    "summary": "ESTJ和ESTP有吸引力也有张力，一个像结果，一个像应变，磨合好了是成长型关系。"
  },
  "ESFP_x_ESTJ": {
    "a": "ESTJ",
    "b": "ESFP",
    "key": "ESFP_x_ESTJ",
    "display": "ESTJ×ESFP",
    "name": "互相成就的搭档",
    "base": 65,
    "fit": [
      "ESTJ的统筹力与ESFP的表现力形成互补",
      "ESTJ擅长组织，ESFP擅长活泼，配合起来更全面",
      "ESTJ的直接能稳住ESFP的社交，互相平衡"
    ],
    "block": [
      "ESTJ的过于武断可能让ESFP感到疏离或受挫",
      "ESFP的逃避责任有时会让ESTJ摸不着头脑"
    ],
    "summary": "ESTJ和ESFP有吸引力也有张力，一个像结果，一个像即兴，磨合好了是成长型关系。"
  },
  "ESFJ_x_ESFJ": {
    "a": "ESFJ",
    "b": "ESFJ",
    "key": "ESFJ_x_ESFJ",
    "display": "ESFJ×ESFJ",
    "name": "镜像双生",
    "base": 73,
    "fit": [
      "双方都擅长亲和力，沟通成本极低",
      "对关怀和和谐有天然默契",
      "能理解对方对热心的坚持"
    ],
    "block": [
      "两个人都容易在意评价，问题出现时容易一起卡住",
      "相同视角可能放大盲区，缺少互补"
    ],
    "summary": "两个执政官相遇，是知己也是镜子。理解彼此很容易，但别让相似变成 stagnation，记得主动引入新鲜视角。"
  },
  "ESFJ_x_ISTP": {
    "a": "ESFJ",
    "b": "ISTP",
    "key": "ESFJ_x_ISTP",
    "display": "ESFJ×ISTP",
    "name": "互补型绝配",
    "base": 78,
    "fit": [
      "ESFJ的亲和力与ISTP的应变力形成互补",
      "ESFJ擅长合群，ISTP擅长冷静，配合起来更全面",
      "ESFJ的社交能稳住ISTP的独立，互相平衡"
    ],
    "block": [
      "ESFJ的在意评价可能让ISTP感到疏离或受挫",
      "ISTP的情感冷淡有时会让ESFJ摸不着头脑"
    ],
    "summary": "ESFJ与ISTP是少见的互补型组合，探险家与探险家的碰撞既能互相激发，又能互相兜底。"
  },
  "ESFJ_x_ISFP": {
    "a": "ESFJ",
    "b": "ISFP",
    "key": "ESFJ_x_ISFP",
    "display": "ESFJ×ISFP",
    "name": "理性与感性的平衡",
    "base": 68,
    "fit": [
      "ESFJ的亲和力与ISFP的审美力形成互补",
      "ESFJ擅长合群，ISFP擅长艺术，配合起来更全面",
      "ESFJ的社交能稳住ISFP的温和，互相平衡"
    ],
    "block": [
      "ESFJ的在意评价可能让ISFP感到疏离或受挫",
      "ISFP的回避冲突有时会让ESFJ摸不着头脑"
    ],
    "summary": "ESFJ与ISFP是少见的互补型组合，探险家与探险家的碰撞既能互相激发，又能互相兜底。"
  },
  "ESFJ_x_ESTP": {
    "a": "ESFJ",
    "b": "ESTP",
    "key": "ESFJ_x_ESTP",
    "display": "ESFJ×ESTP",
    "name": "互相成就的搭档",
    "base": 65,
    "fit": [
      "ESFJ的亲和力与ESTP的行动力形成互补",
      "ESFJ擅长合群，ESTP擅长行动，配合起来更全面",
      "ESFJ的社交能稳住ESTP的现实，互相平衡"
    ],
    "block": [
      "ESFJ的在意评价可能让ESTP感到疏离或受挫",
      "ESTP的冲动短视有时会让ESFJ摸不着头脑"
    ],
    "summary": "ESFJ和ESTP有吸引力也有张力，一个像热心，一个像应变，磨合好了是成长型关系。"
  },
  "ESFJ_x_ESFP": {
    "a": "ESFJ",
    "b": "ESFP",
    "key": "ESFJ_x_ESFP",
    "display": "ESFJ×ESFP",
    "name": "互相成就的搭档",
    "base": 60,
    "fit": [
      "ESFJ的亲和力与ESFP的表现力形成互补",
      "ESFJ擅长合群，ESFP擅长活泼，配合起来更全面",
      "ESFJ的社交能稳住ESFP的社交，互相平衡"
    ],
    "block": [
      "ESFJ的在意评价可能让ESFP感到疏离或受挫",
      "ESFP的逃避责任有时会让ESFJ摸不着头脑"
    ],
    "summary": "ESFJ和ESFP有吸引力也有张力，一个像热心，一个像即兴，磨合好了是成长型关系。"
  },
  "ISTP_x_ISTP": {
    "a": "ISTP",
    "b": "ISTP",
    "key": "ISTP_x_ISTP",
    "display": "ISTP×ISTP",
    "name": "镜像双生",
    "base": 73,
    "fit": [
      "双方都擅长应变力，沟通成本极低",
      "对动手和务实有天然默契",
      "能理解对方对随性的坚持"
    ],
    "block": [
      "两个人都容易情感冷淡，问题出现时容易一起卡住",
      "相同视角可能放大盲区，缺少互补"
    ],
    "summary": "两个鉴赏家相遇，是知己也是镜子。理解彼此很容易，但别让相似变成 stagnation，记得主动引入新鲜视角。"
  },
  "ISFP_x_ISTP": {
    "a": "ISTP",
    "b": "ISFP",
    "key": "ISFP_x_ISTP",
    "display": "ISTP×ISFP",
    "name": "理性与感性的平衡",
    "base": 68,
    "fit": [
      "ISTP的应变力与ISFP的审美力形成互补",
      "ISTP擅长冷静，ISFP擅长艺术，配合起来更全面",
      "ISTP的独立能稳住ISFP的温和，互相平衡"
    ],
    "block": [
      "ISTP的情感冷淡可能让ISFP感到疏离或受挫",
      "ISFP的回避冲突有时会让ISTP摸不着头脑"
    ],
    "summary": "ISTP与ISFP是少见的互补型组合，探险家与探险家的碰撞既能互相激发，又能互相兜底。"
  },
  "ESTP_x_ISTP": {
    "a": "ISTP",
    "b": "ESTP",
    "key": "ESTP_x_ISTP",
    "display": "ISTP×ESTP",
    "name": "理性与感性的平衡",
    "base": 73,
    "fit": [
      "ISTP的应变力与ESTP的行动力形成互补",
      "ISTP擅长冷静，ESTP擅长行动，配合起来更全面",
      "ISTP的独立能稳住ESTP的现实，互相平衡"
    ],
    "block": [
      "ISTP的情感冷淡可能让ESTP感到疏离或受挫",
      "ESTP的冲动短视有时会让ISTP摸不着头脑"
    ],
    "summary": "ISTP与ESTP是少见的互补型组合，探险家与探险家的碰撞既能互相激发，又能互相兜底。"
  },
  "ESFP_x_ISTP": {
    "a": "ISTP",
    "b": "ESFP",
    "key": "ESFP_x_ISTP",
    "display": "ISTP×ESFP",
    "name": "理性与感性的平衡",
    "base": 77,
    "fit": [
      "ISTP的应变力与ESFP的表现力形成互补",
      "ISTP擅长冷静，ESFP擅长活泼，配合起来更全面",
      "ISTP的独立能稳住ESFP的社交，互相平衡"
    ],
    "block": [
      "ISTP的情感冷淡可能让ESFP感到疏离或受挫",
      "ESFP的逃避责任有时会让ISTP摸不着头脑"
    ],
    "summary": "ISTP与ESFP是少见的互补型组合，探险家与探险家的碰撞既能互相激发，又能互相兜底。"
  },
  "ISFP_x_ISFP": {
    "a": "ISFP",
    "b": "ISFP",
    "key": "ISFP_x_ISFP",
    "display": "ISFP×ISFP",
    "name": "镜像双生",
    "base": 73,
    "fit": [
      "双方都擅长审美力，沟通成本极低",
      "对当下和审美有天然默契",
      "能理解对方对自由的坚持"
    ],
    "block": [
      "两个人都容易回避冲突，问题出现时容易一起卡住",
      "相同视角可能放大盲区，缺少互补"
    ],
    "summary": "两个探险家相遇，是知己也是镜子。理解彼此很容易，但别让相似变成 stagnation，记得主动引入新鲜视角。"
  },
  "ESTP_x_ISFP": {
    "a": "ISFP",
    "b": "ESTP",
    "key": "ESTP_x_ISFP",
    "display": "ISFP×ESTP",
    "name": "理性与感性的平衡",
    "base": 77,
    "fit": [
      "ISFP的审美力与ESTP的行动力形成互补",
      "ISFP擅长艺术，ESTP擅长行动，配合起来更全面",
      "ISFP的温和能稳住ESTP的现实，互相平衡"
    ],
    "block": [
      "ISFP的回避冲突可能让ESTP感到疏离或受挫",
      "ESTP的冲动短视有时会让ISFP摸不着头脑"
    ],
    "summary": "ISFP与ESTP是少见的互补型组合，探险家与探险家的碰撞既能互相激发，又能互相兜底。"
  },
  "ESFP_x_ISFP": {
    "a": "ISFP",
    "b": "ESFP",
    "key": "ESFP_x_ISFP",
    "display": "ISFP×ESFP",
    "name": "理性与感性的平衡",
    "base": 73,
    "fit": [
      "ISFP的审美力与ESFP的表现力形成互补",
      "ISFP擅长艺术，ESFP擅长活泼，配合起来更全面",
      "ISFP的温和能稳住ESFP的社交，互相平衡"
    ],
    "block": [
      "ISFP的回避冲突可能让ESFP感到疏离或受挫",
      "ESFP的逃避责任有时会让ISFP摸不着头脑"
    ],
    "summary": "ISFP与ESFP是少见的互补型组合，探险家与探险家的碰撞既能互相激发，又能互相兜底。"
  },
  "ESTP_x_ESTP": {
    "a": "ESTP",
    "b": "ESTP",
    "key": "ESTP_x_ESTP",
    "display": "ESTP×ESTP",
    "name": "镜像双生",
    "base": 73,
    "fit": [
      "双方都擅长行动力，沟通成本极低",
      "对冒险和魅力有天然默契",
      "能理解对方对应变的坚持"
    ],
    "block": [
      "两个人都容易冲动短视，问题出现时容易一起卡住",
      "相同视角可能放大盲区，缺少互补"
    ],
    "summary": "两个企业家相遇，是知己也是镜子。理解彼此很容易，但别让相似变成 stagnation，记得主动引入新鲜视角。"
  },
  "ESFP_x_ESTP": {
    "a": "ESTP",
    "b": "ESFP",
    "key": "ESFP_x_ESTP",
    "display": "ESTP×ESFP",
    "name": "理性与感性的平衡",
    "base": 68,
    "fit": [
      "ESTP的行动力与ESFP的表现力形成互补",
      "ESTP擅长行动，ESFP擅长活泼，配合起来更全面",
      "ESTP的现实能稳住ESFP的社交，互相平衡"
    ],
    "block": [
      "ESTP的冲动短视可能让ESFP感到疏离或受挫",
      "ESFP的逃避责任有时会让ESTP摸不着头脑"
    ],
    "summary": "ESTP与ESFP是少见的互补型组合，探险家与探险家的碰撞既能互相激发，又能互相兜底。"
  },
  "ESFP_x_ESFP": {
    "a": "ESFP",
    "b": "ESFP",
    "key": "ESFP_x_ESFP",
    "display": "ESFP×ESFP",
    "name": "镜像双生",
    "base": 73,
    "fit": [
      "双方都擅长表现力，沟通成本极低",
      "对享乐和热情有天然默契",
      "能理解对方对即兴的坚持"
    ],
    "block": [
      "两个人都容易逃避责任，问题出现时容易一起卡住",
      "相同视角可能放大盲区，缺少互补"
    ],
    "summary": "两个表演者相遇，是知己也是镜子。理解彼此很容易，但别让相似变成 stagnation，记得主动引入新鲜视角。"
  }
};
