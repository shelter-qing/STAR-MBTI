# Result Ring Offset Fix

## Symptom

After scrolling a report, choosing "redial", and querying again, the yellow
ring could appear above its percentage label. Scrolling the new report
corrected its position while the label stayed in place.

## Findings

- A similar cross-page canvas/scroll offset was reported in
  [echarts-for-weixin #931](https://github.com/ecomfe/echarts-for-weixin/issues/931).
  It is a matching symptom, not proof that both apps share the same internal bug.
- The [native component reference](https://developers.weixin.qq.com/miniprogram/dev/component/native-component.html)
  explains that canvas is rendered natively. Layout queries cannot confirm that
  the native compositing surface is positioned correctly after scroll restore.
- Waiting for the page route and remounting the canvas improved its reveal timing,
  but the reported offset remained.

## Resolution

The visible ring no longer uses canvas. `result-ring` now draws the track and
progress with ordinary WXML views and WXSS. A conic gradient supplies the gold
colors, a radial mask cuts out the center, and two positioned circular caps keep
both arc ends rounded. The percentage and arc share the same component box and
page scroll coordinate.

The component keeps its `score` property, score count-up, scene score updates,
and delayed page mount. Detaching the component stops its timer and invalidates
any pending animation ticks.

## Verification

Run `node tests/result-components.test.js`. The test covers the absence of a
canvas element, the CSS ring contract, score interpolation, angle/color updates,
score clamping, scene changes, route lifecycle order, and animation cancellation.

Device acceptance: scroll a result to its bottom, choose "redial", change MBTI,
and query again at least three times without scrolling the new report. The ring
must stay centered on its percentage. Also check direct result entry, all three
scene tabs, 0% and 100% scores, and a smaller-screen device. Confirm the gold
gradient and rounded end caps match the original canvas ring.
