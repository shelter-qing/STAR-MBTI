const { MBTI_TYPES, ZODIACS, formatPick } = require('../../utils/helper');
const { calculateCompatibility } = require('../../utils/score');
const { cardModel, createPoster, removePoster } = require('../../utils/share-poster');

const SCENE_LABEL = { love: '恋爱相性', friend: '友情默契', work: '职场搭档' };
const ZODIAC_ICON_FILES = [
  '白羊座.svg', '金牛座.svg', '双子座.svg', '巨蟹座.svg',
  '狮子座.svg', '处女座.svg', '天秤座.svg', '天蝎座.svg',
  '射手座.svg', '摩羯座.svg', '水瓶座.svg', '双鱼座.svg'
];
const ZODIAC_ICON_ROOT = '../../assets/refer/svg/';

Page({
  data: {
    pickA: '', pickB: '', pickAText: '', pickBText: '',
    zodiacIconA: '', zodiacIconB: '',
    scene: 'love', sceneLabel: SCENE_LABEL.love,
    scoreText: '0%', ringScore: 0, ringMounted: false,
    levelName: '', keyword: '', summary: '', advice: '',
    fitItems: [], grindItems: [], adviceLines: [], tags: ['', ''],
    mA: 0, zA: 0, mB: 0, zB: 0,
    shareVisible: false, shareLoading: false, shareSaving: false,
    shareError: '', sharePosterPath: ''
  },

  onLoad(query) {
    const index = (value, length) => {
      const number = Number(value);
      return Number.isInteger(number) && number >= 0 && number < length ? number : 0;
    };
    const mA = index(query.mA, MBTI_TYPES.length);
    const zA = index(query.zA, ZODIACS.length);
    const mB = index(query.mB, MBTI_TYPES.length);
    const zB = index(query.zB, ZODIACS.length);
    const scene = Object.prototype.hasOwnProperty.call(SCENE_LABEL, query.scene) ? query.scene : 'love';
    this._renderScene(mA, zA, mB, zB, scene);
  },

  onReady() {
    this._pageReady = true;
    this._mountRingWhenReady();
  },

  onRouteDone() {
    this._routeDone = true;
    this._mountRingWhenReady();
  },

  _mountRingWhenReady() {
    if (!this._pageReady || !this._routeDone || this._unloaded || this._leaving) return;
    wx.nextTick(() => {
      if (!this._unloaded && !this._leaving && !this.data.ringMounted) {
        this.setData({ ringMounted: true });
      }
    });
  },

  onUnload() {
    this._unloaded = true;
    removePoster(this._poster);
    this._poster = null;
  },

  onSwitchScene(e) {
    const scene = (e.detail && e.detail.scene) || (e.currentTarget && e.currentTarget.dataset.scene);
    if (!Object.prototype.hasOwnProperty.call(SCENE_LABEL, scene) || scene === this.data.scene) return;
    const { mA, zA, mB, zB } = this.data;
    this._renderScene(mA, zA, mB, zB, scene);
    if (this._playSound) this._playSound('tick');
  },

  _renderScene(mA, zA, mB, zB, scene) {
    const result = calculateCompatibility(mA, zA, mB, zB, scene);
    removePoster(this._poster);
    this._poster = null;
    this.setData({
      pickA: formatPick(mA, zA), pickB: formatPick(mB, zB),
      pickAText: `${MBTI_TYPES[mA].toLowerCase()} - ${ZODIACS[zA].name}`,
      pickBText: `${MBTI_TYPES[mB].toLowerCase()} - ${ZODIACS[zB].name}`,
      zodiacIconA: ZODIAC_ICON_ROOT + ZODIAC_ICON_FILES[zA],
      zodiacIconB: ZODIAC_ICON_ROOT + ZODIAC_ICON_FILES[zB],
      mA, zA, mB, zB, scene, sceneLabel: SCENE_LABEL[scene],
      scoreText: `${result.score}%`, ringScore: result.score,
      levelName: result.level || '', keyword: result.nickname || '',
      summary: result.summary || '', advice: result.advice || '',
      adviceLines: String(result.adviceText || result.advice || '').split(/\n+/).filter(Boolean),
      fitItems: result.fitItems || [], grindItems: result.grindItems || [],
      tags: [result.tags && result.tags[0] || '', result.tags && result.tags[1] || ''],
      sharePosterPath: '', shareError: ''
    });
  },

  onRedial() {
    if (this._leaving) return;
    this._leaving = true;
    if (this._playSound) this._playSound('confirm');
    this.setData({ ringMounted: false }, () => {
      wx.nextTick(() => {
        if (this._unloaded) return;
        wx.navigateBack({ delta: 1, fail: () => wx.reLaunch({ url: '/pages/index/index' }) });
      });
    });
  },

  async onShare() {
    if (this._unloaded) return;
    if (this._playSound) this._playSound('tick');
    this.setData({ shareVisible: true });
    try {
      await this._ensureSharePoster();
    } catch (error) {
      // The modal retains a retry control when image generation fails.
    }
  },

  onCloseShare() {
    if (!this.data.shareSaving) {
      if (this._playSound) this._playSound('tick');
      this.setData({ shareVisible: false });
    }
  },

  onShareImageError() {
    removePoster(this._poster);
    this._poster = null;
    this.setData({ sharePosterPath: '', shareError: '卡片加载失败，请重试' });
  },

  stopShareTouch() {},

  _ensureSharePoster() {
    const model = cardModel(this.data);
    if (this._poster && this._poster.key === model.key) return Promise.resolve(this._poster);
    if (this._posterRequest && this._posterRequest.key === model.key) return this._posterRequest.promise;
    this.setData({ shareLoading: true, shareError: '' });
    const request = { key: model.key };
    request.promise = createPoster(model).then(poster => {
      if (this._unloaded || cardModel(this.data).key !== model.key) {
        removePoster(poster);
        throw new Error('poster request is no longer current');
      }
      this._poster = poster;
      this.setData({ sharePosterPath: poster.posterPath });
      return poster;
    }).catch(error => {
      if (!this._unloaded && this._posterRequest === request) {
        console.error('[share-poster] generation failed', {
          stage: error && error.stage || 'unknown',
          source: error && error.source || '',
          message: error && (error.errMsg || error.message) || String(error)
        });
        this.setData({ shareError: '卡片生成失败，请重试' });
      }
      throw error;
    }).finally(() => {
      if (this._posterRequest === request) {
        this._posterRequest = null;
        if (!this._unloaded) this.setData({ shareLoading: false });
      }
    });
    this._posterRequest = request;
    return request.promise;
  },

  async onSaveCard() {
    if (this.data.shareSaving || this._unloaded) return;
    this.setData({ shareSaving: true });
    try {
      const poster = await this._ensureSharePoster();
      if (this._unloaded) return;
      await new Promise((resolve, reject) => {
        wx.saveImageToPhotosAlbum({ filePath: poster.posterPath, success: resolve, fail: reject });
      });
      if (!this._unloaded) wx.showToast({ title: '已保存到相册', icon: 'success' });
      if (this._playSound) this._playSound('confirm');
    } catch (error) {
      if (this._unloaded) return;
      const message = String(error && error.errMsg || '');
      if (/auth deny|auth denied|authorize|permission/i.test(message)) {
        wx.showModal({
          title: '需要相册权限', content: '请允许保存图片到相册', confirmText: '去设置',
          success: result => { if (result.confirm) wx.openSetting({}); }
        });
      } else if (!/cancel/i.test(message)) {
        wx.showToast({ title: '保存失败，请重试', icon: 'none' });
      }
    } finally {
      if (!this._unloaded) this.setData({ shareSaving: false });
    }
  },

  onShareAppMessage() {
    const { pickA, pickB, sceneLabel, scoreText, levelName, mA, zA, mB, zB, scene } = this.data;
    const payload = {
      title: `${pickA} × ${pickB} · ${sceneLabel} ${scoreText}（${levelName}）`,
      path: `/pages/result/result?mA=${mA}&zA=${zA}&mB=${mB}&zB=${zB}&scene=${scene}`
    };
    if (this._poster && this._poster.key === cardModel(this.data).key) {
      payload.imageUrl = this._poster.thumbnailPath;
    }
    return payload;
  },

  _getApp() {
    return typeof getApp === 'function' ? getApp() : null;
  },

  _playSound(name) {
    const app = this._getApp();
    if (app && typeof app.playSound === 'function') app.playSound(name);
  }
});
