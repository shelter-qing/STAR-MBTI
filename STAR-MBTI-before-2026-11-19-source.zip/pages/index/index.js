// pages/index/index.js — 首页（Lanhu 静态版 + 选择交互）
const { MBTI_TYPES, ZODIACS, formatPick } = require('../../utils/helper');
const GUIDE_CONFIG = require('../../utils/guide-config');

const GUIDE_STORAGE_KEY = 'mbti-star:guide-seen-v3';

// MBTI 气泡按 ring3 刻度间隔排列；从当前压线位置整体回退半个槽位，落在两条刻度之间
// 顺序与 utils/helper.js 的 MBTI_TYPES 一致：01=INTJ ... 16=ESFP
const MBTI_SLOT_DEG = 360 / 16;
const BUBBLE_OFFSET_DEG = -MBTI_SLOT_DEG / 2; // -11.25°，相对当前压线位置整体回退
const BUB_R = 244; // 气泡中心距轮盘圆心 rpx，较上一版向外回退 2rpx
const ZODIAC_SLOT_DEG = 360 / 12;
const STAR_BUBBLE_OFFSET_DEG = -ZODIAC_SLOT_DEG / 2; // -15°，相对 ring2 切割线整体回退
const STAR_BUB_R = 136; // 星座气泡中心距轮盘圆心 rpx，较上一版向内收 6rpx
const BUBBLE_FILES = {
  purple: Array.from({ length: 16 }, (_, i) =>
    `../../assets/refer/bubble/mbti-bubbles-big/purple-mbti-bubbles${String(i + 1).padStart(2, '0')}.png`),
  blue: Array.from({ length: 16 }, (_, i) =>
    `../../assets/refer/bubble/mbti-bubbles-big/blue-mbti-bubbles${String(i + 1).padStart(2, '0')}.png`)
};
// 预计算当前压线基准角；统一回退偏移在 WXML 中叠加，旋转由 rot{which}_mbti 叠加
const BUBBLE_A = MBTI_TYPES.map((_, i) => ({ a: (i + 0.5) * MBTI_SLOT_DEG, file: BUBBLE_FILES.purple[i] }));
const BUBBLE_B = MBTI_TYPES.map((_, i) => ({ a: (i + 0.5) * MBTI_SLOT_DEG, file: BUBBLE_FILES.blue[i] }));
// 素材编号按设计稿顺序排列，映射到 helper.js 的标准星座顺序
// 白羊、金牛、双子、巨蟹、狮子、处女、天秤、天蝎、射手、摩羯、水瓶、双鱼
const STAR_BUBBLE_FILE_INDEX = [6, 11, 7, 10, 9, 12, 2, 8, 3, 1, 4, 5];
const STAR_BUBBLE_FILES = {
  purple: Array.from({ length: 12 }, (_, i) =>
    `../../assets/refer/bubble/star-bubbles/purple-star-bubbles${String(STAR_BUBBLE_FILE_INDEX[i]).padStart(2, '0')}.png`),
  blue: Array.from({ length: 12 }, (_, i) =>
    `../../assets/refer/bubble/star-bubbles/blue-star-bubbles${String(STAR_BUBBLE_FILE_INDEX[i]).padStart(2, '0')}.png`)
};
const STAR_BUBBLE_A = ZODIACS.map((_, i) => ({
  a: (i + 0.5) * ZODIAC_SLOT_DEG,
  file: STAR_BUBBLE_FILES.purple[i]
}));
const STAR_BUBBLE_B = ZODIACS.map((_, i) => ({
  a: (i + 0.5) * ZODIAC_SLOT_DEG,
  file: STAR_BUBBLE_FILES.blue[i]
}));

Page({
  data: {
    pickA: 'INTJ · 狮子座 ♌',
    pickB: 'INTP · 天秤座 ♎',
    // 三层独立旋转：每盘 MBTI 层 + 星座层各自旋转（ring1 装饰层静止）
    // 初始 rot 经过反推：让吸附解析恰好命中 A=INTJ·狮子 / B=INTP·天秤
    // （rotA_mbti=90 → bubble_0=0；rotA_zodiac=330 → star_bubble_4=0；
    //   rotB_mbti=247.5 → bubble_1=180；rotB_zodiac=90 → star_bubble_6=180）
    rotA_mbti: 90, rotA_zodiac: 330,
    rotB_mbti: 247.5, rotB_zodiac: 90,
    rotTransA_mbti: 'none', rotTransA_zodiac: 'none',
    rotTransB_mbti: 'none', rotTransB_zodiac: 'none',
    // 16 MBTI 气泡数据（item.a 为静态角，item.file 为图片路径）
    bubblesA: BUBBLE_A,
    bubblesB: BUBBLE_B,
    BUB_R, // 暴露给 wxml 表达式
    BUBBLE_OFFSET_DEG,
    starBubblesA: STAR_BUBBLE_A,
    starBubblesB: STAR_BUBBLE_B,
    STAR_BUB_R,
    STAR_BUBBLE_OFFSET_DEG,
    submitting: false,
    wheelActiveA: false,
    wheelActiveB: false,
    guideVisible: false,
    guideStep: 0,
    guideScale: 1,
    guideTop: 0
  },

  onLoad(query = {}) {
    this.stateA = { mbtiIdx: 0, zodiacIdx: 4 };
    this.stateB = { mbtiIdx: 1, zodiacIdx: 6 };
    this.setData({
      pickA: formatPick(this.stateA.mbtiIdx, this.stateA.zodiacIdx),
      pickB: formatPick(this.stateB.mbtiIdx, this.stateB.zodiacIdx)
    });
    this._fitGuideToScreen();
    this._handleGuideEntry(query.guide === '1');
  },

  // 直接点击 MBTI 气泡或星座图标选择
  onPick(e) {
    if (this.data.submitting) return;
    const { which, type, idx } = e.currentTarget.dataset;
    const target = which === 'A' ? this.stateA : this.stateB;
    if (type === 'mbti') target.mbtiIdx = Number(idx);
    else target.zodiacIdx = Number(idx);
    this.setData({
      pickA: formatPick(this.stateA.mbtiIdx, this.stateA.zodiacIdx),
      pickB: formatPick(this.stateB.mbtiIdx, this.stateB.zodiacIdx)
    });
    this._playSound('tick');
  },

  // ===== 手动拨动轮盘：外圈拨 MBTI(16扇区) / 内圈拨星座(12扇区)，带磁吸+惯性+松手吸附 =====
  onWheelTouchStart(e) {
    if (this.data.submitting || this.data.guideVisible) return;
    const which = e.currentTarget.dataset.which;
    const t = e.touches[0];
    const tx = t.clientX, ty = t.clientY; // 提前取坐标，避免异步回调时事件对象失效
    const id = which === 'A' ? 'wheelA' : 'wheelB';
    wx.createSelectorQuery().in(this).select('#' + id).boundingClientRect(rect => {
      if (!rect) return;
      const cx = rect.left + rect.width / 2;
      const cy = rect.top + rect.height / 2;
      const R = rect.width / 2;
      const dx = tx - cx;
      const dy = ty - cy;
      const d = Math.sqrt(dx * dx + dy * dy);
      // 分区：外圈 d>0.64R 拨 MBTI / 内圈 d≤0.64R 拨星座 / 中心装饰圈忽略
      let layer = null;
      if (d > R * 0.64) layer = 'mbti';
      else if (d > R * 0.237) layer = 'zodiac';
      if (!layer) return;
      const angle = Math.atan2(dy, dx) * 180 / Math.PI;
      const snapDeg = layer === 'mbti' ? 360 / 16 : 360 / 12;
      const startRot = this.data['rot' + which + '_' + layer];
      this.touch = {
        which, layer, cx, cy,
        startAngle: angle,
        startRot,
        lastRot: startRot,
        lastTime: Date.now(),
        lastSnapIdx: Math.round(startRot / snapDeg),
        lastTickAt: 0,
        velocity: 0,
        snapDeg
      };
      this._lastMoveTs = 0;
      // 跟手：先关过渡
      this.setData({
        ['rotTrans' + which + '_' + layer]: 'none',
        ['wheelActive' + which]: true
      });
    }).exec();
  },

  onWheelTouchMove(e) {
    if (!this.touch) return;
    const now = Date.now();
    if (now - (this._lastMoveTs || 0) < 16) return; // 节流 ~60fps
    this._lastMoveTs = now;
    const tc = this.touch;
    const t = e.touches[0];
    const angle = Math.atan2(t.clientY - tc.cy, t.clientX - tc.cx) * 180 / Math.PI;
    let rot = tc.startRot + (angle - tc.startAngle);
    // 磁吸：距最近吸附角 < 扇区1/3 时拉近一半差量 → 旋钮顿挫感
    const step = tc.snapDeg;
    const nearest = Math.round(rot / step) * step;
    const diff = rot - nearest;
    if (Math.abs(diff) < step / 3) {
      rot -= diff * 0.5;
    }
    // 跨扇区轻震动（已按用户要求移除雷霆交互）
    const snapIdx = Math.round(rot / step);
    if (snapIdx !== tc.lastSnapIdx && now - tc.lastTickAt >= 85) {
      this._playSound('tick');
      tc.lastTickAt = now;
    }
    tc.lastSnapIdx = snapIdx;
    // 速度估算（度/秒），供松手惯性用
    const dt = (now - tc.lastTime) / 1000;
    if (dt > 0) {
      tc.velocity = (rot - tc.lastRot) / dt;
      tc.lastRot = rot;
      tc.lastTime = now;
    }
    this.setData({ ['rot' + tc.which + '_' + tc.layer]: rot });
  },

  onWheelTouchEnd() {
    this._finishWheelTouch(true);
  },

  onWheelTouchCancel() {
    this._finishWheelTouch(false);
  },

  // 松手：惯性滑行 + 吸附到最近扇区 + 同步选中
  _finishWheelTouch(withInertia) {
    const tc = this.touch;
    if (!tc) return;
    this.touch = null;
    const step = tc.snapDeg;
    let final = this.data['rot' + tc.which + '_' + tc.layer];
    if (withInertia) {
      // 惯性：按最后速度滑行 0.25s，限幅 ±180° 防止猛甩跳变
      let glide = tc.velocity * 0.25;
      if (glide > 180) glide = 180;
      if (glide < -180) glide = -180;
      final += glide;
    }
    const target = Math.round(final / step) * step;
    const transKey = 'rotTrans' + tc.which + '_' + tc.layer;
    const rotKey = 'rot' + tc.which + '_' + tc.layer;
    this.setData({
      [transKey]: 'transform 0.35s cubic-bezier(0.2, 0.65, 0.3, 1)',
      [rotKey]: target
    });
    setTimeout(() => {
      this.setData({ [transKey]: 'none', ['wheelActive' + tc.which]: false });
      this._syncPick(tc.which);
      this._playSound('tick');
    }, 400);
  },

  // 拨动结束后同步 state + 顶部文案
  _syncPick(which) {
    const A = which === 'A';
    const state = A ? this.stateA : this.stateB;
    state.mbtiIdx = this._resolvePickMbti(this.data['rot' + which + '_mbti'], which);
    state.zodiacIdx = this._resolvePickZodiac(this.data['rot' + which + '_zodiac'], which);
    this.setData({
      pickA: formatPick(this.stateA.mbtiIdx, this.stateA.zodiacIdx),
      pickB: formatPick(this.stateB.mbtiIdx, this.stateB.zodiacIdx)
    });
    // 注：此处不再震动——手动拖拽松手吸附后不应有画面震动反馈（用户要求）
  },

  // 随机生成：4 层独立动画（每盘 MBTI + 星座），两段式——先随机乱飘，减速停稳后自动吸附到最近扇区
  onRandom() {
    if (this.data.submitting || this.data.guideVisible) return;
    // MBTI 层 4-6 圈（视觉略快），星座层 3-5 圈（视觉略慢）
    const mbtiTurns = 4 + Math.floor(Math.random() * 3);
    const zodiacTurns = 3 + Math.floor(Math.random() * 3);
    const mbtiSpin = mbtiTurns * 360 + Math.random() * 360;
    const zodiacSpin = zodiacTurns * 360 + Math.random() * 360;
    // 方向：A 盘 MBTI 顺时针 + 星座逆时针；B 盘镜像（视觉差异更明显）
    const trans = 'transform 2.8s cubic-bezier(0.18, 0.7, 0.2, 1)';
    this._startSpinTicks();
    this.setData({
      wheelActiveA: true,
      wheelActiveB: true,
      rotTransA_mbti: trans, rotTransA_zodiac: trans,
      rotTransB_mbti: trans, rotTransB_zodiac: trans,
      rotA_mbti: this.data.rotA_mbti + mbtiSpin,
      rotA_zodiac: this.data.rotA_zodiac - zodiacSpin,
      rotB_mbti: this.data.rotB_mbti - mbtiSpin,
      rotB_zodiac: this.data.rotB_zodiac + zodiacSpin
    });
    // 第一段动画结束（转速已近 0）：每层自动吸附到最近扇区角（16 槽 22.5° / 12 槽 30°）
    // 与手动拨动松手吸附同一套公式 Math.round(rot/step)*step + 0.35s 过渡
    setTimeout(() => {
      const steps = { mbti: 360 / 16, zodiac: 360 / 12 };
      const snapTrans = 'transform 0.35s cubic-bezier(0.2, 0.65, 0.3, 1)';
      const patch = {};
      for (const w of ['A', 'B']) {
        for (const layer of ['mbti', 'zodiac']) {
          const rotKey = 'rot' + w + '_' + layer;
          const transKey = 'rotTrans' + w + '_' + layer;
          patch[transKey] = snapTrans;
          patch[rotKey] = Math.round(this.data[rotKey] / steps[layer]) * steps[layer];
        }
      }
      this.setData(patch);
      // 吸附动画结束：根据落点计算选中并复位过渡
      setTimeout(() => {
        this.stateA = {
          mbtiIdx: this._resolvePickMbti(this.data.rotA_mbti, 'A'),
          zodiacIdx: this._resolvePickZodiac(this.data.rotA_zodiac, 'A')
        };
        this.stateB = {
          mbtiIdx: this._resolvePickMbti(this.data.rotB_mbti, 'B'),
          zodiacIdx: this._resolvePickZodiac(this.data.rotB_zodiac, 'B')
        };
        this.setData({
          pickA: formatPick(this.stateA.mbtiIdx, this.stateA.zodiacIdx),
          pickB: formatPick(this.stateB.mbtiIdx, this.stateB.zodiacIdx),
          rotTransA_mbti: 'none', rotTransA_zodiac: 'none',
          rotTransB_mbti: 'none', rotTransB_zodiac: 'none'
        });
        if (wx.vibrateShort) wx.vibrateShort({ type: 'medium' });
        this.setData({ wheelActiveA: false, wheelActiveB: false });
        this._playSound('confirm');
      }, 400);
    }, 2800);
  },

  // 从 MBTI 层旋转角度反推指针指向（16 槽）—— 哪个轮盘决定箭头方向（A=东 0°，B=西 180°）
  _resolvePickMbti(rot, which) {
    return this._resolvePickGeneric(rot, MBTI_TYPES.length, which);
  },

  // 从星座层旋转角度反推指针指向（12 槽）
  _resolvePickZodiac(rot, which) {
    return this._resolvePickGeneric(rot, ZODIACS.length, which);
  },

  // 通用槽位解析：找世界 atan2 坐标系下最接近箭头方向的槽
  // 气泡最终角度 = (i+0.5)*slotDeg - 0.5*slotDeg + rot，即 i*slotDeg + rot
  //   ring3 刻度线处于半槽相反相位，因此吸附后气泡中心落在刻度之间
  // 指针方向：左盘箭头在东(atan2=0)，右盘箭头在西(atan2=180)
  // MBTI/星座气泡在吸附后都与指针中心重合
  _resolvePickGeneric(rot, n, which) {
    const slotDeg = 360 / n;
    const norm = ((rot % 360) + 360) % 360;
    const pointer = which === 'B' ? 180 : 0; // B 盘箭头在西侧
    const offset = n === MBTI_TYPES.length ? BUBBLE_OFFSET_DEG : STAR_BUBBLE_OFFSET_DEG;
    const phase = slotDeg / 2 + offset;
    let best = 0, bestDiff = 999;
    for (let i = 0; i < n; i++) {
      const center = (i * slotDeg + phase + norm - 90 + 720) % 360;
      const diff = Math.min(Math.abs(center - pointer), 360 - Math.abs(center - pointer));
      if (diff < bestDiff) { bestDiff = diff; best = i; }
    }
    return best;
  },

  onSubmit() {
    if (this.data.submitting || this.data.guideVisible) return;
    this.setData({ submitting: true });
    this._playSound('confirm');
    setTimeout(() => {
      const { stateA, stateB } = this;
      wx.navigateTo({
        url: `/pages/result/result?mA=${stateA.mbtiIdx}&zA=${stateA.zodiacIdx}&mB=${stateB.mbtiIdx}&zB=${stateB.zodiacIdx}`,
        fail: () => this.setData({ submitting: false })
      });
    }, 600);
  },

  onShow() {
    if (this.data.submitting) this.setData({ submitting: false });
    this._handleGuideEntry();
  },

  onAppEntry() {
    this._handleGuideEntry();
  },

  onUnload() {
    if (this._spinTickTimer) clearTimeout(this._spinTickTimer);
  },

  onResize() {
    this._fitGuideToScreen();
  },

  _fitGuideToScreen() {
    if (typeof wx.getWindowInfo !== 'function') return;
    const { windowWidth, windowHeight } = wx.getWindowInfo();
    if (!(windowWidth > 0 && windowHeight > 0)) return;
    const heightRpx = windowHeight * 750 / windowWidth;
    const guideScale = Math.min(1, heightRpx / 1584);
    this.setData({ guideScale, guideTop: Math.max(0, (heightRpx - 1584 * guideScale) / 2) });
  },

  _handleGuideEntry(force = false) {
    const app = this._getApp();
    const entryId = app && app.globalData ? app.globalData.guideEntryId || 0 : 0;
    const firstPageEntry = this._guideEntryId === undefined;
    if (force || (GUIDE_CONFIG.repeatOnEntry && this._guideEntryId !== entryId)) {
      this._guideGesture = null;
      this._guideEntryId = entryId;
      this.setData({ guideVisible: true, guideStep: 0 });
      return;
    }
    this._guideEntryId = entryId;
    if (firstPageEntry) this._showFirstVisitGuide();
  },

  _showFirstVisitGuide() {
    if (typeof wx === 'undefined' || typeof wx.getStorageSync !== 'function') return;
    let seen = false;
    try {
      seen = wx.getStorageSync(GUIDE_STORAGE_KEY) === true;
    } catch (error) {
      // Storage failure should not prevent the first-use explanation from showing.
    }
    if (!seen) this.setData({ guideVisible: true, guideStep: 0 });
  },

  _finishGuide() {
    this._guideGesture = null;
    if (typeof wx !== 'undefined' && typeof wx.setStorageSync === 'function') {
      try {
        wx.setStorageSync(GUIDE_STORAGE_KEY, true);
      } catch (error) {
        // Keep the current session usable even when local storage is unavailable.
      }
    }
    this.setData({ guideVisible: false });
  },

  onGuideNext() {
    if (!this.data.guideVisible) return;
    this._guideGesture = null;
    this._playSound('tick');
    if (this.data.guideStep === 0) this.setData({ guideStep: 1 });
    else this._finishGuide();
  },

  onGuideTouchStart(e) {
    this._guideGesture = null;
    if (!this.data.guideVisible || this.data.guideStep !== 0 || e.touches.length !== 1) return;
    const touch = e.touches[0];
    const which = e.currentTarget.dataset.which;
    const gesture = {
      startX: touch.clientX, startY: touch.clientY,
      lastX: touch.clientX, lastY: touch.clientY,
      which, lastMoveAt: 0
    };
    this._guideGesture = gesture;
    if (!which || typeof wx.createSelectorQuery !== 'function') return;
    wx.createSelectorQuery().in(this).select('#wheel' + which).boundingClientRect(rect => {
      if (!rect || this._guideGesture !== gesture) return;
      gesture.cx = rect.left + rect.width / 2;
      gesture.cy = rect.top + rect.height / 2;
      const dx = touch.clientX - gesture.cx;
      const dy = touch.clientY - gesture.cy;
      const distance = Math.sqrt(dx * dx + dy * dy);
      const radius = rect.width / 2;
      if (distance <= radius * 0.237 || distance > radius) return;
      gesture.layer = distance > radius * 0.64 ? 'mbti' : 'zodiac';
      gesture.rotKey = 'rot' + which + '_' + gesture.layer;
      gesture.startRot = this.data[gesture.rotKey];
      gesture.dragRadius = Math.max(distance, radius * 0.4);
      this.setData({ ['rotTrans' + which + '_' + gesture.layer]: 'none' });
    }).exec();
  },

  onGuideTouchMove(e) {
    const gesture = this._guideGesture;
    if (!gesture) return;
    if (e.touches.length !== 1) {
      this.onGuideTouchCancel();
      return;
    }
    const touch = e.touches[0];
    gesture.lastX = touch.clientX;
    gesture.lastY = touch.clientY;
    const dx = touch.clientX - gesture.startX;
    const dy = touch.clientY - gesture.startY;
    if (Math.abs(dx) < 8 * this.data.guideScale || Math.abs(dx) < Math.abs(dy) * 1.25) return;
    if (!gesture.layer || Date.now() - gesture.lastMoveAt < 16) return;
    const direction = gesture.which === 'A' ? 1 : -1;
    const rot = gesture.startRot + direction * dx * 180 / (Math.PI * gesture.dragRadius);
    gesture.lastMoveAt = Date.now();
    this.setData({ [gesture.rotKey]: rot });
  },

  _snapGuideWheel(gesture) {
    if (!gesture || !gesture.layer) return;
    const step = gesture.layer === 'mbti' ? MBTI_SLOT_DEG : ZODIAC_SLOT_DEG;
    this.setData({ [gesture.rotKey]: Math.round(this.data[gesture.rotKey] / step) * step });
    this._syncPick(gesture.which);
  },

  onGuideTouchEnd(e) {
    const gesture = this._guideGesture;
    this._guideGesture = null;
    if (!gesture || !this.data.guideVisible || this.data.guideStep !== 0) return;
    this._snapGuideWheel(gesture);
    const touch = e.changedTouches && e.changedTouches[0];
    const dx = (touch ? touch.clientX : gesture.lastX) - gesture.startX;
    const dy = (touch ? touch.clientY : gesture.lastY) - gesture.startY;
    const threshold = 32 * this.data.guideScale;
    if (Math.abs(dx) >= threshold && Math.abs(dx) >= Math.abs(dy) * 1.25) this.onGuideNext();
  },

  onGuideTouchCancel() {
    this._snapGuideWheel(this._guideGesture);
    this._guideGesture = null;
  },

  stopGuideTap() {},

  stopGuideTouch() {},

  _getApp() {
    return typeof getApp === 'function' ? getApp() : null;
  },

  _startSpinTicks() {
    if (this._spinTickTimer) clearTimeout(this._spinTickTimer);
    const startedAt = Date.now();
    const tick = () => {
      const progress = Math.min(1, (Date.now() - startedAt) / 2800);
      if (progress >= 1) {
        this._spinTickTimer = null;
        return;
      }
      this._playSound('tick');
      const delay = 75 + Math.pow(progress, 2) * 220;
      this._spinTickTimer = setTimeout(tick, delay);
    };
    tick();
  },

  _playSound(name) {
    const app = this._getApp();
    if (app && typeof app.playSound === 'function') app.playSound(name);
  },

  onShareAppMessage() {
    return {
      title: 'MBTI 星座轮盘 · 测测你们的宇宙契合度',
      path: '/pages/index/index'
    };
  }
});
